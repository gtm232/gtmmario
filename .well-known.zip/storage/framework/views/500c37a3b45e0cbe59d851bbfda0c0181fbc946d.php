<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Laporan Pekerjaan</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                               
			<?php if(Auth::user()->hak_akses == "admin"): ?>			
             <form style="float:left; margin-right:0px 5px 10px;" action="<?php echo url('/tambah_dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
						<button type="submit" class="btn btn-info">Tambah</button></a>
			</form>
					<br>
			<?php endif; ?>
          
			<br>
            <div class="card-body ">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Tanggal</th>
					  <th>Jenis Dokumen</th>
                      <th>Perihal</th>
					  <th>No Surat</th>
					  <th>Dari</th>
					  <th>Kepada</th>
                      
                      <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>Opsi</th>.
					  <?php endif; ?>
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php 
				  $no=1;
				  $dokumen_laporan_pekerjaan=DB::table('dokumen_laporan_pekerjaan')->where('id_laporan_pekerjaan','=',$id_laporan_pekerjaan)->get();
				  ?>
				  <?php $__currentLoopData = $dokumen_laporan_pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(date('d-m-Y',strtotime($pkn->tanggal))); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->jenis_dokumen); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->prihal); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->no_surat); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;">
					  <?php if($pkn->jenis_dokumen == "SPPH" or $pkn->jenis_dokumen == "Undangan Nego" or $pkn->jenis_dokumen == "BA Nego" or $pkn->jenis_dokumen == "SPK" or $pkn->jenis_dokumen == "BAP" or $pkn->jenis_dokumen == "BAST"){  
						echo "PGN";
					  } else if($pkn->jenis_dokumen == "SPH" or $pkn->jenis_dokumen == "LPS" or $pkn->jenis_dokumen == "SPP"){
						echo "PGASOL";
					  }
					  ?>
					  
					  </div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;">
					  <?php if($pkn->jenis_dokumen == "SPPH" or $pkn->jenis_dokumen == "Undangan Nego" or $pkn->jenis_dokumen == "BA Nego" or $pkn->jenis_dokumen == "SPK" or $pkn->jenis_dokumen == "BAP" or $pkn->jenis_dokumen == "BAST"){  
						echo "PGASOL";
					  } else if($pkn->jenis_dokumen == "SPH" or $pkn->jenis_dokumen == "LPS" or $pkn->jenis_dokumen == "SPP"){
						echo "PGN";
					  }
					  ?>
					  
					  </div></a></td>
                      
					   <div style="display:none;">
					<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/lihat_dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
						<input type="hidden" name="id" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
					</form>
					  </div>
					 
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td>
					  <form style="float:left; margin-right:5px;" action="<?php echo url('/edit_dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
						<input type="hidden" name="id" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">Edit</button></a>
					</form>
					  
					<form method="post" action="<?php echo url('/hapus_dokumen_pekerjaan'); ?>">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id" value="<?php echo e($pkn->id); ?>">
						<input type="hidden" name="nama_dokumen_pekerjaan" value="<?php echo e($pkn->nama_dokumen_pekerjaan); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					
					
					  </td>
					   <?php endif; ?>
					   
                    </tr>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>