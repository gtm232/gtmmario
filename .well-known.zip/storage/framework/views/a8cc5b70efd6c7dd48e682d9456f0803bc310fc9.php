<table border="1">
                    <tr>
					  <td rowspan="2" >No</td>
					  <td rowspan="2" >Program Kerja</td>
					  <td rowspan="2" >Status</td>
                      <td rowspan="2">Nilai Seluruh SPK</td>
                      <td colspan="2">SPK</td>
                      <td >Nomor PO</td>
					  <td >Realisasi & Nomor Receipt</td>
					  <td colspan="2">BAP</td>
					  <td colspan="2">BAST</td>
                     
					</tr>
					
					<tr>
						<td>Nomor</td>
						<td>Tanggal</td>
						<td>Nomor</td>
						<td>Tanggal</td>
						<td>Nomor</td>
						<td>Tanggal</td>
					</tr>
					
					<tr>
						<?php
						$tahundashboard=date('Y');
						if(isset($_GET["tdn"])){
							$eproc=DB::table('spk_dev')->where('tahun',$_GET["tdn"])->get();
						}else{
							$eproc=DB::table('spk_dev')->where('tahun',$tahundashboard)->get();
						}
						$no=1;
						?>
						<?php $__currentLoopData = $eproc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eproc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<td><?php echo e($no); ?></td>
						<td>
						<?php
						$dlp=DB::table('dokumen_laporan_pekerjaan')->where('id',$eproc->id_dokumen)->get()->first();
						$lp=DB::table('laporan_pekerjaan')->where('id',$dlp->id_laporan_pekerjaan)->get()->first();
						?>
						<?php echo e($lp->nama_pekerjaan); ?> (<?php echo e($eproc->persentasi); ?>%)
						</td>
						<td><?php echo e($lp->status); ?></td>
						<td>
						<?php
						$dspk=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$lp->id],['jenis_dokumen','SPK']])->get()->first();
						echo number_format((($eproc->persentasi/100)*$dspk->harga),0,',','.');
						?>
						</td>
						<td><?php echo e($dspk->no_surat); ?></td>
						<td><?php echo e(date('d-m-Y',strtotime($dspk->tanggal))); ?></td>
						<td>
							<?php
								$nomor_po=DB::table('eproc')->where('id_spk_dev',$eproc->id)->get()->first();
							?>
							
								<?php
									if($nomor_po and $nomor_po->nomor_po != 0){
								?>
								<?php echo e($nomor_po->nomor_po); ?>

								<?php
								}
								?>
								
						</td>
						<td>
								<?php
									if($nomor_po and $nomor_po->nomor_receipt != 0){
								?>
								<?php echo e($nomor_po->nomor_receipt); ?>

								<?php
								}
								?>
							
							
						</td>
						<td>
						<?php
						$dbap=DB::table('dokumen_laporan_pekerjaan')->where('id_spk_dev',$eproc->id)->where('jenis_dokumen','BAP')->get()->first();
						if($dbap){
						echo $dbap->no_surat;
						}
						?>
						</td>
						<td>
						<?php
						if($dbap){
						echo date('d-m-Y',strtotime($dbap->tanggal));
						}
						?>
						</td>
						<td>
						<?php
						$dbast=DB::table('dokumen_laporan_pekerjaan')->where('id_spk_dev',$eproc->id)->where('jenis_dokumen','BAST')->get()->first();
						if($dbast){
						echo $dbast->no_surat;
						}
						?>
						</td>
						<td>
						<?php
						if($dbast){
						echo date('d-m-Y',strtotime($dbast->tanggal));
						}
						?>
						</td>
					</tr>
					<?php
					$no++;
					?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  
                </table>