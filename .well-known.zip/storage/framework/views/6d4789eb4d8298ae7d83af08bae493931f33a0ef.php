<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-12 col-lg-12 align-self-center" style="text-align:center; margin-bottom:10px;">
                        <h3 class="text-themecolor m-b-0 m-t-0">Laporan Bulanan</h3>
                        
                    </div>
                   
                </div>
				
			<table>
				<tr>
				<td>
				<form action="<?php echo url('/bulan_tahun'); ?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="tahunbulan" value="<?php echo e($tahunbulan-1); ?>">
					<button type="submit" class="btn btn-primary"><<</button>
				</form>
				</td>
				<td>
				<form>
				<button type="submit" class="btn btn-primary"><?php echo e($tahunbulan); ?></button>
				</form>
				</td>
				<td>
				<form action="<?php echo url('/bulan_tahun'); ?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="tahunbulan" value="<?php echo e($tahunbulan+1); ?>">
					<button type="submit" class="btn btn-primary">>></button>
				</form>
				</td>
				</tr>
			</table>
			<br>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                            <br>   
			<?php if(Auth::user()->hak_akses == "admin"): ?>			
             <a style="margin:10px;" href="<?php echo e(route('bulanan.create')); ?>" ><button class="btn btn-info">Tambah</button></a>
            <?php endif; ?>
          
			<br>
            <div class="card-body ">
              <div class="table-responsive" style="margin:10px;">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Bulan</th>
                      <th>Lokasi Arsip</th>
                      
                      <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>Opsi</th>
					  <?php endif; ?>
					  
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php $no=1; ?>
				  <?php $__currentLoopData = $bulanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
					
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;">
					  <?php if($bln->bulan == 1): ?>
						Januari
					  <?php elseif($bln->bulan == 2): ?>
						Februari
					  <?php elseif($bln->bulan == 3): ?>
						Maret
					  <?php elseif($bln->bulan == 4): ?>
						April
					  <?php elseif($bln->bulan == 5): ?>
						Mei
					  <?php elseif($bln->bulan == 6): ?>
						Juni
					  <?php elseif($bln->bulan == 7): ?>
						Juli
					  <?php elseif($bln->bulan == 8): ?>
						Agustus
					  <?php elseif($bln->bulan == 9): ?>
						September
					  <?php elseif($bln->bulan == 10): ?>
						Oktober
					  <?php elseif($bln->bulan == 11): ?>
						November
					  <?php elseif($bln->bulan == 12): ?>
						Desember
					  <?php endif; ?>
					  </div></a></td>
                      
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($bln->arsip); ?></div></a></td>
                      
					  <div style="display:none;">
					  <form id="dbln<?php echo e($no); ?>" action="<?php echo url('/wilayah_operasi'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($bln->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
					</form>
					  </div>
					  
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					<td style="width:20%;">
					 
					<a  style="float:left; margin-right:5px;" href="<?php echo e(route('bulanan.edit',$bln->id)); ?>"><button class="btn btn-primary">Edit</button></a>
					  
					<form style="float:left; margin-right:5px;" method="post" action="<?php echo e(route('bulanan.destroy',$bln->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					
					<form style="float:left; margin-right:5px;" method="post" action="<?php echo url('/download_bulanan'); ?>">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_bulanan" value="<?php echo e($bln->id); ?>">
						<input type="submit" class="btn btn-success" value="Download" />
					</form>
					
					  </td>
					  
					  
					  <?php endif; ?>
					  
                    </tr>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>