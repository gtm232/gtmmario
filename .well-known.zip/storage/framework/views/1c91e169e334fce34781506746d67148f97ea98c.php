<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Laporan Bulanan</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                   
					<br>
          
			<br>
            <div class="card-body ">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Nama Pekerjaan</th>
                      <th>Tanggal Mulai</th>
					  <th>Tanggal Berakhir</th>
					  <th>PIC</th>
					  <th>Lokasi Arsip</th>
                      <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>Opsi</th>
					  <?php endif; ?>
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php $no=1; ?>
				  <?php $__currentLoopData = $peringatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				   <?php  
							$tanggal_lahir  = strtotime($pkn->tanggal_berakhir);
							$sekarang    = time(); // Waktu sekarang
							$diff   = $sekarang - $tanggal_lahir;
							//echo 'umur anda adalah ' . floor($diff / (60 * 60 * 24 * 365)) . ' Tahun'; // Umur anda dalam hitungan tahun
							//echo 'umur anda adalah ' . floor($diff / (60 * 60 * 24)) . ' Hari'; // Umur anda dalam hitungan hari	
							$selisih= floor($diff / (60 * 60 * 24));
							
						
							
					?>
					<?php if($pkn->status != "CLOSED"): ?>
					<?php if($selisih >= -30 or $selisih > 1 ): ?>
                    <tr>
					
					  <td style="background:red; color:#ffff;"><?php echo e($selisih); ?><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%; color:#ffff;"><?php echo e($pkn->nama_pekerjaan); ?></div></a> </td>
                      <td style="background:red; color:#ffff;"><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%; color:#ffff;"><?php echo e($pkn->tanggal_mulai); ?></div></a></td>
                      <td style="background:red; color:#ffff;"><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%; color:#ffff;"><?php echo e($pkn->tanggal_berakhir); ?></div></a></td>
                      <td style="background:red; color:#ffff;"><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%; color:#ffff;"><?php echo e($pkn->pic); ?></div></a></td>
					  <td style="background:red; color:#ffff;"><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%; color:#ffff;"><?php echo e($pkn->lokasi); ?></div></a></td>
                      
					  <div style="display:none;">
					  <form id="dbln<?php echo e($no); ?>" action="<?php echo url('/dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
					</form>
					  </div>
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td style="background:red; color:#ffff;">
					 
					 <a  style="float:left; margin-right:5px;" href="<?php echo e(route('peringatan.edit',$pkn->id)); ?>"><button class="btn btn-primary">Edit</button></a>
				
					  </td>
					  <?php endif; ?>
                    </tr>
					<?php endif; ?>
					<?php endif; ?>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>