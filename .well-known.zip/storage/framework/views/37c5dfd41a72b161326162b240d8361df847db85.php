<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-12 col-lg-12 align-self-center" style="text-align:center; margin-bottom:10px;">
                        <h3 class="text-themecolor m-b-0 m-t-0">Permintaan Surat</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                            <br>   
			<?php if(Auth::user()->hak_akses == "admin"): ?>			
             <a style="margin:10px;" href="<?php echo e(route('permintaan_surat.create')); ?>" ><button class="btn btn-info">Tambah</button></a>
            <?php endif; ?>
          
			<br>
            <div class="card-body ">
              <div class="table-responsive" style="margin:10px;">
                <table class="table table-bordered table-striped table-hover js-basic-example dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>no</th>
                      <th>Perihal Permintaan</th>
                      <th>File LPS</th>
                      <th>Catatan</th>
                      
                      <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>Opsi</th>
					  <?php endif; ?>
					  
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php $no=1; ?>
				  <?php $__currentLoopData = $permintaan_surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permintaan_surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
					  <td><?php echo e($no); ?></td>
					  <td><?php echo e($permintaan_surat->perihal_permintaan); ?></td>
                      <td><?php echo e($permintaan_surat->file); ?></td>
                      <td>
					  <?php echo $permintaan_surat->catatan; ?>
					  </td>
                    
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td>
					 
					<a  style="float:left; margin-right:5px;" href="<?php echo e(route('permintaan_surat.edit',$permintaan_surat->id)); ?>"><button class="btn btn-primary">Edit</button></a>
					  
					<form method="post" action="<?php echo e(route('permintaan_surat.destroy',$permintaan_surat->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					
					  </td>
					  <?php endif; ?>
					  
                    </tr>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>