<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Pembuatan Surat</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                               
					
            <form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/tambah_pembuatan_surat_isi');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id_pembuatan_surat" value="<?php echo e($id); ?>">
					<input type="submit" class="btn btn-info" value="Tambah" />
			</form>
          
          
			<br>
            <div class="card-body ">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Perihal</th>
                      <th>Opsi</th>
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php 
				  $no=1; 
				  $pembuatan_surat_isi=DB::table('pembuatan_surat_isi')->where('id_pembuatan_surat','=',$id)->get();
				  ?>
				  <?php $__currentLoopData = $pembuatan_surat_isi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
						<td><?php echo e($pbs->prihal); ?></td>
						
						<td>
							<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/edit_pembuatan_surat_isi');?>" method="post">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id_pembuatan_surat" value="<?php echo e($id); ?>">
								<input type="hidden" name="id_edit" value="<?php echo e($pbs->id); ?>">
								<input type="submit" class="btn btn-info" value="Edit" />
							</form>
							
							<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/lihat_pembuatan_surat_isi');?>" method="post">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id_pembuatan_surat" value="<?php echo e($id); ?>">
								<input type="hidden" name="id_edit" value="<?php echo e($pbs->id); ?>">
								<input type="submit" class="btn btn-primary" value="Lihat" />
							</form>
							
							<?php if(Auth::user()->hak_akses == "admin"): ?>
							<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/hapus_pembuatan_surat_isi');?>" method="post">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id_pembuatan_surat" value="<?php echo e($id); ?>">
								<input type="hidden" name="id_edit" value="<?php echo e($pbs->id); ?>">
								<input type="submit" class="btn btn-danger" value="Hapus" />
							</form>
							<?php endif; ?>
						</td>
                    </tr>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
				
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>