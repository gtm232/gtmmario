<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Tambah Data</h2>
			<form class="form-group" action="<?php echo e(route('pembuatan_surat.update',$pembuatan_surat->id)); ?>" method="post">
				<input type="hidden" name="_method" value="PUT">
				<?php echo e(csrf_field()); ?>

				<div class="form-group">
					<label for="judul">Nama Pekerjaan</label>
					<input type="text" name="nama_pekerjaan" class="form-control" value="<?php echo e($pembuatan_surat->nama_pekerjaan); ?>" required="required">
					<input type="hidden" name="nama_user" class="form-control" value="<?php echo e(Auth::user()->id); ?>" required="required">
					<input type="hidden" name="status" value="<?php echo e($pembuatan_surat->status); ?>" class="form-control" >
				</div>
				
				<div class="form-group">
					<label for="isi">Jenis Pekerjaan</label>
					<select name="jenis_pekerjaan" class="form-control" required="required">
						<option value="<?php echo e($pembuatan_surat->jenis_pekerjaan); ?>"><?php echo e($pembuatan_surat->jenis_pekerjaan); ?></option>
						<option value="Offshore">Offshore</option>
						<option value="Onshore">Onshore</option>
						<option value="Fasilitas">Fasilitas</option>
						<option value="Integrity">Integrity</option>
					</select>
				</div>
				
				<div class="form-group">
					<label for="isi">Catatan</label>
					<textarea name="catatan" id="catatan">
						<?php echo e($pembuatan_surat->catatan); ?>

					</textarea>
					<script>
					CKEDITOR.replace('catatan', {removePlugins: 'about,sourcearea,link,elementspath,image'});
					</script>
				</div>
				
				<div class="form-group">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>