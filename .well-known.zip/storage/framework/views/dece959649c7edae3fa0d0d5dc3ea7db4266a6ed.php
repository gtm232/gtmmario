<?php $__env->startSection('content'); ?>

	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
				<?php 
				  $dokumen_laporan_pekerjaan=DB::table('dokumen_laporan_pekerjaan')->where('id','=',$id)->get()->first();
				?>
                <div class="row page-titles">
                    <div class="col-md-12 col-12 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0"><?php echo e($dokumen_laporan_pekerjaan->prihal); ?></h3>
                        
                    </div>
					
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                               
			<?php $dokumen_laporan_pekerjaan2=DB::table('dokumen_laporan_pekerjaan')->where('id_laporan_pekerjaan','=',$id_laporan_pekerjaan)->get(); ?>
            <div class="card-body ">
				<select class="form-control" id="dokumen" onchange="dokumen(this.value)">
					<option value="0">-- Silahkan Pilih --</option>
					<?php $__currentLoopData = $dokumen_laporan_pekerjaan2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($pkn->id); ?>"><?php echo e($pkn->prihal); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				
				<div style="display:none;">
				<form id="bln" action="<?php echo url('/lihat_dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
						<input type="hidden" name="id" id="text" value="">
						<button type="submit" class="btn btn-primary">save</button></a>
				</form>
				</div>
			<?php
			$nama_pekerjaan=DB::table('laporan_pekerjaan')->where('id','=',$id_laporan_pekerjaan)->get()->first();
			?>
			<iframe width="100%" height="700" src="<?php echo URL::to('/'); ?>/laporan_pekerjaan/<?php echo e($nama_pekerjaan->nama_pekerjaan); ?>/<?php echo e($dokumen_laporan_pekerjaan->nama_folder); ?>/<?php echo e($dokumen_laporan_pekerjaan->nama_dokumen_pekerjaan); ?>">
			</iframe>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<script type="text/javascript">
   function dokumen(value) {
	  
	$('#text').val(value);
	document.getElementById('bln').submit()
}
</script>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>