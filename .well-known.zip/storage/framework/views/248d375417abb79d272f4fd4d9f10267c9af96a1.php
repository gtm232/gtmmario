<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-block">
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Upload file</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
						<form  style="" action="<?php echo url('/import1'); ?>" method="post" enctype="multipart/form-data">
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
							<input type="hidden" name="id_mea" value="<?php echo e($id_mea); ?>">
							<label for="file">Upload file</label>
							<input type="file" class="form-control-file" name="file" id="file" placeholder="">
						  </div>
						  <div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							<button type="Submit" class="btn btn-primary">Save changes</button>
						  </div>
					  </form>
					</div>
				  </div>
			</div>
			
			<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Lihat Detail</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
						<div id="lihat_detail_mea">
						
						</div>
					  </div>
						  
						  <div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						  </div>
					</div>
				  </div>
			</div>
			
			
				<div class="card-body ">
				<a style="float:left; margin:5px;" href="javascript:" onclick="document.getElementById('detail_mea').submit()" ><i class="fa fa-plus" style="background:blue; color:white; padding:5px; border-radius: 5px;">&nbsp;Tambah Rekomendasi</i></a>
				<form id="detail_mea" style="display:none; " action="<?php echo url('/tambah_detail_mea'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_mea" value="<?php echo e($id_mea); ?>">
						<button type="submit" class="btn btn-info">Tambah</button></a>
				</form>
				
				<a style="float:left; margin:5px;" href="javascript;" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-cloud-upload" style="background:#1dced6; color:white; padding:5px; border-radius: 5px;">&nbsp;Import Data</i></a>
				
				<a style="float:left; margin:5px;" href="<?php echo url('/'); ?>/export?id_mea=<?php echo e($id_mea); ?>" ><i class="fa fa-cloud-download" style="background:green; color:white; padding:5px; border-radius: 5px;">&nbsp;Export Data</i></a>
				
						<div class="table-responsive">
							<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
							  <thead>
								<tr>
								  <th>No</th>
								  <th>Nama Aset</th>
								  <th>Fungsi Aset</th>
								  <th>Penyebab</th>
								  <th>Ranking</th>
								  <th>Rekomendasi</th>
								  <th>Due Date</th>
								  <th>PIC</th>
								  <th>Status</th>
								  <th>Tindak Lanjut</th>
								</tr>
								
							  </thead>
							  
							  <tbody>
								<?php
								$detail_mea=DB::table('detail_mea')->where('id_mea',$id_mea)->get();
								$no=1;
								?>
								<?php $__currentLoopData = $detail_mea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_mea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
								
								  <td><?php echo e($no); ?></td>
								  <td><?php echo e($detail_mea->nama_aset); ?></td>
								  <td><?php echo e($detail_mea->fungsi_aset); ?></td>
								  <td><?php echo e($detail_mea->penyebab); ?></td>
								  <td><?php echo e($detail_mea->ranking); ?></td>
								  <td><?php echo e($detail_mea->rekomendasi); ?></td>
								  <td><?php echo e(date('d-M-Y',strtotime($detail_mea->duedate))); ?></td>
								  <td><?php echo e($detail_mea->pic); ?></td>
								  <td><?php echo e($detail_mea->status); ?></td>
								  <td>
									<a style="float:left; margin:5px;" href="javascript:" onclick="document.getElementById('hapus_detail_mea').submit()" ><i class="fa fa-trash-o" style="background:#f7526f; color:white; padding:5px; border-radius: 5px;">&nbsp;Hapus</i></a>
									<form id="hapus_detail_mea" style="display:none; " action="<?php echo url('/hapus_detail_mea'); ?>" method="post">
											<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
											<input type="hidden" name="id" value="<?php echo e($detail_mea->id); ?>">
											<input type="hidden" name="id_mea" value="<?php echo e($detail_mea->id_mea); ?>">
											<button type="submit" class="btn btn-info">Tambah</button></a>
									</form>
									<?php if($detail_mea->status == "Open"): ?>
									<a style="float:left; margin:5px;" href="javascript:" data-toggle="modal" data-target="#exampleModal<?php echo e($no); ?>"><i class="fa fa-plus" style="background:blue; color:white; padding:5px; border-radius: 5px;">&nbsp;Tindak Lanjut</i></a>
									
									<?php endif; ?>
									
									<?php if($detail_mea->status == "Closed"): ?>
									<a style="float:left; margin:5px;" class="lihat_detail_mea" href="javascript:" token="<?php echo e(csrf_token()); ?>" id-detail-mea="<?php echo e($detail_mea->id); ?>"><i class="fa fa-plus" style="background:blue; color:white; padding:5px; border-radius: 5px;">&nbsp;Lihat</i></a>
									
									<?php endif; ?>
								  </td>
							
								</tr>
								
								<div class="modal fade" id="exampleModal<?php echo e($no); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
											  <div class="modal-dialog" role="document">
												<div class="modal-content">
												  <div class="modal-header">
													<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													  <span aria-hidden="true">&times;</span>
													</button>
												  </div>
												  <div class="modal-body">
													<form id="detail_mea" style="" action="<?php echo url('/tindak_lanjut'); ?>" method="post" enctype="multipart/form-data">
														<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
														<input type="hidden" name="id_mea" value="<?php echo e($id_mea); ?>">
														<div class="form-group">
															<label >Tindak Lanjut</label>
																<input type="hidden" name="id_detail_mea" value="<?php echo e($detail_mea->id); ?>">
																<input type="hidden" name="id_mea" value="<?php echo e($detail_mea->id_mea); ?>">
															  <textarea class="form-control" name="tindak_lanjut"></textarea>
														</div>
														<div class="form-group">
															<label>Tanggal Closing</label>
															  <input style="background:#ffff;" type="text" class="form-control" id="tgl" autocomplete="off" name="tgl" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>
															
														</div>
														
														<div class="form-group">
															<label for="file">Upload file</label>
															<input type="file" class="form-control" name="file" id="file" accept="image/png, image/jpeg, image/JPG, image/PNG" placeholder="">
														</div>
							
														
														<div class="form-group">
															<label >Status</label>
															<select class="form-control" name="status">
																<option>--Pilih--</option>
																<option value="Open">Open</option>
																<option value="Closed">Closed</option>
															</select>
														</div>
													  </div>
													  <div class="modal-footer">
														<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
														<button type="Submit" class="btn btn-primary">Save changes</button>
													  </div>
												  </form>
												</div>
											  </div>
									</div>
									
								<?php
								$no++;
								?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							  </tbody>
							</table>
						</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>