<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Tambah MEA</h2>
			<form class="form-group" action="<?php echo url('/tambah_detail_mea_proses'); ?>" method="post" enctype="multipart/form-data">
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				<input type="hidden" name="id_mea" value="<?php echo e($id_mea); ?>">
				
				<div class="form-group">
					<label >Nama Aset</label>
					  <input type="text" class="form-control" name="nama_aset">
					
				</div>
				
				<div class="form-group">
					<label >Fungsi Aset</label>
					  <input type="text" class="form-control" name="fungsi_aset">
					
				</div>
				
				<div class="form-group">
					<label>Penyebab</label>
					  <textarea class="form-control" name="penyebab"></textarea>
				</div>
				
				<div class="form-group">
					<label >Ranking</label>
					  <input type="text" class="form-control" name="ranking">
					
				</div>
				
				<div class="form-group">
					<label>Rekomendasi</label>
					  <textarea class="form-control" name="rekomendasi">
					  
					  </textarea>
				</div>
			
				<div class="form-group">
					<label>Due Date</label>
					  <input style="background:#ffff;" type="text" class="form-control" id="tgl" autocomplete="off" name="duedate" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>
					
				</div>
				
				<div class="form-group">
					<label >PIC</label>
					  <input type="text" class="form-control" name="pic">
					
				</div>
				
				<div class="form-group">
					<label >Status</label>
					<select class="form-control" name="status">
						<option>--Pilih--</option>
						<option value="Open">Open</option>
						<option value="Closed">Closed</option>
					</select>
				</div>
				
				<div class="form-group">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>