<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12">
            <div class="card" style="margin:auto; padding:80px; width:780px;">
				
					<?php
					$u=DB::table('pembuatan_surat')->where('id',$id_pembuatan_surat)->get()->first(); 
					?> 
					<table style="margin:10px;" border="0">
						<tr>
							<td valign="top">Nomor</td>
							<td valign="top">:</td>
							<td valign="top"><?php echo e($u->nomor_surat); ?></td>
						</tr>
						
						<tr>
							<td valign="top">Sifat</td>
							<td valign="top">:</td>
							<td valign="top"><?php echo e($u->sifat); ?></td>
						</tr>
						
						<tr>
							<td valign="top">Lampiran</td>
							<td valign="top">:</td>
							<td valign="top"><?php echo e($u->lampiran); ?></td>
						</tr>
						
						<tr>
							<td valign="top">Perihal</td>
							<td valign="top">:</td>
							<td valign="top"><?php echo e($u->perihal); ?></td> 
						</tr>
					</table>
					
					<?php 
					$tgl=date('d',strtotime ($u->tanggal_surat)); 
					$bln1=date('M',strtotime ($u->tanggal_surat));
					if($bln1 == "Jan"){
					$bln="Januari";	
					}else if($bln1 == "Feb"){
					$bln="Februari";	
					}else if($bln1 == "Mar"){
					$bln="Maret";	
					}else if($bln1 == "Apr"){
					$bln="April";	
					}else if($bln1 == "May"){
					$bln="Mei";	
					}else if($bln1 == "Jun"){
					$bln="Juni";	
					}else if($bln1 == "Jul"){
					$bln="Juli";	
					}else if($bln1 == "Jan"){
					$bln="Januari";	
					}else if($bln1 == "Aug"){
					$bln="Agustus";	
					}else if($bln1 == "Sep"){
					$bln="September";	
					}else if($bln1 == "Oct"){
					$bln="Oktober";	
					}else if($bln1 == "Nov"){
					$bln="November";	
					}else if($bln1 == "Dec"){
					$bln="Desember";	
					} 
					$thn=date('Y',strtotime ($u->tanggal_surat));
					?>
					<div style="margin:10px; width:200px;">
					Jakarta <?php echo e($tgl); ?> <?php echo e($bln); ?> <?php echo e($thn); ?>

					</div>
					
					<div style="margin:10px; width:300px;">
						Kepada Yth.<br>
						<div style="width:190px; font-weight:bold;"><?php echo e($u->tujuan); ?></div>
						<div style="width:370px;"><?php echo e($u->alamat); ?></div>
					</div>
					
					<div style="margin:0px 10px -20px 10px; text-align:justify;">
						<?php echo $u->isi; ?>
					</div>
					
					<div style="margin:0px 10px 0px 10px; text-align:justify;">
						<div style="width:100%; margin-bottom:10px;">Demikian disampaikan, atas perhatian dan kerjasamanya diucapkan terima kasih.</div>
						<div style="font-weight:bold; margin-bottom:80px;">Division Head, Gas Transmission Management</div>
						<div style="font-weight:bold; margin-bottom:80px;">Posma L.Sirait</div>
					</div>
				
			</div>	
		</div>	
	</div>					
						
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>