<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Tambah Data</h2>
			<form class="form-line" action="<?php echo url('/tambah_dokumen_pekerjaan_proses'); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				
				<div class="form-line">
					<label for="isi">No Surat</label>
					<input type="text" name="no_surat" class="form-control" value="<?php if(isset($no_surat)){echo $no_surat->nomor_surat;} ?>" required="required">
					<input type="hidden" name="id_laporan_pekerjaan" class="form-control" value="<?php echo e($id_laporan_pekerjaan); ?>">
				</div>
				
				<?php
				$parameter_BANK=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','Undangan Nego'],])->count();
				$parameter_SPK=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','BA Nego'],])->count();
				$parameter_LPS=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','SPK'],])->count();
				$parameter_BAP=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','LPS'],])->count();
				$parameter_BAST=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','BAP'],])->count();
				$parameter_SPP=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','BAST'],])->count();
				?>
				<div class="form-line">
					<label for="isi">Jenis Dokumen</label>
					<select name="jenis_dokumen" class="form-control" id="zoneSelect" onchange="updateChar();" required="required">
						<option value="">--Pilih Jenis Dokumen--</option>
						<option value="Usulan">Usulan</option>
						<option value="SPPH">Surat Permintaan Penawaran Harga</option>
						<option value="SPH">Surat Penawaran Harga</option>
						<option value="Undangan Nego">Undangan Klarifikasi & Negosiasi</option>
						
						<option value="BA Nego">Berita Acara Hasil Klarifikasi & Negosiasi</option>
						
						<?php if($parameter_SPK != 0){ ?>
						<option value="SPK">Surat Perintah Kerja</option>
						<?php } ?>
						<?php if($parameter_LPS != 0){ ?>
						<option value="LPS">Laporan Penyelesaian Pekerjaan</option>
						<?php } ?>
						<?php if($parameter_BAP != 0){ ?>
						<option value="BAP">Berita Acara Pemeriksaan</option>
						<?php } ?>
						<?php if($parameter_BAST != 0 or $parameter_BAP != 0){ ?>
						<option value="BAST">Berita Acara Serah Terima</option>
						<?php } ?>
						<?php if($parameter_SPP != 0 or $parameter_BAST != 0 or $parameter_SPK != 0){ ?>
						<option value="SPP">Surat Permohonan Pembayaran</option>
						<?php } ?>
						<option value="Surat Masuk">Surat Masuk</option>
						<option value="Surat Keluar">Surat Keluar</option>
					</select>
				</div>
				
				<?php
					$perihal=DB::table('laporan_pekerjaan')->where('id','=',$id_laporan_pekerjaan)->get()->first();
				?>
				<div class="form-line">
					<label for="isi">Perihal</label>
					<input type="text" id="prihal" name="nama" class="form-control" required="required">
				</div>
				
				<div class="form-line">
					<label >Tanggal</label>
					  <input style="background:#ffff;" type="text" class="form-control" id="tgl3" autocomplete="off" name="tanggal" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>
				</div>
				
				<div style="display:none;" id="harga1" class="form-line">
					<label for="judul">Harga</label>
					<input type="text" id="harga_kesepakatan" name="harga" class="form-control" >
				</div>
				
				<div style="display:none;" id="durasi" class="form-line">
					<label for="judul">Durasi</label>
					<input type="number" id="durasi" name="durasi" value="0" class="form-control" >
				</div>
				
				<div style="display:none;" id="perpem" class="form-line">
					<label for="judul">Persentasi Pembayaran</label>
					<select id="p2" name="p2" onchange="perPem();" class="form-control" >
					<?php
					$parm=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','SPK'],])->get()->first();
					$parm3=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','SPK'],])->count();
					if($parm3!=0){
					$parm2=DB::table('spk_dev')->where('id_dokumen',$parm->id)->get();
					}
					?>
					<option value="">--Pilih--</option>
					<?php
					if($parm3!=0){
					?>
					<?php $__currentLoopData = $parm2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parm2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($parm2->id); ?>"><?php echo e($parm2->persentasi); ?> %</option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php
					}
					?>
					</select>
					
					<input type="hidden" name="persentasi_pembayaran" id="persentasi_pembayaran">
					
				</div>
				
				<div class="form-line">
					<label for="exampleInputPassword1">File</label>
					<input type="file" class="form-control" name="file" onchange="validasiFile()" id="file" required>
				</div>
				
				<br>
				<div class="form-line">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>

<script>
function updateChar() {
	
    var zone = document.getElementById("zoneSelect");

    if (zone.value == "SPK"){
		$("#harga1").fadeIn(1000);
		$("#durasi").fadeIn(1000);
		$("#perpem").fadeOut(1000);
		document.getElementById("prihal").value = "Surat Perintah Kerja <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("persentasi_pembayaran").value = 0;
    }else if (zone.value == "SPP"){
		$("#durasi").fadeOut(1000);
		$("#harga1").fadeIn(1000);
		$("#perpem").fadeOut(1000);
		document.getElementById("prihal").value = "Surat Permohonan Pembayaran <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("durasi").value = 0;
		document.getElementById("persentasi_pembayaran").value = 0;
    }else if (zone.value == "SPH"){
		$("#harga1").fadeIn(1000);
		$("#durasi").fadeOut(1000);
		$("#perpem").fadeOut(1000);
		document.getElementById("durasi").value = 0;
		document.getElementById("prihal").value = "Surat Penawaran Harga <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("persentasi_pembayaran").value = 0;
    }else if (zone.value == "Usulan"){
		$("#harga1").fadeIn(1000);
		$("#durasi").fadeOut(1000);
		$("#perpem").fadeOut(1000);
		document.getElementById("durasi").value = 0;
		document.getElementById("prihal").value = "Usulan <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("persentasi_pembayaran").value = 0;
	}else if (zone.value == "SPPH"){
		$("#harga1").fadeOut(1000);
		$("#durasi").fadeOut(1000);
		$("#perpem").fadeOut(1000);
		document.getElementById("durasi").value = 0;
		document.getElementById("harga_kesepakatan").value = "Rp 0";
		document.getElementById("prihal").value = "Surat Permintaan Penawaran Harga <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("persentasi_pembayaran").value = 0;
	}else if (zone.value == "Undangan Nego"){
		$("#harga1").fadeOut(1000);
		$("#durasi").fadeOut(1000);
		$("#perpem").fadeOut(1000);
		document.getElementById("durasi").value = 0;
		document.getElementById("prihal").value = "Undangan Klarifikasi dan Negosiasi <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("harga_kesepakatan").value = "Rp 0";
		document.getElementById("persentasi_pembayaran").value = 0;
	}else if (zone.value == "BA Nego"){
		$("#harga1").fadeOut(1000);
		$("#durasi").fadeOut(1000);
		$("#perpem").fadeOut(1000);
		document.getElementById("durasi").value = 0;
		document.getElementById("harga_kesepakatan").value = "Rp 0";
		document.getElementById("prihal").value = "Berita Acara Klarifikasi dan Negosiasi Harga <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("persentasi_pembayaran").value = 0;
	}else if (zone.value == "LPS"){
		$("#harga1").fadeOut(1000);
		$("#durasi").fadeOut(1000);
		$("#perpem").fadeIn(1000);
		document.getElementById("durasi").value = 0;
		document.getElementById("harga_kesepakatan").value = "Rp 0";
		document.getElementById("prihal").value = "Laporan Penyelesaian <?php echo e($perihal->nama_pekerjaan); ?>";
	}else if (zone.value == "BAP"){
		$("#harga1").fadeIn(1000);
		$("#durasi").fadeOut(1000);
		$("#perpem").fadeIn(1000);
		document.getElementById("durasi").value = 0;
		document.getElementById("prihal").value = "Berita Acara Pemeriksaan <?php echo e($perihal->nama_pekerjaan); ?>";
	}else if (zone.value == "BAST"){
		$("#harga1").fadeIn(1000);
		$("#perpem").fadeOut(1000);
		document.getElementById("prihal").value = "Berita Acara Serah Terima <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("persentasi_pembayaran").value = 0;
	}else if (zone.value == "Surat Masuk" || zone.value == "Surat Keluar"){
		$("#harga1").fadeIn(1000);
		$("#perpem").fadeOut(1000);
		document.getElementById("prihal").value = "<?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("persentasi_pembayaran").value = 0;
	}
}
function validasiFile(){
    var inputFile = document.getElementById('file');
    var pathFile = inputFile.value;
    var ekstensiOk = /(\.pdf|\.PDF)$/i;
    if(!ekstensiOk.exec(pathFile)){
        alert('Silakan upload file yang memiliki ekstensi mp4');
        inputFile.value = '';
        return false;
    }else{
        //Pratinjau gambar
        
    }
}

function perPem() {
var pp = document.getElementById("p2");
		document.getElementById("persentasi_pembayaran").value = pp.value;
}

</script>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>