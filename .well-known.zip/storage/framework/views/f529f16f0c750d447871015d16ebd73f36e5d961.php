<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
				<?php 
				  $suratsurat=DB::table('surat_surat')->where('id','=',$id_suratsurat)->get()->first();
				?>
                <div class="row page-titles">
                    <div class="col-md-12 col-12 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0"><?php echo e($suratsurat->perihal); ?></h3>
                        
                    </div>
					
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                               
            <div class="card-body ">
				
			<?php if($suratsurat->jenis_surat == "Surat Masuk"): ?>
			<iframe width="100%" height="700" src="<?php echo URL::to('/'); ?>/surat_masuk/<?php echo e($suratsurat->file); ?>">
			</iframe>
			<?php else: ?>
			<iframe width="100%" height="700" src="<?php echo URL::to('/'); ?>/surat_keluar/<?php echo e($suratsurat->file); ?>">
			</iframe>
			<?php endif; ?>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>