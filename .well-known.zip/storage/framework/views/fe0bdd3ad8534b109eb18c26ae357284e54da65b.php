<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Attach</h2>
			<form class="form-group" action="<?php echo url('/attach_proses'); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				<div class="form-group">
					<label for="exampleInputPassword1">File</label>
					<input type="file" class="form-control" name="file"  id="file" required>
					<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
					<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
					<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
					<input type="hidden" name="id" value="<?php echo e($id); ?>">
				</div>
				
				<div class="form-group">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>