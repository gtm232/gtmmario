<div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="index.html">Sistem Informasi MARIO</a>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <!-- Call Search 
                    <li><a href="javascript:void(0);" class="js-search" data-close="true"><i class="material-icons">search</i></a></li>
                    <!-- #END# Call Search -->
                    <!-- Notifications -->
                    <li class="dropdown">
					<?php
								
								$notif_mea=DB::table('detail_mea')->get();
								$no=1;
							?>
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button">
                            <i class="material-icons">notifications</i>
							<?php
							$npsc=DB::table('history')->where([['status','belum'],['penerima',Auth::user()->id],])->count();
							$nps=DB::table('history')->where([['status','belum'],['penerima',Auth::user()->id],])->get();
							?>
                            <span class="label-count"><?php echo e($npsc); ?></span>
                        </a>
                        <ul class="dropdown-menu">
							
                            <li class="header">NOTIFICATIONS</li>
                            <li class="body">
                                <ul class="menu">
								
									<?php $__currentLoopData = $notif_mea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif_mea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php
									$mi=DB::table('mea')->where('id',$notif_mea->id_mea)->get()->first();
									?>
									<?php if($notif_mea->notifikasi == "BBS"): ?>
										
										<?php if($mi->penyusun1 == Auth::user()->id  or $mi->penyusun2 == Auth::user()->id): ?>
										<?php	
										if($mi->penyusun1 == Auth::user()->id){
											$tanda=1;
										}else if($mi->penyusun2 == Auth::user()->id){
											$tanda=2;
										}
										?>	
											<li>
												<a href="javascript:" onclick="document.getElementById('notif<?php echo e($no); ?>').submit()">
													<div class="icon-circle bg-light-green">
														<i class="material-icons">comment</i>
													</div>
													<div class="menu-info">
														<h4><?php echo e($notif_mea->temuan); ?></h4>
													   <!-- <p>
															<i class="material-icons">access_time</i> 14 mins ago
														</p> -->
													</div>
												</a>
												
												<div style="display:none;">
													<form id="notif<?php echo e($no); ?>" action="<?php echo url('/notifikasi'); ?>" method="post">
														<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
														<input type="hidden" name="id_mea" value="<?php echo e($notif_mea->id_mea); ?>">
														<input type="hidden" name="id_detail_mea" value="<?php echo e($notif_mea->id); ?>">
														<input type="hidden" name="tanda" value="<?php echo e($tanda); ?>">
														<input type="hidden" name="status" value="BBS">
													<button type="submit" class="btn btn-primary">save</button></a>
													</form>
												</div>
											</li>
										<?php endif; ?>
										
									<?php elseif($notif_mea->notifikasi == "BS1"): ?>
									
										<?php if($notif_mea->status_penindaklanjut == "BB"): ?>
											<li>
												<a href="javascript:" onclick="document.getElementById('notif<?php echo e($no); ?>').submit()">
													<div class="icon-circle bg-light-green">
														<i class="material-icons">comment</i>
													</div>
													<div class="menu-info">
														<h4><?php echo e($notif_mea->temuan); ?></h4>
													   <!-- <p>
															<i class="material-icons">access_time</i> 14 mins ago
														</p> -->
													</div>
												</a>
												
												<div style="display:none;">
													<form id="notif<?php echo e($no); ?>" action="<?php echo url('/notif_penindaklanjut'); ?>" method="post">
														<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
														<input type="hidden" name="id_mea" value="<?php echo e($notif_mea->id_mea); ?>">
														<input type="hidden" name="id_detail_mea" value="<?php echo e($notif_mea->id); ?>">
														<input type="hidden" name="status_penindaklanjut" value="SB">
														
													<button type="submit" class="btn btn-primary">save</button></a>
													</form>
												</div>
											</li>
										<?php endif; ?>
									
									<?php elseif($notif_mea->notifikasi == "BS2"): ?>
									
										<?php if($mi->penyusun2 == Auth::user()->id): ?>
											<li>
												<a href="javascript:" onclick="document.getElementById('notif<?php echo e($no); ?>').submit()">
													<div class="icon-circle bg-light-green">
														<i class="material-icons">comment</i>
													</div>
													<div class="menu-info">
														<h4><?php echo e($notif_mea->temuan); ?></h4>
													   <!-- <p>
															<i class="material-icons">access_time</i> 14 mins ago
														</p> -->
													</div>
												</a>
												
												<div style="display:none;">
													<form id="notif<?php echo e($no); ?>" action="<?php echo url('/notifikasi'); ?>" method="post">
														<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
														<input type="hidden" name="id_mea" value="<?php echo e($notif_mea->id_mea); ?>">
														<input type="hidden" name="id_detail_mea" value="<?php echo e($notif_mea->id); ?>">
														<input type="hidden" name="tanda" value="2">
														<input type="hidden" name="status_" value="BS2">
													<button type="submit" class="btn btn-primary">save</button></a>
													</form>
												</div>
											</li>
										<?php endif; ?>
									<?php endif; ?>
									
									<?php if($notif_mea->penindak_lanjut == Auth::user()->id): ?>
									
										<?php if($notif_mea->status_penindaklanjut == "BB"): ?>
											<li>
												<a href="javascript:" onclick="document.getElementById('notif2<?php echo e($no); ?>').submit()">
													<div class="icon-circle bg-light-green">
														<i class="material-icons">comment</i>
													</div>
													<div class="menu-info">
														<h4><?php echo e($notif_mea->temuan); ?></h4>
													   <!-- <p>
															<i class="material-icons">access_time</i> 14 mins ago
														</p> -->
													</div>
												</a>
												
												<div style="display:none;">
													<form id="notif2<?php echo e($no); ?>" action="<?php echo url('/notif_penindaklanjut'); ?>" method="post">
														<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
														<input type="hidden" name="id_mea" value="<?php echo e($notif_mea->id_mea); ?>">
														<input type="hidden" name="id_detail_mea" value="<?php echo e($notif_mea->id); ?>">
														<input type="hidden" name="id_user" value="<?php echo e(Auth::user()->id); ?>">
														<input type="hidden" name="status_penindaklanjut" value="SB">
													<button type="submit" class="btn btn-primary">save</button></a>
													</form>
												</div>
											</li>
									
										<?php endif; ?>
									<?php endif; ?>
									
									
									<?php $no++; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								   
								   <?php $__currentLoopData = $nps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								   <?php
								   $noo=1;
								   ?>
										<li>
												<a href="javascript:" onclick="document.getElementById('nps<?php echo e($noo); ?>').submit()">
													<div class="icon-circle bg-light-green">
													<?php
													$nh=DB::table('pembuatan_surat')->where('id',$nps->id_pembuatan_surat)->get()->first();
													?>
														<i class="material-icons"><i class="material-icons">alarm</i></i>
													</div>
													<div class="menu-info">
														<h4><?php echo e($nh->perihal); ?></h4>
													   <!-- <p>
															<i class="material-icons">access_time</i> 14 mins ago
														</p> -->
													</div>
												</a>
												
												<div style="display:none;">
													<form id="nps<?php echo e($noo); ?>" action="<?php echo url('/notif_histori'); ?>" method="post">
														<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
														<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($nh->id_laporan_pekerjaan); ?>">
														<input type="hidden" name="id" value="<?php echo e($nps->id); ?>">
														<input type="hidden" name="id_pembuatan_surat" value="<?php echo e($nh->id); ?>">
													<button type="submit" class="btn btn-primary">save</button></a>
													</form>
												</div>
											</li>
									<?php $noo++; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
                                </ul>
                            </li>
                            <li class="footer">
                                <!--<a href="javascript:void(0);">View All Notifications</a>-->
                            </li>
                        </ul>
                    </li>
                    <!-- #END# Notifications -->
                    <!-- Tasks 
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button">
                            <i class="material-icons">flag</i>
                            <span class="label-count">9</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="header">TASKS</li>
                            <li class="body">
                                <ul class="menu tasks">
                                    <li>
                                        <a href="javascript:void(0);">
                                            <h4>
                                                Footer display issue
                                                <small>32%</small>
                                            </h4>
                                            <div class="progress">
                                                <div class="progress-bar bg-pink" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 32%">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <h4>
                                                Make new buttons
                                                <small>45%</small>
                                            </h4>
                                            <div class="progress">
                                                <div class="progress-bar bg-cyan" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 45%">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <h4>
                                                Create new dashboard
                                                <small>54%</small>
                                            </h4>
                                            <div class="progress">
                                                <div class="progress-bar bg-teal" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 54%">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <h4>
                                                Solve transition issue
                                                <small>65%</small>
                                            </h4>
                                            <div class="progress">
                                                <div class="progress-bar bg-orange" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 65%">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);">
                                            <h4>
                                                Answer GitHub questions
                                                <small>92%</small>
                                            </h4>
                                            <div class="progress">
                                                <div class="progress-bar bg-purple" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 92%">
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="footer">
                                <a href="javascript:void(0);">View All Tasks</a>
                            </li>
                        </ul>
                    </li>
                     #END# Tasks
                    <li class="pull-right"><a href="javascript:void(0);" class="js-right-sidebar" data-close="true"><i class="material-icons">more_vert</i></a></li>
                 --></ul>
            </div>
        </div>
    </nav>