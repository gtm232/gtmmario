<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Ketentuan Acrue</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                               
			<?php if(Auth::user()->hak_akses == "admin"): ?>			
             <a href="<?php echo e(route('acrue.create')); ?>" ><button class="btn btn-info">Tambah</button></a>
					<br>
            <?php endif; ?>
          
			<br>
            <div class="card-body ">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Tahun</th>
                      <th>Dari</th>
                      <th>Sampai</th>
                      
                      <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>Opsi</th>
					  <?php endif; ?>
					  
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php $no=1; ?>
				  <?php $__currentLoopData = $acrue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
					
					  <td><?php echo e($ac->tahun); ?></td>
                      <td><?php echo e($ac->tanggal_mulai); ?></td>
                      <td><?php echo e($ac->tanggal_akhir); ?></td>
					  
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td>
					 
					 <a  style="float:left; margin-right:5px;" href="<?php echo e(route('acrue.edit',$ac->id)); ?>"><button class="btn btn-primary">Edit</button></a>
					  
					<form method="post" action="<?php echo e(route('acrue.destroy',$ac->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					  </td>
					  <?php endif; ?>
					  
                    </tr>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>