<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
				

                <div class="row page-titles">
                    <div class="col-md-12 col-12 align-self-center" style="text-align:center; margin-bottom:10px;">
                        <h3 class="text-themecolor m-b-0 m-t-0">Laporan Pekerjaan</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
			<?php if(!isset($hanya_saya)): ?>
            <form style="float:left; margin:5px;" action="<?php echo url('/hanya_saya'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<button type="submit" class="btn btn-primary">Pekerjaan Saya</button></a>
			</form>
			<?php else: ?>
				<a style="float:left; margin:5px;" href="<?php echo url('/pekerjaan'); ?>" class="waves-effect"><button class="btn btn-info">Semua Pekerjaan</button></a>
				
			<?php endif; ?>
			
					
             <a style="float:left; margin:5px;" href="<?php echo e(route('pekerjaan.create')); ?>" ><button class="btn btn-info">Tambah</button></a>
					<br>
			
          
			<br>
            <div class="card-body ">
              <div class="table-responsive" style="margin:20px;">
			   <div class="col-12">
			   <?php if(!isset($hanya_saya)): ?>
                   <select name="tahun" onchange="location = this.value;">
                      <option>Tahun</option>
					  <?php $tgl_aw=2018; $tgl_ak=date("Y"); 
                      for($i=$tgl_ak; $i>=$tgl_aw; $i--){
                      ?>
                      <option value="pekerjaan?thn=<?php echo e($i); ?>"><?php echo e($i); ?></option>
                      <?php } ?>
                      
                  </select>
				<select id="dokumen" onchange="dokumen(this.value)">
					<option>Pilih</option>
					<option value="SPK">SPK</option>
					<option value="BAP">BAP</option>
					<option value="BAST">BAST</option>
					<option value="SPP">Tagihan</option>
					
				</select>
				
				<div style="display:none;">
				<form id="bln" action="<?php echo url('/carifile'); ?>" method="post"> 
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="jenisdokumen" id="text" value="">
						<button type="submit" class="btn btn-primary">save</button></a>
				</form>
				</div> 
				<?php else: ?>
					 <select name="tahun" onchange="location = this.value;">
                      <option>Tahun</option>
					  <?php $tgl_aw=2018; $tgl_ak=date("Y"); 
                      for($i=$tgl_ak; $i>=$tgl_aw; $i--){
                      ?>
                      <option value="hanya_saya?thn=<?php echo e($i); ?>"><?php echo e($i); ?></option>
                      <?php } ?>
                      
                  </select>
				 
				</div>
				
				<?php endif; ?>
				<br>
				<br>
                <table style="font-size:10px;" class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>No</th>
					  <th>Nama Pekerjaan</th>
                      <th>Tanggal Mulai</th>
					  <th>Tanggal Berakhir</th>
					  <th>PIC</th>
					  <th>Lokasi Arsip</th>
					  <th>Lokasi Pekerjaan</th>
					  <th>Area Operasi</th>
					  <th>Status</th>
					  <th>Nilai SPK</th>
					  <th>Inisiator Kerja</th>
					  <th>Multi Years</th>
                      
                     
					  <th>Opsi</th>
				
					  
                    </tr>
                  </thead>
                  
                  <tbody>
				 
				  <?php $no=1; 
				  if(isset($pekerjaanaccrue)){
				  $pekerjaan=DB::table('laporan_pekerjaan')->where([[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],[DB::raw('MONTH(tanggal_berakhir)'),12],])->get();
				  }else if(isset($_GET["thn"])){
				  $pekerjaan=DB::table('laporan_pekerjaan')->whereYear('tanggal_mulai','=',$_GET["thn"])->get();
				  }else{
					$pekerjaan=DB::table('laporan_pekerjaan')->get();
				  }
				  ?>
				
				  <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  
				  <?php
				  $pic2=DB::table('users')->where('id','=',$pkn->pic)->get()->first();
				  ?>
				  
				    <?php if(isset($hanya_saya)): ?>
					   <?php if(Auth::user()->id == $pkn->pic): ?>
						<tr>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($no); ?></div></a> </td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->nama_pekerjaan); ?></div></a> </td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(date('d-M-Y',strtotime($pkn->tanggal_mulai))); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(date('d-M-Y',strtotime($pkn->tanggal_berakhir))); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pic2->name); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->lokasi); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->lokasi_pekerjaan); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->area_operasi); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;">
					  <?php 
					  $sp=DB::table('popay')->where('id_laporan_pekerjaan','=',$pkn->id)->orderBy('id', 'DESC')->get()->first();
					  ?>
					  
					  <?php if($sp): ?>
					  <?php echo e($sp->status); ?> <?php echo e($sp->isi_termin); ?>

					  <?php else: ?>
					  <?php echo e($pkn->proses); ?>

					  <?php endif; ?>
					  </div></a></td>
					  <?php
					  $nilai_pekerjaan=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$pkn->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
					  ?>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(number_format($nilai_pekerjaan,2,',','.')); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->inisiator_kerja); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;">
					  <?php if($pkn->my == 0): ?>
					    No
					  <?php else: ?>
						<?php echo e($pkn->my); ?> %
					  <?php endif; ?>
					  </div></a></td>
					  
					  <div style="display:none;">
						<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
						</form>
					  </div>
					  
					  
					 <td>
					<table style="border: 0px;">
					<?php if(Auth::user()->hak_akses == "admin" or Auth::user()->id == $pkn->pic): ?>
					<td style="border: 0px;">
					<a style="float:left; margin-right:5px;" href="<?php echo e(route('pekerjaan.edit',$pkn->id)); ?>"><i class="material-icons">create</i></a>
					</td>
					<td style="border: 0px;">
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('popay<?php echo e($no); ?>').submit()"><i class="material-icons">monetization_on</i></a>  
					<form style="display:none;" id="popay<?php echo e($no); ?>" action="<?php echo url('/popaylist'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">POPAY</button></a>
					</form>
					</td>
					
						
					<?php if(Auth::user()->hak_akses == "admin"): ?>
					<td style="border: 0px;">
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('delete<?php echo e($no); ?>').submit()"><i class="material-icons">delete</i></a>
					<form style="display:none;" id="delete<?php echo e($no); ?>" method="post" action="<?php echo e(route('pekerjaan.destroy',$pkn->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					</td>
					
					<?php endif; ?>
					<?php endif; ?>
					</table> 
					</td>
					 
					  <?php $no++; ?>
                    </tr>
					<?php endif; ?>
				   
                    <?php elseif(isset($carifile)): ?>
							<?php 
							$cf=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$pkn->id],['jenis_dokumen',$carifile],])->get()->count();
							?>
								<?php if($cf >= 1): ?>
								  <tr>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($no); ?></div></a> </td>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->nama_pekerjaan); ?></div></a> </td>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(date('d-M-Y',strtotime($pkn->tanggal_mulai))); ?></div></a></td>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(date('d-M-Y',strtotime($pkn->tanggal_berakhir))); ?></div></a></td>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pic2->name); ?></div></a></td>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->lokasi); ?></div></a></td>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->lokasi_pekerjaan); ?></div></a></td>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->area_operasi); ?></div></a></td>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;">
								  <?php 
								  $sp=DB::table('popay')->where('id_laporan_pekerjaan','=',$pkn->id)->orderBy('id', 'DESC')->get()->first();
								  ?>
								  
								  <?php if($sp): ?>
								  <?php echo e($sp->status); ?> <?php echo e($sp->isi_termin); ?>

								  <?php else: ?>
								  <?php echo e($pkn->proses); ?>

								  <?php endif; ?>
								  </div></a></td>
								  <?php
								  $nilai_pekerjaan=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$pkn->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
								  ?>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(number_format($nilai_pekerjaan,2,',','.')); ?></div></a></td>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->inisiator_kerja); ?></div></a></td>
								  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;">
								  <?php if($pkn->my == 0): ?>
									No
								  <?php else: ?>
									<?php echo e($pkn->my); ?> %
								  <?php endif; ?>
								  </div></a></td>
								  
								  <div style="display:none;">
									<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/dokumen_pekerjaan'); ?>" method="post">
									<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
									<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
									<button type="submit" class="btn btn-primary">save</button></a>
									</form>
								  </div>
								  <?php $no++; ?>
								 
								 <td>
					<table style="border: 0px;">
					<?php if(Auth::user()->hak_akses == "admin" or Auth::user()->id == $pkn->pic): ?>
					<td style="border: 0px;">
					<a style="float:left; margin-right:5px;" href="<?php echo e(route('pekerjaan.edit',$pkn->id)); ?>"><i class="material-icons">create</i></a>
					</td>
					<td style="border: 0px;">
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('popay<?php echo e($no); ?>').submit()"><i class="material-icons">monetization_on</i></a>  
					<form style="display:none;" id="popay<?php echo e($no); ?>" action="<?php echo url('/popaylist'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">POPAY</button></a>
					</form>
					</td>
					
						
					<?php if(Auth::user()->hak_akses == "admin"): ?>
					<td style="border: 0px;">
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('delete<?php echo e($no); ?>').submit()"><i class="material-icons">delete</i></a>
					<form style="display:none;" id="delete<?php echo e($no); ?>" method="post" action="<?php echo e(route('pekerjaan.destroy',$pkn->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					</td>
					
					<?php endif; ?>
					<?php endif; ?>
					</table> 
					</td>
								 
								 
								</tr>
							<?php endif; ?>
					<?php else: ?> 
					<tr>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($no); ?></div></a> </td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->nama_pekerjaan); ?></div></a> </td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(date('d-M-Y',strtotime($pkn->tanggal_mulai))); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(date('d-M-Y',strtotime($pkn->tanggal_berakhir))); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pic2->name); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->lokasi); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->lokasi_pekerjaan); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->area_operasi); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;">
					  <?php 
					  $sp=DB::table('popay')->where('id_laporan_pekerjaan','=',$pkn->id)->orderBy('id', 'DESC')->get()->first();
					  ?>
					  
					  <?php if($sp): ?>
					  <?php echo e($sp->status); ?> <?php echo e($sp->isi_termin); ?>

					  <?php else: ?>
					  <?php echo e($pkn->proses); ?>

					  <?php endif; ?>
					  </div></a></td>
					  <?php
					  $nilai_pekerjaan=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$pkn->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
					  ?>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(number_format($nilai_pekerjaan,2,',','.')); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->inisiator_kerja); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;">
					  <?php if($pkn->my == 0): ?>
					    No
					  <?php else: ?>
						<?php echo e($pkn->my); ?> %
					  <?php endif; ?>
					  </div></a></td>
                      
					  <div style="display:none;">
						<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
						</form>
					  </div>
					  <?php $no++; ?>
					 
					  <td>
					<table style="border: 0px;">
					<?php if(Auth::user()->hak_akses == "admin" or Auth::user()->id == $pkn->pic): ?>
					<td style="border: 0px;">
					<a style="float:left; margin-right:5px;" href="<?php echo e(route('pekerjaan.edit',$pkn->id)); ?>"><i class="material-icons">create</i></a>
					</td>
					<td style="border: 0px;">
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('popay<?php echo e($no); ?>').submit()"><i class="material-icons">monetization_on</i></a>  
					<form style="display:none;" id="popay<?php echo e($no); ?>" action="<?php echo url('/popaylist'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">POPAY</button></a>
					</form>
					</td>
					
						
					<?php if(Auth::user()->hak_akses == "admin"): ?>
					<td style="border: 0px;">
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('delete<?php echo e($no); ?>').submit()"><i class="material-icons">delete</i></a>
					<form style="display:none;" id="delete<?php echo e($no); ?>" method="post" action="<?php echo e(route('pekerjaan.destroy',$pkn->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					</td>
					
					<?php endif; ?>
					<?php endif; ?>
					</table> 
					</td>
					 
					 
                    </tr>
					<?php endif; ?>
					
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<script type="text/javascript">
   function dokumen(value) {
	  
	$('#text').val(value);
	document.getElementById('bln').submit()
}
</script> 
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>