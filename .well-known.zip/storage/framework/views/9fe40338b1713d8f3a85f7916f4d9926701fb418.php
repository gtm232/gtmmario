<?php $__env->startSection('content'); ?>

<div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Data User</h3>
                        
                    </div>
                   
                </div>

<!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
<?php if(Auth::user()->hak_akses == "admin"): ?>
				<div class="row" style="margin-bottom:5px;">
					<div class="col-md-12">	
					<form style="float:left; margin-right:5px;" action="<?php echo url('/tambah_user'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<button type="submit" class="btn btn-primary">Tambah</button></a>
					</form>
					</div>
				</div>
<?php endif; ?>

            <div class="card-body ">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Nama</th>
					  <th>Username</th>
                      <th>Email</th>
                      <th>Hak Akses</th>
                      <th>Gambar</th>
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>Opsi</th>
					<?php endif; ?>
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($user->name); ?></td>
					  <td><?php echo e($user->username); ?></td>
                      <td><?php echo e($user->email); ?></td>
                      <td><?php echo e($user->hak_akses); ?></td>
                      <td><img width="40px" height="40px" src="<?php echo e(url('/')); ?>/img/gambar/<?php echo e($user->gambar); ?>"></td>
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td>
					  <form style="float:left; margin-right:5px;" action="<?php echo url('/edit_user'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_user" value="<?php echo e($user->id); ?>">
					  <button  type="submit" class="btn btn-warning">Edit</button>
					  </form>
					  <form style="float:left; margin-right:5px;" action="<?php echo url('/hapus_user'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_user" value="<?php echo e($user->id); ?>">
						<input type="hidden" name="gambar" value="<?php echo e($user->gambar); ?>">
					  <button type="submit" class="btn btn-danger">Hapus</button>
					  </form>
					  </td>
					  <?php endif; ?>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              
            </div>
          </div>
							</div>
                        </div>
                    </div>
                </div>
	 
	 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>