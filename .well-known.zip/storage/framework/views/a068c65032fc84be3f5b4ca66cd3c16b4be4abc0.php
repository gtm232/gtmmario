<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Edit Data</h2>
			<form class="form-group" action="<?php echo url('/edit_dokumen_pekerjaan_proses'); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				<?php $pkn = DB::table('dokumen_laporan_pekerjaan')->where('id', '=', $id)->get()->first(); ?>
				
				<div class="form-group">
					<label for="isi">No Surat</label>
					<input type="text" name="no_surat" class="form-control" value="<?php echo e($pkn->no_surat); ?>" required="required">
					<input type="hidden" name="id_laporan_pekerjaan" class="form-control" value="<?php echo e($id_laporan_pekerjaan); ?>">
					<input type="hidden" name="file_old" class="form-control" value="<?php echo e($pkn->nama_dokumen_pekerjaan); ?>">
					<input type="hidden" name="id" class="form-control" value="<?php echo e($pkn->id); ?>">
				</div>
				
				<div class="form-group">
					<label for="isi">Perihal</label>
					<input type="text" name="prihal" class="form-control" value="<?php echo e($pkn->prihal); ?>" required="required">
				</div>
				
				<div class="form-group">
					<label for="isi">Jenis Dokumen</label>
					<select name="jenis_dokumen" class="form-control" id="zoneSelect" onclick="updateChar();" required="required">
						<option value="<?php echo e($pkn->jenis_dokumen); ?>"><?php echo e($pkn->jenis_dokumen); ?></option>
						<option value="SPPH">SPPH</option>
						<option value="SPH">SPH</option>
						<option value="Undangan Nego">Undangan Nego</option>
						<option value="BA Nego">BA Nego</option>
						<option value="SPK">SPK</option>
						<option value="LPS">LPS</option>
						<option value="BAP">BAP</option>
						<option value="BAST">BAST</option>
						<option value="SPP">SPP</option>
						<option value="Surat Masuk">Surat Masuk</option>
						<option value="Surat Keluar">Surat Keluar</option>
					</select>
				</div>
				
				<div style="display:none;" id="harga1" class="form-group">
					<label for="judul">Harga</label>
					<input type="text" id="harga" name="harga" class="form-control" >
					<input type="hidden" name="harga_old" value="<?php echo e($pkn->harga_pekerjaan); ?>" class="form-control" >
					<input type="hidden" name="nama_folder" value="<?php echo e($pkn->nama_folder); ?>" class="form-control" >
					
				</div>
				
				<div class="form-group">
					<label >Tanggal Mulai</label>
					  <input style="background:#ffff;" type="text" class="form-control" id="tgl" autocomplete="off" name="tanggal" value="<?php echo date('d F Y',strtotime ($pkn->tanggal)) ; ?>" readonly>
					
				</div>
				
				<div class="form-group">
					<label for="exampleInputPassword1">File</label>
					<input type="file" class="form-control" name="file" onchange="validasiFile()" id="file" >
				</div>
				
				<div class="form-group">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>

<script>
function validasiFile(){
    var inputFile = document.getElementById('file');
    var pathFile = inputFile.value;
    var ekstensiOk = /(\.pdf|\.PDF)$/i;
    if(!ekstensiOk.exec(pathFile)){
        alert('Silakan upload file yang memiliki ekstensi mp4');
        inputFile.value = '';
        return false;
    }else{
        //Pratinjau gambar
        
    }
}

function updateChar() {

    var zone = document.getElementById("zoneSelect");

    if (zone.value == "SPK"){
		$("#harga1").fadeIn(1000);
    }else if (zone.value == "SPP"){
		$("#harga1").fadeIn(1000);
    }else{
		$("#harga1").fadeOut(1000);
		document.getElementById("harga").value = "";;
		
	}
}


</script>
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>