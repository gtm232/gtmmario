<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
				<?php 
				  $dokumen_laporan_bulanan=DB::table('dokumen_laporan_bulanan')->where('id','=',$id)->get()->first();
				?>
                <div class="row page-titles">
                    <div class="col-md-11 col-11 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0"><?php echo e($dokumen_laporan_bulanan->prihal); ?></h3>
                        
                    </div>
					<div class="col-md-1 col-1 align-self-center">
                        <a href="javascript:" class="waves-effect" data-toggle="modal" data-target="#exampleModalLong"><i class="fa fa-paperclip m-r-10" aria-hidden="true"></i></a>
                        
						<!-- Modal -->
								<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
								  <div class="modal-dialog" role="document">
									<div class="modal-content">
									  <div class="modal-header">
										<h5 class="modal-title" id="exampleModalLongTitle">Attach</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										  <span aria-hidden="true">&times;</span>
										</button>
									  </div>
											  <div class="modal-body">
												<div class="table-responsive">
												<form style=" margin-right:0px 5px 10px;" action="<?php echo url('/attach'); ?>" method="post">
															<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
															<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
															<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
															<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
															<input type="hidden" name="id" value="<?php echo e($id); ?>">
															<button type="submit" class="btn btn-info">Tambah</button></a>
												</form>
													<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
													  <thead>
														<tr>
														  <th>Dokumen</th>
											
														  <th>Opsi</th>
														</tr>
													  </thead>
													  
													  <?php $lampiran=DB::table('attach')->where([['id_laporan_bulanan',$id_laporan_bulanan],['id_jenis_laporan',$id_jenis_laporan],['id_wilayah_operasi',$id_wilayah_operasi],])->get(); ?>
													  <tbody>
														<?php $__currentLoopData = $lampiran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														
														<tr>
														<td><?php echo e($lam->nama_dokumen); ?></td>
														
														<td>
														<form style="float:left; margin-right:5px;" method="post" action="<?php echo url('/hapus_attach'); ?>">
															<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
															<input type="hidden" name="id_attach" value="<?php echo e($lam->id); ?>">
															<input type="hidden" name="id" value="<?php echo e($id); ?>">
															<input type="hidden" name="nama_dokumen" value="<?php echo e($lam->nama_dokumen); ?>">
															<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
															<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
															<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
															<input type="submit" class="btn btn-danger" value="Delete" />
														
														</form>
														
														<a style="float:left;" href="<?php echo URL::to('/'); ?>/laporan_bulanan/<?php echo e($lam->nama_dokumen); ?>" download><button class="btn btn-info">Download</button></a>
														</td>
														</tr>
														
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													  </tbody>
													</table>
												</div>
											  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
									  </div>
									</div>
								  </div>
								</div>
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                               
			<?php $dokumen_laporan_bulanan2=DB::table('dokumen_laporan_bulanan')->where([['id_laporan_bulanan',$id_laporan_bulanan],['jenis_laporan',$id_jenis_laporan],['wilayah_operasi',$id_wilayah_operasi],])->get(); ?>
            <div class="card-body ">
				<select class="form-control" id="dokumen" onchange="dokumen(this.value)">
					<option value="0">-- Silahkan Pilih --</option>
					<?php $__currentLoopData = $dokumen_laporan_bulanan2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dlb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($dlb->id); ?>"><?php echo e($dlb->prihal); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				
				<div style="display:none;">
				<form id="bln" action="<?php echo url('/lihat_dokumen_bulanan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
						<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
						<input type="hidden" name="id" id="text" value="">
						<button type="submit" class="btn btn-primary">save</button></a>
				</form>
				</div>
			
			<iframe width="100%" height="700" src="<?php echo URL::to('/'); ?>/laporan_bulanan/<?php echo e($dokumen_laporan_bulanan->nama_dokumen_laporan); ?>">
			</iframe>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<script type="text/javascript">
   function dokumen(value) {
	  
	$('#text').val(value);
	document.getElementById('bln').submit()
}
</script>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>