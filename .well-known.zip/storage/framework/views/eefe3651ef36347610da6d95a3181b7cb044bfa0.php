<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">POPAY</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                   
			<?php if(Auth::user()->hak_akses == "admin"): ?>			
				<form style="float:left;" action="<?php echo url('/popay'); ?>" method="post">
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
							<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
							<button type="submit" class="btn btn-primary">POPAY</button></a>
				</form>
					<br>
            <?php endif; ?>
          
			<br>
            <div class="card-body ">
              <div class="table-responsive">
                 
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Nomor Pr</th>
					  <th>Tanggal Input</th>
                      <th>Rupiah</th>
					  <th>Status</th>
                      <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>Opsi</th>
					  <?php endif; ?>
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php $no=1; ?>
				  <?php $__currentLoopData = $popaylist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popaylist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				   
                    <tr>
					  <td><?php echo e($popaylist->nomor_pr); ?></td>
					  <td><?php echo e($popaylist->tanggal_input); ?></td>
					  <td><?php echo e($popaylist->rupiah); ?></td>
					  <td><?php echo e($popaylist->status); ?></td>
					
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td >
							<form style="float:left; margin-right:5px;" action="<?php echo url('/popay_hapus'); ?>" method="post">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id" value="<?php echo e($popaylist->id); ?>">
								<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
								<button type="submit" class="btn btn-danger">Hapus</button></a>
							</form>
							
							<form style="float:left;" action="<?php echo url('/popay_paid'); ?>" method="post">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id" value="<?php echo e($popaylist->id); ?>">
								<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
								<button type="submit" class="btn btn-success">Paid</button></a>
							</form>
					  </td>
					  <?php endif; ?>
                    </tr>
					
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>