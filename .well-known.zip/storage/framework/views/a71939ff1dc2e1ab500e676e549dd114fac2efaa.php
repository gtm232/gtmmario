<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Laporan Bulanan</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                               
						
             <a href="<?php echo e(route('bulanan.create')); ?>" ><button class="btn btn-info">Tambah</button></a>
					<br>
          
			<br>
            <div class="card-body ">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Tahun</th>
                      <th>Bulan</th>
                      
                      <th>Lokasi Arsip</th>
                      
					  <th>Opsi</th>
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php $no=1; ?>
				  <?php $__currentLoopData = $bulanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
					
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($bln->tahun); ?></div></a> </td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($bln->bulan); ?></div></a></td>
                      
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($bln->arsip); ?></div></a></td>
                      
					  <div style="display:none;">
					  <form id="dbln<?php echo e($no); ?>" action="<?php echo url('/jenis_laporan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($bln->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
					</form>
					  </div>
					  <td>
					 
					 <a  style="float:left; margin-right:5px;" href="<?php echo e(route('bulanan.edit',$bln->id)); ?>"><button class="btn btn-primary">Edit</button></a>
					  
					  <form method="post" action="<?php echo e(route('bulanan.destroy',$bln->id)); ?>">
					<input type="hidden" name="_method" value="DELETE">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="submit" class="btn btn-danger" value="Delete" />
				</form>
					  </td>
                    </tr>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>