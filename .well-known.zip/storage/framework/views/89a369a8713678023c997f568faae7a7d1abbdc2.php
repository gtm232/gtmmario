<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Edit Data</h2>
			<form class="form-group" action="<?php echo url('/edit_file_pembuatan_surat_proses'); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				<?php if(Auth::user()->hak_akses == "admin"): ?>
				<div class="form-group">
					<label for="isi">Perihal</label>
					<input type="text" name="perihal" class="form-control" value="<?php echo e($edit_file_pembuatan_surat->perihal); ?>" required="required">
					<input type="hidden" name="id" class="form-control" value="<?php echo e($edit_file_pembuatan_surat->id); ?>">
					<input type="hidden" name="id_pembuatan_surat" class="form-control" value="<?php echo e($id_pembuatan_surat); ?>">
				</div>
				<?php endif; ?>
				
				<?php if(Auth::user()->hak_akses == "user"): ?>
				<div class="form-group">
					<input type="hidden" name="perihal" class="form-control" value="<?php echo e($edit_file_pembuatan_surat->perihal); ?>" required="required">
					<input type="hidden" name="id" class="form-control" value="<?php echo e($edit_file_pembuatan_surat->id); ?>">
					<input type="hidden" name="id_pembuatan_surat" class="form-control" value="<?php echo e($id_pembuatan_surat); ?>">
					<input style="display:none;" type="file" class="form-control" name="file" onchange="validasiFile()" id="file" >
					<input type="hidden" class="form-control" name="file_old" value="<?php echo e($edit_file_pembuatan_surat->nama_file); ?>" >
				</div>
				<?php endif; ?>
				
				<?php if(Auth::user()->hak_akses == "admin"): ?>
				<div class="form-group">
					<label for="exampleInputPassword1">File</label>
					<input type="file" class="form-control" name="file" onchange="validasiFile()" id="file" >
					<input type="hidden" class="form-control" name="file_old" value="<?php echo e($edit_file_pembuatan_surat->nama_file); ?>" >
				</div>
				<?php endif; ?>
				
				<div class="form-group">
					<label for="isi">Catatan</label>
					<textarea name="catatan" id="catatan">
						<?php echo e($edit_file_pembuatan_surat->catatan); ?>

					</textarea>
					<script>
					CKEDITOR.replace('catatan', {removePlugins: 'about,sourcearea,link,elementspath,image'});
					</script>
				</div>
				
				<div class="form-group">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>

<script>
function validasiFile(){
    var inputFile = document.getElementById('file');
    var pathFile = inputFile.value;
    var ekstensiOk = /(\.pdf|\.PDF)$/i;
    if(!ekstensiOk.exec(pathFile)){
        alert('Silakan upload file yang memiliki ekstensi mp4');
        inputFile.value = '';
        return false;
    }else{
        //Pratinjau gambar
        
    }
}


</script>
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>