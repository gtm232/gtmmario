<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=hasil.xls");
?>
	<table border="1">
        <thead>
            <tr>
                <th bgcolor="yellow">Nama Aset</th>
                <th bgcolor="yellow">Fungsi Aset</th>
                <th bgcolor="yellow">Penyebab</th>
                <th bgcolor="yellow">Ranking</th>
                <th bgcolor="yellow">Rekomendasi</th>
                <th bgcolor="yellow">Due Date</th>
                <th bgcolor="yellow">PIC</th>
                <th bgcolor="yellow">Status</th>
            </tr>
        </thead>
            <?php
				$detail_mea=DB::table("detail_mea")->where('id_mea',$_GET["id_mea"])->get();
			?>
			<?php $__currentLoopData = $detail_mea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_mea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($detail_mea->nama_aset); ?></td>
				<td><?php echo e($detail_mea->fungsi_aset); ?></td>
				<td><?php echo e($detail_mea->penyebab); ?></td>
				<td><?php echo e($detail_mea->ranking); ?></td>
				<td><?php echo e($detail_mea->rekomendasi); ?></td>
				<td><?php echo e(date('d-M-Y',strtotime($detail_mea->duedate))); ?></td>
				<td><?php echo e($detail_mea->pic); ?></td>
				<td><?php echo e($detail_mea->status); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>