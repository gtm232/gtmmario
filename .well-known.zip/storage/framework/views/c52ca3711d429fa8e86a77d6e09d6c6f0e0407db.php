<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Pembuatan Surat</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                               
					
             <a href="<?php echo e(route('pembuatan_surat.create')); ?>" ><button class="btn btn-info">Tambah</button></a>
					<br>
          
          
			<br>
            <div class="card-body ">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Nama Pekerjaan</th>
                      <th>Jenis Pekerjaan</th>
					  <th>Catatan</th>
                      <th>Status</th>
					  
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>PIC</th>  
                      <?php endif; ?>
                      
					  <th>Opsi</th>
					
					  
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php $no=1; ?>
				  <?php $__currentLoopData = $pembuatan_surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
				  <?php $catatan=$pbs->catatan;?>
                    <tr>
					
					  <td><?php echo e($pbs->nama_pekerjaan); ?></td>
                      <td><?php echo e($pbs->jenis_pekerjaan); ?></td>
                      <td><div style="clear:both;"><?php echo $catatan;?></div></td>
					  <td><?php echo e($pbs->status); ?></td>
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
						<?php $pic=DB::table('users')->where('id','=',$pbs->nama_user)->get()->first(); ?>
					  <td><?php echo e($pic->name); ?></td>  
                      <?php endif; ?>
					 
					 
					<td>
					 
					<?php if(Auth::user()->hak_akses == "user" and $pbs->status == "Belum Konfirmasi"): ?>
					<a  style="margin-right:5px; float:left" href="<?php echo e(route('pembuatan_surat.edit',$pbs->id)); ?>"><button class="btn btn-primary">Edit</button></a>
					<?php endif; ?>
					
					 
					<?php if(Auth::user()->hak_akses == "user" and $pbs->status == "Belum Konfirmasi"): ?> 
					<form method="post" style=" margin-right:5px; float:left" action="<?php echo e(route('pembuatan_surat.destroy',$pbs->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					<?php endif; ?>
					
					<?php if(Auth::user()->hak_akses == "admin"): ?> 
					<form method="post" style=" margin-right:5px; float:left" action="<?php echo e(route('pembuatan_surat.destroy',$pbs->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					<?php endif; ?>
					
					<?php if(Auth::user()->hak_akses == "admin" and $pbs->status == "Belum Konfirmasi"): ?>
					<a  style="float:left; margin-right:5px;" href="<?php echo e(route('pembuatan_surat.show',$pbs->id)); ?>"><button class="btn btn-primary">konfirmasi</button></a>
					<?php endif; ?>
					
					<?php if(Auth::user()->hak_akses == "admin"): ?>
					<?php if($pbs->status == "Sedang Dikerjakan" or $pbs->status == "Revisi"): ?>
					<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/selesai_pembuatan_surat');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
					<input type="submit" class="btn btn-success" value="Selesai" />
					</form>
					<?php endif; ?>
					<?php endif; ?>
					
					<?php if(Auth::user()->hak_akses == "user" and $pbs->status == "Pemeriksaan Oleh PIC"): ?>
					<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/revisi');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
					<input type="submit" class="btn btn-danger" value="Revisi" />
					</form>
					<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/ok');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
					<input type="submit" class="btn btn-success" value="OK" />
					</form>
					<?php endif; ?>
					
					<?php if(Auth::user()->hak_akses == "admin" and $pbs->status == "Proses TTD"): ?>
					<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/arsip');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
					<input type="submit" class="btn btn-success" value="Arsipkan" />
					</form>
					<?php endif; ?>
					
					
						
						<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/file_pembuatan_surat');?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
						<input type="submit" class="btn btn-warning" value="File" />
						</form>
						
					<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/lihat_pembuatan_surat');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
					<input type="submit" class="btn btn-primary" value="Lihat" />
					</form>
						
					
					</td>
				
					  
                    </tr>
					<?php $no++; $catatan=$pbs->catatan;?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
				
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>