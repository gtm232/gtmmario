<?php $__env->startSection('content'); ?>
<div class="container">
		<div class="col-md-12">
			<!-- content -->
			<h2>Menu Add Data</h2>
			<form class="form-group" action="<?php echo e(route('bulanan.update',$bulanan->id)); ?>" method="post">
				<input type="hidden" name="_method" value="PUT">
				<?php echo e(csrf_field()); ?>

				<div class="form-group">
					<label for="judul">Bulan</label>
					<select name="bulan" class="form-control ">
						<option value="<?php echo e($bulanan->bulan); ?>"><?php echo e($bulanan->bulan); ?></option>
						
						
						<option value="Januari">Januari</option>
						<option value="Februari">Februari</option>
						<option value="Maret">Maret</option>
						<option value="April">April</option>
						<option value="Mei">Mei</option>
						<option value="Juni">Juni</option>
						<option value="Juli">Juli</option>
						<option value="Agustus">Agustus</option>
						<option value="September">September</option>
						<option value="Oktober">Oktober</option>
						<option value="November">November</option>
						<option value="Desember">Desember</option>
					</select>
				</div>
				<div class="form-group">
					<label for="headline">Tahun</label>
					<select name="tahun" class="form-control">
						<option value="<?php echo e($bulanan->tahun); ?>"><?php echo e($bulanan->tahun); ?></option>
						<?php
						$thn_skr = date('Y');
						for ($x = $thn_skr; $x >= 2010; $x--) {
							
						?>
							<option value="<?php echo $x ?>"><?php echo $x ?></option>
						<?php
						} 
						?>
					</select>
				</div>
				<div class="form-group">
					<label for="isi">Lokasi Arsip</label>
					<input type="text" name="arsip" class="form-control" value="<?php echo e($bulanan->arsip); ?>" required="required">
				</div>
				<div class="form-group">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>