
<?php $__env->startSection('content'); ?>

	<?php $user = DB::table('users')->where('id','=',$id_user)->get()->first(); ?>
					<form class="form-group" action="<?php echo url('/edit_user_proses'); ?>" method="post" enctype='multipart/form-data'>
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_user" value="<?php echo e($user->id); ?>">
						
						<div class="form-group">
							<label for="exampleInputPassword1">Nama</label>
							<input type="text" class="form-control" name="nama" value="<?php echo e($user->name); ?>" required>
						</div>
						
						<div class="form-group">
							<label for="exampleInputPassword1">Username</label>
							<input type="text" class="form-control" name="username" value="<?php echo e($user->username); ?>" required>
						</div>
						
						<div class="form-group">
							<label for="exampleInputPassword1">Email</label>
							<input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>" required>
						</div>
						
						<div class="form-group">
							<label for="exampleInputPassword1">Hak Akses</label>
							<select class="form-control" name="hak_akses" required>
								<option value="<?php echo e($user->hak_akses); ?>"><?php echo e($user->hak_akses); ?></option>
								<option value="admin">Admin</option>
								<option value="user">User</option>
							</select>
						</div>
						
						<div class="form-group">
							<label for="exampleInputPassword1">Password (Kosongkan jika tidak dirubah)</label>
							<input type="text" class="form-control" name="password" value="" >
							<input type="hidden" name="old_password" value="<?php echo e($user->password); ?>">
						</div>
						
						<div class="form-group">
							<label for="exampleInputPassword1">Gambar (Kosongkan jika tidak dirubah)</label>
							<input type="file" class="form-control" name="gambar" >
							<input type="hidden" name="old_gambar" value="<?php echo e($user->gambar); ?>">
						</div>
						
						<button type="submit" class="btn btn-success">Save</button>
					</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>