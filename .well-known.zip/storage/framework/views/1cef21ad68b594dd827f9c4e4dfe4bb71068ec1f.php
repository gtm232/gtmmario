<?php $__env->startSection('content'); ?>

	<div class="row">
	<h2 align="center">Tambah Data</h2><br>
		<div class="col-md-12">
			<!-- content -->
			
			<form class="form-line" action="<?php echo e(route('pekerjaan.store')); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<div class="form-line">
					<label for="isi">Nama Pekerjaan</label>
					<input type="text" name="nama_pekerjaan" class="form-control" required="required">
				</div>
				
				<?php
					if(Auth::user()->hak_akses ==  "admin"){
				?>
				<div class="form-line">
					<label for="isi">Lokasi Arsip</label>
					<input type="text" name="lokasi" class="form-control" required="required">
				</div>
				<?php
					}else{
				?>
				
				<input type="hidden" name="lokasi" value="Belum Arsip">
				
				<?php } ?>
				
				<?php
					if(Auth::user()->hak_akses ==  "admin"){
				?>
				<div class="form-line">
					<label for="isi">PIC</label>
					<select name="pic" class="form-control" required="required">
						<?php
						$pic=DB::table('users')->where('hak_akses','=','user')->get();
						?>
						<option value="">--Pilih--</option> 
						<?php $__currentLoopData = $pic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($pic->id); ?>"><?php echo e($pic->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<?php
					}else{
				?>
				
				<input type="hidden" name="pic" value="<?php echo e(Auth::user()->id); ?>">
				
				<?php } ?>
				
				
				<div class="form-line">
					<label for="isi">Wilayah Operasi</label>
					<input type="text" name="wilayah_operasi" class="form-control" required="required">
				</div>
				
				<div class="form-line">
					<label for="isi">Jenis Pekerjaan</label>
					<select name="jenis_pekerjaan" class="form-control" required="required">
						<option value="">--Pilih--</option> 
						<option value="Fasilitas Stasiun">Fasilitas Stasiun</option>
						<option value="Fasilitas Compressor">Fasilitas Compressor</option>
						<option value="HSSE">HSSE</option>
						<option value="Onshore">Pipeline Onshore</option>
						<option value="Offshore">Pipeline Offshore</option>
						<option value="Offshore">Integrity</option>
						<option value="ASANTIE">ASANTIE</option>
						<option value="SIMAG">SIMAG</option>
						
					</select>
				</div>
			
			<div class="form-line">
					<label for="isi">Nomor Surat</label>
					<input type="text" name="no_surat" class="form-control" required="required">
			</div>
			
			<div class="form-line">
					<label for="isi">Perihal SPPH/Usulan</label>
					<input type="text" name="nama" id="prihal" class="form-control" required="required">
			</div>
			
			<div class="form-line" >
					<label >Tanggal</label>
					  <input style="background:#ffff;" type="text" class="form-control" id="tgl" autocomplete="off" name="tanggal" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>
					
			</div>
			
			<div class="form-line" >
					<label>Tahun</label>
					  <input style="background:#ffff;" type="text" class="form-control" id="tahun" autocomplete="off" name="tahun" value="<?php echo date('Y') ; ?>" >
					
			</div>
			
			<div class="form-line">
					<label for="isi">Jenis Dokumen</label>
					<select name="jenis_dokumen" class="form-control" id="zoneSelect" onchange="updateChar();" required="required">
						<option value="">--Pilih Jenis Dokumen--</option>
						<option value="Usulan">Usulan</option>
						<option value="SPPH">Surat Permintaan Penawaran Harga</option>
					</select>
			</div>
			
			<div class="form-line">
					<label for="exampleInputPassword1">File</label>
					<input type="file" class="form-control" name="file" onchange="validasiFile()" id="file" >
			</div>
			
			<br>
			<div class="form-line">
				<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
			</div>
		</form>
	</div>
	</div>
	
<?php $__env->stopSection(); ?>

<script>
function updateChar() {
	
    var zone = document.getElementById("zoneSelect");

    if (zone.value == "Usulan"){
		document.getElementById("prihal").value = "Usulan ";
	}else if (zone.value == "SPPH"){
		document.getElementById("prihal").value = "Surat Permintaan Penawaran Harga ";
	}
}

function validasiFile(){
    var inputFile = document.getElementById('file');
    var pathFile = inputFile.value;
    var ekstensiOk = /(\.pdf|\.PDF)$/i;
    if(!ekstensiOk.exec(pathFile)){
        alert('Silakan upload file yang memiliki ekstensi PDF');
        inputFile.value = '';
        return false;
    }else{
        //Pratinjau gambar
        
    }
}
</script>
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>