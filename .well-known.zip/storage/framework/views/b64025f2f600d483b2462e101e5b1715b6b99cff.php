<?php $__env->startSection('content'); ?>
<div class="container">
		<div class="col-md-12">
			<!-- content -->
			<h2>Edit Data</h2>
			<form class="form-line" action="<?php echo e(route('pekerjaan.update',$pekerjaan->id)); ?>" method="post">
				<input type="hidden" name="_method" value="PUT">
				<?php echo e(csrf_field()); ?>

				
				<div class="form-line">
					<label for="isi">Nama Pekerjaan</label>
					<input type="text" name="nama_pekerjaan" class="form-control" value="<?php echo e($pekerjaan->nama_pekerjaan); ?>" required="required">
					<input type="hidden" name="nama_pekerjaan_old" class="form-control" value="<?php echo e($pekerjaan->nama_pekerjaan); ?>" >
				</div>
				
				
				<div class="form-line">
					<label for="isi">Lokasi Arsip</label>
					<input type="text" name="lokasi" class="form-control" value="<?php echo e($pekerjaan->lokasi); ?>" <?php if(Auth::user()->hak_akses != "admin"){echo "readonly";} ?>>
					
				</div>
				
				<?php
					if(Auth::user()->hak_akses ==  "admin"){
				?>
				<div class="form-line">
					<label for="isi">PIC</label>
					<select name="pic" class="form-control" required="required">
						<?php
						$pic=DB::table('users')->where('hak_akses','=','user')->get();
						$pic2=DB::table('users')->where('id','=',$pekerjaan->pic)->get()->first();
						?>
						<option value="<?php echo e($pekerjaan->pic); ?>"><?php echo e($pic2->name); ?></option>
						<?php $__currentLoopData = $pic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($pic->id); ?>"><?php echo e($pic->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<?php
					}else{
				?>
				
				<input type="hidden" name="pic" value="<?php echo e(Auth::user()->id); ?>">
				
				<?php } ?>
				
				<div class="form-line">
					<label for="isi">Status</label>
					<select name="status" class="form-control"  required="required">
					<option value="<?php echo e($pekerjaan->status); ?>"><?php echo e($pekerjaan->status); ?></option>
					<option value="OPEN">Open</option>
					<option value="CLOSED">Close</option>
					</select>
				</div>
				
				<div class="form-line">
					<label for="isi">Lokasi Pekerjaan</label>
					<input type="text" name="lokasi_pekerjaan" class="form-control" value="<?php echo e($pekerjaan->lokasi_pekerjaan); ?>" required="required">
				</div>
				
				<div class="form-line">
					<label for="isi">Area Operasi</label>
					<input type="text" name="area_operasi" class="form-control" value="<?php echo e($pekerjaan->area_operasi); ?>" required="required">
				</div>
				
				<div class="form-line">
					<label for="isi">Inisiator Kerja</label>
					<input type="text" name="inisiator_kerja" class="form-control" value="<?php echo e($pekerjaan->inisiator_kerja); ?>" required="required">
				</div>
				
				<div class="form-line">
					<label for="isi">Multi Years (%)</label> 
					<input type="number" name="multi_years" class="form-control" value="<?php echo e($pekerjaan->my); ?>">
				</div>
				
				<div class="form-line">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>