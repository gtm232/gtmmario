<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Wilayah Operasi</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                               
						
            <form style="float:left; margin-right:0px 5px 10px;" action="<?php echo url('/tambah_wilayah_operasi'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<button type="submit" class="btn btn-info">Tambah</button></a>
			</form>
					<br>
          
			<br>
            <div class="card-body ">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Wilayah Operasi </th>
                      
					  <th>Opsi</th>
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php 
				  $no=1; 
				  $wilayah_operasi=DB::table('wilayah_operasi')->get();
				  ?>
				  
				  <?php $__currentLoopData = $wilayah_operasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($wo->wilayah_operasi); ?></a></div></td>
					  <td>
					  <div style="display:none;">
					<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/dokumen_bulanan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
						<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($wo->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
					</form>
					  </div>
					  
					 <form style="float:left; margin-right:5px;" action="<?php echo url('/edit_wilayah_operasi'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<input type="hidden" name="id" value="<?php echo e($wo->id); ?>">
						<button type="submit" class="btn btn-primary">Edit</button></a>
					</form>
					  
					  <form method="post" action="<?php echo url('/hapus_wilayah_operasi'); ?>">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
					<input type="hidden" name="id" value="<?php echo e($wo->id); ?>">
					<input type="submit" class="btn btn-danger" value="Delete" />
				</form>
					  </td>
                    </tr>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>