<?php $__env->startSection('content'); ?>

	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->

<div class="row">

<?php
	$tahundashboard=$tahundashboard;
?>
<div class="col-lg-12 col-md-12">
	<table>
	<tr>
	<td>
	<form action="<?php echo url('/dashboard_tahun'); ?>" method="post">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<input type="hidden" name="tahundashboard" value="<?php echo e($tahundashboard-1); ?>">
		<button type="submit" class="btn btn-primary"><<</button>
	</form>
	</td>
	<td>
	<form>
	<button type="submit" class="btn btn-primary"><?php echo e($tahundashboard); ?></button>
	</form>
	</td>
	<td>
	<form action="<?php echo url('/dashboard_tahun'); ?>" method="post">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<input type="hidden" name="tahundashboard" value="<?php echo e($tahundashboard+1); ?>">
		<button type="submit" class="btn btn-primary">>></button>
	</form>
	</td>
	</tr>
	</table>
</div>
<div id="container" class="col-lg-6 col-md-6 col-sm-6" style="margin-bottom:15px;"></div>
<div id="container1" class="col-lg-6 col-md-6 col-sm-6" style="margin-bottom:15px;"></div>
<div id="container3" class="col-lg-12 col-md-12 col-sm-12" style="margin-bottom:15px;"></div>

<div class="col-lg-12">
<?php
	$jumlahspk=DB::table('laporan_pekerjaan')->where(DB::raw('YEAR(tanggal_mulai)'),$tahundashboard)->get();
		$Paid=0;
		foreach($jumlahspk as $jumlahspk){
			$jmlspk1=DB::table('popay')->where([['id_laporan_pekerjaan',$jumlahspk->id],['status','Paid'],])->get()->sum('rupiah');
			$Paid=$Paid+$jmlspk1;
			
		}
	$acrue1=DB::table('laporan_pekerjaan')->where([[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],[DB::raw('MONTH(tanggal_berakhir)'),12],])->get();
	$acrue=0;
	foreach($acrue1 as $acrue1){
		$jmlacrue=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$acrue1->id],['jenis_dokumen','SPK'],])->get()->SUM('harga_pekerjaan');
		$acrue=$jmlacrue+$acrue;
	}
	$multi_years1=DB::table('laporan_pekerjaan')->where([[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],['my','!=',0],])->get();
	$multi_years=0;
	foreach($multi_years1 as $multi_years1){
		$jmlmulti_years=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$multi_years1->id],['jenis_dokumen','SPK'],])->get()->SUM('harga_pekerjaan');
		$multi_years2=(($multi_years1->my / 100) * $jmlmulti_years); 
		$multi_years=$multi_years+$multi_years2;
	}
	
	$luncuran20181=DB::table('laporan_pekerjaan')->where([[DB::raw('YEAR(tanggal_mulai)'),($tahundashboard-1)],['my','!=',0],])->get();
	$luncuran2018=0;
	foreach($luncuran20181 as $luncuran20181){
		$jmlluncuran2018=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$luncuran20181->id],['jenis_dokumen','SPK'],])->get()->SUM('harga_pekerjaan');
		$luncuran20182=(($luncuran20181->my / 100) * $jmlluncuran2018); 
		$luncuran2018=$luncuran2018+$luncuran20182;
	}
?>

<?php
	//Fasilitas Compressor
	$fasilitascompressor1=DB::table('laporan_pekerjaan')->where('proses','=','Pengerjaan')->orwhere('proses','=','Tagihan')->orwhere('proses','=','Popay')->orwhere('proses','=','Paid')->get();
	$fcj=0;
	foreach($fasilitascompressor1 as $fc){
	$pt=date('Y',strtotime($fc->tanggal_mulai));
	if($fc->lokasi_pekerjaan == "Fasilitas Compressor" and $pt==$tahundashboard){	 
	$fcj++;
	}
	}
	//end Fasilitas Compressor
	
	//Integrity
	$integrity=DB::table('laporan_pekerjaan')->where('proses','=','Pengerjaan')->orwhere('proses','=','Tagihan')->orwhere('proses','=','Popay')->orwhere('proses','=','Paid')->get();
	$inj=0;
	foreach($integrity as $in){
	$pt=date('Y',strtotime($in->tanggal_mulai));
	if($in->lokasi_pekerjaan == "Integrity" and $pt==$tahundashboard){	 
	$inj++;
	}
	}
	//end Integrity
	
	//Pipeline Onshore
	$onshore=DB::table('laporan_pekerjaan')->where('proses','=','Pengerjaan')->orwhere('proses','=','Tagihan')->orwhere('proses','=','Popay')->orwhere('proses','=','Paid')->get();
	$osj=0;
	foreach($onshore as $os){
	$pt=date('Y',strtotime($os->tanggal_mulai));
	if($os->lokasi_pekerjaan == "Onshore" and $pt==$tahundashboard){	 
	$osj++;
	}
	}
	//end Pipeline Onshore
	
	//Pipeline Offshore
	$offshore=DB::table('laporan_pekerjaan')->where('proses','=','Pengerjaan')->orwhere('proses','=','Tagihan')->orwhere('proses','=','Popay')->orwhere('proses','=','Paid')->get();
	$ofj=0;
	foreach($offshore as $of){
	$pt=date('Y',strtotime($of->tanggal_mulai));
	if($of->lokasi_pekerjaan == "Offshore" and $pt==$tahundashboard){	 
	$ofj++;
	}
	}
	//end Pipeline Offshore
	
	//HSSE
	$hsse=DB::table('laporan_pekerjaan')->where('proses','=','Pengerjaan')->orwhere('proses','=','Tagihan')->orwhere('proses','=','Popay')->orwhere('proses','=','Paid')->get();
	$hsj=0;
	foreach($hsse as $hs){
	$pt=date('Y',strtotime($hs->tanggal_mulai));
	if($hs->lokasi_pekerjaan == "HSSE" and $pt==$tahundashboard){	 
	$hsj++;
	}
	}
	//end HSSE
	
	//Fasilitas Stasiun
	$fasilitasstasiun=DB::table('laporan_pekerjaan')->where('proses','=','Pengerjaan')->orwhere('proses','=','Tagihan')->orwhere('proses','=','Popay')->orwhere('proses','=','Paid')->get();
	$fsj=0;
	foreach($fasilitasstasiun as $fs){
	$pt=date('Y',strtotime($fs->tanggal_mulai));
	if($fs->lokasi_pekerjaan == "Fasilitas Stasiun" and $pt==$tahundashboard){	 
	$fsj++;
	}
	}
	//end Fasilitas Stasiun
	
	//SIMAG
	$simag=DB::table('laporan_pekerjaan')->where('proses','=','Pengerjaan')->orwhere('proses','=','Tagihan')->orwhere('proses','=','Popay')->orwhere('proses','=','Paid')->get();
	$smj=0;
	foreach($simag as $sm){
	$pt=date('Y',strtotime($sm->tanggal_mulai));
	if($sm->lokasi_pekerjaan == "SIMAG" and $pt==$tahundashboard){	 
	$smj++;
	}
	}
	//end SIMAG
	
	//ASANTIE
	$asantie=DB::table('laporan_pekerjaan')->where('proses','=','Pengerjaan')->orwhere('proses','=','Tagihan')->orwhere('proses','=','Popay')->orwhere('proses','=','Paid')->get();
	$asj=0;
	foreach($asantie as $as){
	$pt=date('Y',strtotime($as->tanggal_mulai));
	if($as->lokasi_pekerjaan == "ASANTIE" and $pt==$tahundashboard){	 
	$asj++;
	}
	}
	//end ASANTIE
	$jumlahspksatuan=$fcj+$inj+$osj+$ofj+$hsj+$fsj; 
	?>
 


</div>
</div>

	<div class="row">
		
		<div class="col-lg-6 col-md-6">
		<div class="card" >
		<div class="table-responsive">
			<table class="table table-bordered" style="background-color:white; font-size:12px;">
				<tr>
					<td>No</td>
					<td>Deskripsi</td>
					<td>Nilai SPK</td> 
					<td>Jumlah SPK</td>
				</tr>
				
				<tr>
					<td>1</td>
					<td>Jumlah SPK (MARIO)</td>
					<td>
											  
						<?php
						$jumlahspk=DB::table('laporan_pekerjaan')->where([['lokasi_pekerjaan','!=','ASANTIE'],['lokasi_pekerjaan','!=','SIMAG'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
						$jmlspk=0;
						foreach($jumlahspk as $jumlahspk){
						$jmlspk1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$jumlahspk->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
						$jmlspk=$jmlspk+$jmlspk1; 
						}												
						echo number_format($jmlspk,2,',','.'); 
						?>
											
					</td>
					<td><?php echo e($jumlahspksatuan); ?></td>
				</tr>
										
				<tr>
					<td>2</td>
					<td>Jumlah SPK (ASANTIE)</td>
					<td>
											 
					<?php
					$jumlahasantie=DB::table('laporan_pekerjaan')->where([['lokasi_pekerjaan','=','ASANTIE'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
					$jmlasantie=0;
					foreach($jumlahasantie as $jumlahasantie){
					$jmlasantie1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$jumlahasantie->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
					$jmlasantie=$jmlasantie+$jmlasantie1;
					}	
					echo number_format($jmlasantie,2,',','.'); 
					?>
											
					</td>
					<td><?php echo e($asj); ?></td>
					</tr>
										
					<tr>
						<td colspan="2" style="text-align:center;">Jumlah SPK</td>
						<td><?php echo e(number_format($jmlspk + $jmlasantie,2,',','.')); ?></td>
						<td><?php echo e($jumlahspksatuan + $asj); ?></td>
					</tr>
					
					<tr>
						<td>Nilai BAST</td>
						<td>
							<?php
								$bast1=DB::table('laporan_pekerjaan')->get();
								$bast=0;
								$nobast=0;
								foreach($bast1 as $bast1){
								$pt=date('Y',strtotime($bast1->tanggal_mulai));
								if($pt==$tahundashboard){	 
								$bast2=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$bast1->id],['jenis_dokumen','BAST']])->sum('harga_pekerjaan');
								$bast=$bast+$bast2;
								
								$nobast2=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$bast1->id],['jenis_dokumen','BAST']])->count();
								if($nobast2!=0){
									$nobast++;
								}
								} 
								}
							?>
							<?php echo e(number_format($bast,2,',','.')); ?>

						</td>
						<td>Pekerjaan Sudah BAST</td>
						<td><?php echo e($nobast); ?></td>
					</tr>
										
				<!--<tr>
						<td>3</td>
						<td>Jumlah Terbayar</td>
						<td>
											
						<?php
						//$jumlahspk=DB::table('laporan_pekerjaan')->where('proses','=','Paid')->get();
						//$jspk=0;
						//foreach($jumlahspk as $jmlspk){
						//$jspk1=DB::table('popay')->where([['id_laporan_pekerjaan','=',$jmlspk->id],['status','=','Paid'],])->sum('rupiah'); 
						//$jspk=$jspk+$jspk1;
						//	}
						//echo "Rp. ".number_format($jspk,2,',','.');
						?>
											
						</td>
					</tr>-->
			</table>
		
		</div>
		</div>
		</div>
		
		<div class="col-lg-6 col-md-6">
		<div class="card" >
		<div class="table-responsive">
			<table class="table table-bordered" style="background-color:white; text-align:center; font-size:12px;"> 
				<tr>
					<td colspan="3">Alokasi Anggaran <?php echo e($tahundashboard); ?></td>
					<td>Alokasi <?php echo e($tahundashboard+1); ?></td>
					<td>Terbayar</td> 
				</tr>
				
				<tr>
					<td>Luncuran <?php echo e($tahundashboard-1); ?></td>
					<td><?php echo e($tahundashboard); ?></td>
					<td>
					<div style="float:left; margin-right:5px;">Potensial Accrue</div>
					<div style="float:left;">
					<form action="<?php echo url('/pekerjaan_accrue');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="tahundashboard" value="<?php echo e($tahundashboard); ?>"> 
					<button type="submit"><i class="fa fa-eye"></i></button>
					</form>
					</div>
					</td>
					<td rowspan="4"><div style="margin-top:30%;"><?php echo e(number_format($multi_years,2,',','.')); ?></div></td>
					<?php
					$jumlahspk=DB::table('laporan_pekerjaan')->get();
					$Paid=0;
					foreach($jumlahspk as $jumlahspk){
						$jmlspk1=DB::table('popay')->where(DB::raw('YEAR(tanggal_input)'),$tahundashboard)->where([['id_laporan_pekerjaan',$jumlahspk->id],['status','Paid'],])->get()->sum('rupiah');
						$Paid=$Paid+$jmlspk1;
					}?>	
					<td rowspan="4"><div style="margin-top:30%;"><?php echo e(number_format($Paid,2,',','.')); ?></div></td>
				</tr>
				
				<tr>
					<td rowspan="2"><?php echo e(number_format($luncuran2018,2,',','.')); ?></td>
					<td><?php echo e(number_format(($jmlspk + $jmlasantie)-($multi_years+$acrue),2,',','.')); ?></td>
					<td><?php echo e(number_format($acrue,2,',','.')); ?></td>
				</tr>
				
				<tr>
					<td colspan="2"><?php echo e(number_format(($jmlspk + $jmlasantie)-$multi_years,2,',','.')); ?></td>
				</tr>
				
				<tr>
					<td colspan="3"><?php echo e(number_format(($jmlspk + $jmlasantie + $luncuran2018)-$multi_years,2,',','.')); ?></td>
				</tr>
			</table>
		</div>
	</div>
	</div>
	</div>

	
	<div class="col-lg-12 col-md-12">
	<div class="card" >
	<div class="table-responsive">
		<table class="table table-bordered" width="100%" cellspacing="0" style="font-size:13px;">
									<thead>
										<tr>
											<th>No</th>
											<th>Deskripsi</th>
											<th>Nilai SPK</th>
										</tr>
									</thead>
									
									<tbody>
									<?php
										$spkfc=DB::table('laporan_pekerjaan')->where([['lokasi_pekerjaan','=','Fasilitas Compressor'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
										$jmlspkfc=0; 
												foreach($spkfc as $spkfc){ 
													$jmlspkfc1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$spkfc->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
													$jmlspkfc=$jmlspkfc1+$jmlspkfc; 
												}	
									?>
										<tr>
											<td>1</td>
											<td>Fasilitas Compressor</td>
											<td>Rp <?php echo e(number_format($jmlspkfc,2,',','.')); ?></td>
											
										</tr>
										<?php
										$spkinty=DB::table('laporan_pekerjaan')->where([['lokasi_pekerjaan','=','Integrity'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
										$jmlspkinty=0; 
												foreach($spkinty as $spkinty){ 
													$jmlspkinty1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$spkinty->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
													$jmlspkinty=$jmlspkinty1+$jmlspkinty; 
												}	
										?>
										<tr>
											<td>2</td>
											<td>Integrity</td>
											<td>Rp <?php echo e(number_format($jmlspkinty,2,',','.')); ?></td>
										</tr>
										<?php
										$spkon=DB::table('laporan_pekerjaan')->where([['lokasi_pekerjaan','=','Onshore'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
										$jmlspkon=0; 
												foreach($spkon as $spkon){ 
													$jmlspkon1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$spkon->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
													$jmlspkon=$jmlspkon1+$jmlspkon; 
												}	
										?>
										<tr>
											<td>3</td>
											<td>Pipeline Onshore</td>
											<td>Rp <?php echo e(number_format($jmlspkon,2,',','.')); ?></td>
										</tr>
										<?php
										$spkoff=DB::table('laporan_pekerjaan')->where([['lokasi_pekerjaan','=','Offshore'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
										$jmlspkoff=0; 
												foreach($spkoff as $spkoff){ 
													$jmlspkoff1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$spkoff->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
													$jmlspkoff=$jmlspkoff1+$jmlspkoff; 
												}	
										?>
										<tr>
											<td>4</td>
											<td>Pipeline Offshore</td>
											<td>Rp <?php echo e(number_format($jmlspkoff,2,',','.')); ?></td>
										</tr>
										<?php
										$spkhsse=DB::table('laporan_pekerjaan')->where([['lokasi_pekerjaan','=','HSSE'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
										$jmlspkhsse=0; 
												foreach($spkhsse as $spkhsse){ 
													$jmlspkhsse1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$spkhsse->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
													$jmlspkhsse=$jmlspkhsse1+$jmlspkhsse; 
												}	
										?>
										
										<tr>
											<td>5</td>
											<td>HSSE</td>
											<td>Rp <?php echo e(number_format($jmlspkhsse,2,',','.')); ?></td>
										</tr>
										<?php
										$spkfs=DB::table('laporan_pekerjaan')->where([['lokasi_pekerjaan','=','Fasilitas Stasiun'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
										$jmlspkfs=0; 
												foreach($spkfs as $spkfs){ 
													$jmlspkfs1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$spkfs->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
													$jmlspkfs=$jmlspkfs1+$jmlspkfs; 
												}	
										?>
										<tr>
											<td>6</td>
											<td>Fasilitas Stasiun</td>
											<td>Rp <?php echo e(number_format($jmlspkfs,2,',','.')); ?></td>
										</tr>
										
										
									</tbody>
								</table>
	</div>
	</div>
	</div>
	
	
	<div class="col-lg-12">

	<div class="card" >
	<h2 align="center">Notifikasi</h2>
		<table class="table table-bordered" id="dataTable"  cellspacing="0" style="font-size:13px;">
									<thead>
										<tr>
											<th style="text-align:center;">No</th>
											<th style="text-align:center;">Waktu</th>
											<th style="text-align:center;">Nama Pekerjaan</th>
											<th style="text-align:center;">Tanggal Mulai</th>
											<th style="text-align:center;">Tanggal Berakhir</th>
											<th style="text-align:center;">PIC</th>
											<th></th> 
										</tr>
									</thead>
									
									<tbody>
									<?php
									$peringatan=DB::table('laporan_pekerjaan')->get();
									$no=1;
									?>
									<?php $__currentLoopData = $peringatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peringatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($peringatan->tanggal_mulai != 0000-00-00): ?>
									<?php  
									$tanggal_berakhir  = strtotime($peringatan->tanggal_berakhir);
									$sekarang    = time(); // Waktu sekarang
									$diff   = $sekarang - $tanggal_berakhir;
									//echo 'umur anda adalah ' . floor($diff / (60 * 60 * 24 * 365)) . ' Tahun'; // Umur anda dalam hitungan tahun
									//echo 'umur anda adalah ' . floor($diff / (60 * 60 * 24)) . ' Hari'; // Umur anda dalam hitungan hari	
									$selisih= floor($diff / (60 * 60 * 24));
									$user=DB::table('users')->where('id','=',$peringatan->pic)->get()->first();
									$bast=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$peringatan->id],['jenis_dokumen','BAST']])->get()->count();
									?>
									<?php if($peringatan->status != "CLOSED" and $bast == 0): ?> 
									<?php if($selisih >= -15 or $selisih > 1 ): ?>
										<tr>
											<td style="text-align:center;"><?php echo e($no); ?></td> 
											<td><?php echo e($peringatan->nama_pekerjaan); ?></td> 
											<td style="text-align:center;">
											<?php if($selisih >= -15 and $selisih < 0): ?> 
												Sisa <?php echo e(abs($selisih)); ?> Hari 
											<?php endif; ?>
											<?php if($selisih >= 1): ?>
												Lewat <?php echo e($selisih); ?> Hari
											<?php endif; ?>
											<?php if($selisih == 0): ?>
												Berakhir Hari Ini
											<?php endif; ?>
											</td> 
											<td style="text-align:center;"><?php echo e(date('d-M-Y',strtotime($peringatan->tanggal_mulai))); ?></td>
											<td style="text-align:center;"><?php echo e(date('d-M-Y',strtotime($peringatan->tanggal_berakhir))); ?></td>
											<td style="text-align:center;"><?php echo e($user->name); ?></td>
											<td style="text-align:center;">
											<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/dokumen_pekerjaan'); ?>" method="post">
											<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
											<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($peringatan->id); ?>">
											<button type="submit" class="btn btn-primary">Lihat</button></a>
											</form>
											</td>
										</tr>
									<?php $no++; ?>
									<?php endif; ?>
									<?php endif; ?>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
		</table>
	</div>
</div> 

<script type="text/javascript">

Highcharts.chart('container3', {
    chart: {
        type: 'column',
        options3d: {
            enabled: true,
            alpha: 10,
            beta: 0,
            depth: 70
        }
    },
	credits: {
    enabled: false
  },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    plotOptions: {
        column: {
            depth: 25
        }
    },
    xAxis: {
        //categories: Highcharts.getOptions().lang.shortMonths,
        categories: [''],
        labels: {
            skew3d: true,
            style: {
                fontSize: '16px'
            }
        }
    },
    yAxis: {
        title: {
            text: null
        }
    },
	<?php
	$jumlahspk=DB::table('laporan_pekerjaan')->where(DB::raw('YEAR(tanggal_mulai)'),$tahundashboard)->get(); 
		$usulan=0;
		foreach($jumlahspk as $jumlahspk){
			$jmlspk1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$jumlahspk->id],['jenis_dokumen','SPH'],])->get()->sum('harga_pekerjaan');
			$jmlspk2=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$jumlahspk->id],['jenis_dokumen','Usulan'],])->get()->sum('harga_pekerjaan');
			
			$usulan=$usulan+$jmlspk1+$jmlspk2; 
		}
	$jumlahspk=DB::table('laporan_pekerjaan')->where(DB::raw('YEAR(tanggal_mulai)'),$tahundashboard)->get();
		$Pengerjaan=0;
		foreach($jumlahspk as $jumlahspk){
			$jmlspk1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$jumlahspk->id],['jenis_dokumen','SPK'],])->get()->sum('harga_pekerjaan');
			$Pengerjaan=$Pengerjaan+$jmlspk1; 
		}	
	$nego1=DB::table('laporan_pekerjaan')->where([['proses','=','Nego'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
	$nego=0;
	foreach($nego1 as $nego1){
		$harga2=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$nego1->id],['jenis_dokumen','SPH'],])->get()->sum('harga_pekerjaan');
		$nego=$nego+$harga2;
	}
	$jumlahspk=DB::table('laporan_pekerjaan')->where(DB::raw('YEAR(tanggal_mulai)'),$tahundashboard)->get();
		$Tagihan=0;
		foreach($jumlahspk as $jumlahspk){
			$jmlspk1=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$jumlahspk->id],['jenis_dokumen','SPP'],])->get()->sum('harga_pekerjaan');
			$Tagihan=$Tagihan+$jmlspk1; 
		}	
	
	 
	$Popay=DB::table('popay')->where('status','=','On Progress')->get()->sum('rupiah');
	//$Paid=DB::table('popay')->where('status','=','Paid')->get()->sum('rupiah');

					$jumlahspk=DB::table('laporan_pekerjaan')->get();
					$Paid=0;
					foreach($jumlahspk as $jumlahspk){
						$jmlspk1=DB::table('popay')->where(DB::raw('YEAR(tanggal_input)'),$tahundashboard)->where([['id_laporan_pekerjaan',$jumlahspk->id],['status','Paid'],])->get()->sum('rupiah');
						$Paid=$Paid+$jmlspk1; 
					}
	$bast1=DB::table('laporan_pekerjaan')->get();
								$bast=0;
								$nobast=0;
								foreach($bast1 as $bast1){
								$pt=date('Y',strtotime($bast1->tanggal_mulai));
								if($pt==$tahundashboard){	 
								$bast2=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$bast1->id],['jenis_dokumen','BAST']])->sum('harga_pekerjaan');
								$bast=$bast+$bast2;
								
								$nobast2=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$bast1->id],['jenis_dokumen','BAST']])->count();
								if($nobast2!=0){
									$nobast++;
								}
								} 
								}
	
	?>
 
	
	series: [{
        name: 'Usulan',
		color:'green',
        data: [<?php echo e($usulan); ?>]
    },
	
	{
        name: 'SPK',
		color:'Grey',
        data: [<?php echo e($Pengerjaan); ?>]
    },
	
	{
        name: 'Nego',
		color:'Blue',
        data: [<?php echo e($nego); ?>]
    },
	
	{
        name: 'Tagihan',
		color:'Red',
        data: [<?php echo e($Tagihan); ?>]
    },
	
	{
        name: 'Popay',
		color:'chocolate',
        data: [<?php echo e($Popay); ?>]
    },
	
	{
        name: 'Paid',
		color:'yellow',
        data: [<?php echo e($Paid); ?>]
    },
	
	{
        name: 'Acrue',
		color:'Violet',
        data: [<?php echo e($acrue); ?>]
    },
	
	{
        name: 'Multi Years',
		color:'Black',
        data: [<?php echo e($multi_years); ?>]
    },
	
	{
        name: 'BAST',
		color:'Pink',
        data: [<?php echo e($bast); ?>]
    }, 
	]
	
	
});
		</script>  
				
								
<script type="text/javascript">

Highcharts.chart('container1', {
    chart: {
        type: 'column',
        options3d: {
            enabled: true,
            alpha: 10,
            beta: 0,
            depth: 70
        }
    },
	credits: {
    enabled: false
  },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    plotOptions: {
        column: {
            depth: 25
        }
    },
    xAxis: {
        //categories: Highcharts.getOptions().lang.shortMonths,
        categories: [''],
        labels: {
            skew3d: true,
            style: {
                fontSize: '16px'
            }
        }
    },
    yAxis: {
        title: {
            text: null
        }
    },
	<?php
	$jumlahspk=DB::table('laporan_pekerjaan')->where(DB::raw('YEAR(tanggal_mulai)'),$tahundashboard)->get(); 
		$usulan=0;
		foreach($jumlahspk as $jumlahspk){
			$usulan=$usulan+1;
		}
	$jumlahspk=DB::table('laporan_pekerjaan')->where(DB::raw('YEAR(tanggal_mulai)'),$tahundashboard)->get();
		$Pengerjaan=0;
		foreach($jumlahspk as $jumlahspk){
			$jmlspk1=DB::table('laporan_pekerjaan')->where([['id','=',$jumlahspk->id],['proses','!=','Nego'],])->get()->count(); 
			$Pengerjaan=$Pengerjaan+$jmlspk1;
		}	
	$nego1=DB::table('laporan_pekerjaan')->where([['proses','=','Nego'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
	$nego=0;
	foreach($nego1 as $nego1){
		$harga2=1;
		$nego=$nego+$harga2;
	}
	$jumlahspk=DB::table('laporan_pekerjaan')->where([['proses','=','Tagihan'],[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],])->get();
		$Tagihan=0;
		foreach($jumlahspk as $jumlahspk){
			$jmlspk1=1;
			$Tagihan=$Tagihan+$jmlspk1; 
		}	
	
	 
	$jumlahspk=DB::table('laporan_pekerjaan')->get();
					$Popay=0;
					foreach($jumlahspk as $jumlahspk){
						$jmlspk1=DB::table('popay')->where(DB::raw('YEAR(tanggal_input)'),$tahundashboard)->where([['id_laporan_pekerjaan',$jumlahspk->id],['status','On Progress'],])->get()->count();
						if($jmlspk1){
						$jmlspk1=1;
						$Popay=$Popay+$jmlspk1;
						}						
					}
	//$Paid=DB::table('popay')->where('status','=','Paid')->get()->sum('rupiah');

					$jumlahspk=DB::table('laporan_pekerjaan')->get();
					$Paid=0;
					foreach($jumlahspk as $jumlahspk){
						$jmlspk1=DB::table('popay')->where(DB::raw('YEAR(tanggal_input)'),$tahundashboard)->where([['id_laporan_pekerjaan',$jumlahspk->id],['status','Paid'],])->get()->count();
						if($jmlspk1){
						$jmlspk1=1;
						$Paid=$Paid+$jmlspk1;
						}
					}

	$acrue12=DB::table('laporan_pekerjaan')->where([[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],[DB::raw('MONTH(tanggal_berakhir)'),12],])->get();
	$acrue2=0;
	foreach($acrue12 as $acrue12){
		$acrue2++;
	}
	$multi_years12=DB::table('laporan_pekerjaan')->where([[DB::raw('YEAR(tanggal_mulai)'),$tahundashboard],['my','!=',0],])->get();
	$multi_years2=0;
	foreach($multi_years12 as $multi_years12){
		$multi_years2++;
	}
	
	
	?>
 
	
	series: [{
        name: 'Usulan / SPH',
		color:'green',
        data: [<?php echo e($usulan); ?>]
    },
	
	{
        name: 'SPK',
		color:'Grey',
        data: [<?php echo e($Pengerjaan); ?>]
    },
	
	{
        name: 'Nego',
		color:'Blue',
        data: [<?php echo e($nego); ?>]
    },
	
	{
        name: 'Tagihan',
		color:'Red',
        data: [<?php echo e($Tagihan); ?>]
    },
	
	{
        name: 'Popay',
		color:'chocolate',
        data: [<?php echo e($Popay); ?>]
    },
	
	{
        name: 'Paid',
		color:'yellow',
        data: [<?php echo e($Paid); ?>]
    },
	
	{
        name: 'Acrue',
		color:'Violet',
        data: [<?php echo e($acrue2); ?>]
    },
	
	{
        name: 'Multi Years',
		color:'Black',
        data: [<?php echo e($multi_years2); ?>]
    },
	
	{
        name: 'BAST',
		color:'Pink',
        data: [<?php echo e($nobast); ?>]
    }, 
	]
	
	
});
		</script>  
		
		
<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
	
	credits: {
    enabled: false
  },
    title: {
        text: '' 
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
	
    series: [{
        type: 'pie',
        name: 'Evaluation GTM',
        data: [
			<?php
			if($fcj != 0){ 
			?>
            ['Fasilitas Compressor (<?php echo e($fcj); ?>)', <?php echo e($fcj); ?>],
			<?php
			}
			?>
			<?php
			if($inj != 0){ 
			?>
            ['Integrity (<?php echo e($inj); ?>)', <?php echo e($inj); ?>],
			<?php
			}
			?>
			<?php
			if($osj != 0){ 
			?>
            ['Pipeline Onshore (<?php echo e($osj); ?>)', <?php echo e($osj); ?>],
			<?php
			}
			?>
			<?php
			if($ofj != 0){ 
			?>
            ['Pipeline Offshore (<?php echo e($ofj); ?>)', <?php echo e($ofj); ?>],
			<?php 
			}
			?>
			<?php
			if($hsj != 0){ 
			?>
            ['HSSE (<?php echo e($hsj); ?>)', <?php echo e($hsj); ?>],
            <?php
			}
			?>
			<?php
			if($fsj != 0){ 
			?>
			['Fasilitas Stasiun (<?php echo e($fsj); ?>)', <?php echo e($fsj); ?>],
			<?php
			}
			?>
			<?php
			if($smj != 0){ 
			?>
            ['SIMAG (<?php echo e($smj); ?>)', <?php echo e($smj); ?>],
			<?php
			}
			?> 
			<?php
			if($asj != 0){ 
			?>
            ['ASANTIE (<?php echo e($asj); ?>)', <?php echo e($asj); ?>],
			<?php
			}
			?>
        ]
    }]

});
		</script>
              
<?php $__env->stopSection(); ?>
<script src="<?php echo URL::to('/'); ?>/haightcart/code/highcharts.js"></script>
<script src="<?php echo URL::to('/'); ?>/haightcart/code/highcharts-3d.js"></script>
<script src="<?php echo URL::to('/'); ?>/haightcart/code/modules/exporting.js"></script>
<script src="<?php echo URL::to('/'); ?>/haightcart/code/modules/export-data.js"></script>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>