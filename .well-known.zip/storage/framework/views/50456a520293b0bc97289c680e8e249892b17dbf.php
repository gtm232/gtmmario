<?php $__env->startSection('content'); ?>
<style type="text/css">
#container {
    height: 500px; 
    width: 100%;
    margin: 0 auto;
}
		</style>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->


<div id="container"></div>
				
				<div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                   <div class="table-responsive">					
				<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th rowspan="2" style="vertical-align:top; text-align:center;">Program Kerja</th>
                      <th rowspan="2" style="vertical-align:top; text-align:center;">Lokasi</th>
                      <th rowspan="2" style="vertical-align:top; text-align:center;">Area Operasi</th>
					  <th rowspan="2" style="vertical-align:top; text-align:center;">Inisiator Program Kerja</th>
					  <th colspan="2" style="vertical-align:top; text-align:center;">Surat Permintaan Pekerjaan</th>
					  <th colspan="2" style="vertical-align:top; text-align:center;">SPPH</th>
					  <th colspan="2" style="vertical-align:top; text-align:center;">SPH</th>
					  <th colspan="2" style="vertical-align:top; text-align:center;">Undangan Klarifikasi & Negosisasi</th>
					  <th colspan="2" style="vertical-align:top; text-align:center;">BA Klarifikasi & Negosisasi</th>
					  <th colspan="2" style="vertical-align:top; text-align:center;">SPK</th>
					  <th rowspan="2" style="vertical-align:top; text-align:center;">Durasi Pekerjaan</th>
					  <th rowspan="2" style="vertical-align:top; text-align:center;">Mulai Pekerjaan</th>
					  <th colspan="2" style="vertical-align:top; text-align:center;">Selesai Pekerjaan</th>
					  <th colspan="2" style="vertical-align:top; text-align:center;">BAP</th>
					  <th colspan="3" style="vertical-align:top; text-align:center;">BAST</th>
					  <th colspan="3" style="vertical-align:top; text-align:center;">Invoice</th>
					  <th colspan="5" style="vertical-align:top; text-align:center;">Pembayaran POPAY</th>
					  <th rowspan="2" style="vertical-align:top; text-align:center;">PPN (10%)</th>
					  <th rowspan="2" style="vertical-align:top; text-align:center;">PPH</th>
					  <th rowspan="2" style="vertical-align:top; text-align:center;">Jumlah Terbayar</th>
					  <th rowspan="2" style="vertical-align:top; text-align:center;">Penawaran PGASOL</th>
					  <th rowspan="2" style="vertical-align:top; text-align:center;">Selisih Nego</th>
					  <th rowspan="2" style="vertical-align:top; text-align:center;">Prosentase</th>
					  
                    </tr>
					
					<tr>
						<th>Nomor</th>
						<th>Tanggal</th>
						
						<th>Nomor</th>
						<th>Tanggal</th>
						
						<th>Nomor</th>
						<th>Tanggal</th>
						
						<th>Nomor</th>
						<th>Tanggal</th>
						
						<th>Nomor</th>
						<th>Tanggal</th>
						
						<th>Nomor</th>
						<th>Tanggal</th>
						
						<th>Rencana</th>
						<th>Realisasi</th>
						
						<th>Nomor</th>
						<th>Tanggal</th>
						
						<th>Nomor</th>
						<th>Tanggal</th>
						<th>Rupiah</th>
						
						<th>Nomor</th>
						<th>Tanggal</th>
						<th>Rupiah</th>
						
						<th>Nomor PR</th>
						<th>Tanggal Input</th>
						<th>Tanggal Paid</th>
						<th>Rupiah</th>
						<th>Status</th>
						
					</tr>
                  </thead>
                  
                  <tbody>
				  <?php $no=1; ?>
				  <?php $__currentLoopData = $dashboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dashboard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  <tr>
                    <td><div style="width:200px;"><?php echo e($dashboard->nama_pekerjaan); ?></div></td>
                    <td><?php echo e($dashboard->lokasi_pekerjaan); ?></td>
                    <td><?php echo e($dashboard->area_operasi); ?></td>
                    <td><?php echo e($dashboard->inisiator_kerja); ?></td>
					
					<!--usulan-->
					<?php
					$usulan=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','Usulan'],])->get()->first();
					if($usulan){
						$usulanno_surat=$usulan->no_surat;
						$usulantanggal=$usulan->tanggal;
					}else{
						$usulanno_surat="";
						$usulantanggal="";
					}
					?>
                    <td><div style="width:220px;"><?php echo e($usulanno_surat); ?></div></td>
                    <td><div style="width:150px;"><?php echo e($usulantanggal); ?></div></td>
					
					<!--SPPH-->
					<?php
					$SPPH=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','SPPH'],])->get()->first();
					if($SPPH){
						$SPPHno_surat=$SPPH->no_surat;
						$SPPHtanggal=$SPPH->tanggal;
					}else{
						$SPPHno_surat="";
						$SPPHtanggal="";
					}
					?>
                    <td><?php echo e($SPPHno_surat); ?></td>
                    <td><?php echo e($SPPHtanggal); ?></td>
					
					<!--SPH-->
					<?php
					$SPH=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','SPH'],])->get()->first();
					if($SPH){
						$SPHno_surat=$SPH->no_surat;
						$SPHtanggal=$SPH->tanggal;
					}else{
						$SPHno_surat="";
						$SPHtanggal="";
					}
					?>
                    <td><?php echo e($SPHno_surat); ?></td>
                    <td><?php echo e($SPHtanggal); ?></td>
					
					<!--Undangan Nego-->
					<?php
					$Undangan_Nego=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','Undangan Nego'],])->get()->first();
					if($Undangan_Nego){
						$UndanganNegono_surat=$Undangan_Nego->no_surat;
						$UndanganNegotanggal=$Undangan_Nego->tanggal;
					}else{
						$UndanganNegono_surat="";
						$UndanganNegotanggal="";
					}
					?>
                    <td><?php echo e($UndanganNegono_surat); ?></td>
                    <td><?php echo e($UndanganNegotanggal); ?></td>
					
					<!--BA Nego-->
					<?php
					$BA_Nego=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','BA Nego'],])->get()->first();
					if($BA_Nego){
						$BANegono_surat=$BA_Nego->no_surat;
						$BANegotanggal=$BA_Nego->tanggal;
					}else{
						$BANegono_surat="";
						$BANegotanggal="";
					}
					?>
                    <td><?php echo e($BANegono_surat); ?></td>
                    <td><?php echo e($BANegotanggal); ?></td>
					
					<!--SPK-->
					<?php
					$SPK=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','SPK'],])->get()->first();
					if($BA_Nego){
						$SPKno_surat=$SPK->no_surat;
						$SPKtanggal=$SPK->tanggal;
					}else{
						$SPKno_surat="";
						$SPKtanggal="";
					}
					?>
                    <td><?php echo e($SPKno_surat); ?></td>
                    <td><?php echo e($SPKtanggal); ?></td>
					
					<?php
					$tanggal_mulai  = strtotime($dashboard->tanggal_mulai);
							$tangga_berakhir    = strtotime($dashboard->tanggal_berakhir); // Waktu sekarang
							$diff   = $tangga_berakhir - $tanggal_mulai;	
							$selisih= floor($diff / (60 * 60 * 24));
					?>
                    <td><?php echo e($selisih); ?></td>
                    <td><?php echo e($dashboard->tanggal_mulai); ?></td>
					
					<!--Selesai Pekerjaan-->
					<?php
						if($dashboard->realisasi == 0000-00-00){
							$realisasi="";
						}else{
							$realisasi=$dashboard->realisasi;
						}
					?>
                    <td><?php echo e($dashboard->tanggal_berakhir); ?></td>
                    <td><?php echo e($realisasi); ?></td>
					
					<!--BAP-->
					<?php
					$BAP=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','BAP'],])->get()->first();
					if($BAP){
						$BAPno_surat=$BAP->no_surat;
						$BAPtanggal=$BAP->tanggal;
					}else{
						$BAPno_surat="";
						$BAPtanggal="";
					}
					?>
                    <td><?php echo e($BAPno_surat); ?></td>
                    <td><?php echo e($BAPtanggal); ?></td>
					
					<!--BAST-->
					<?php
					$BAST=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','BAST'],])->get()->first();
					if($BAST){
						$BASTno_surat=$BAST->no_surat;
						$BASTtanggal=$BAST->tanggal;
						$BASTharga_pekerjaan=$BAST->harga_pekerjaan;
					}else{
						$BASTno_surat="";
						$BASTtanggal="";
						$BASTharga_pekerjaan="";
					}
					?>
                    <td><?php echo e($BASTno_surat); ?></td>
                    <td><?php echo e($BASTtanggal); ?></td>
                    <td><?php echo e($BASTharga_pekerjaan); ?></td>
					
					<!--Invoice-->
					<?php
					$Invoice=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','SPP'],])->get();
					$Invoice2=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','SPP'],])->get();
					$Invoice3=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','SPP'],])->get();
					?>
                    <td>
					<?php $__currentLoopData = $Invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div style="width:220px;"><?php echo e($Invoice->no_surat); ?></div><br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
                    <td>
					<?php $__currentLoopData = $Invoice2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div style="width:100px;"><?php echo e($Invoice->tanggal); ?></div><br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
                    <td>
					<?php $__currentLoopData = $Invoice3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div style="width:150px;"><?php echo e($Invoice->harga_pekerjaan); ?></div><br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
					
					<!--POPAY-->
					<?php
					$Popay=DB::table('popay')->where('id_laporan_pekerjaan','=',$dashboard->id)->get();
					$Popay2=DB::table('popay')->where('id_laporan_pekerjaan','=',$dashboard->id)->get();
					$Popay3=DB::table('popay')->where('id_laporan_pekerjaan','=',$dashboard->id)->get();
					$Popay4=DB::table('popay')->where('id_laporan_pekerjaan','=',$dashboard->id)->get();
					$Popay5=DB::table('popay')->where('id_laporan_pekerjaan','=',$dashboard->id)->get();
					?>
                    <td>
					<?php $__currentLoopData = $Popay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div style="width:150px;"><?php echo e($popay->nomor_pr); ?></div><br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
                    <td >
					<?php $__currentLoopData = $Popay2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div style="width:100px;"><?php echo e($popay->tanggal_input); ?></div><br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
                    <td>
					<?php $__currentLoopData = $Popay3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div style="width:100px;"><?php echo e($popay->tanggal_paid); ?></div><br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
                    <td>
					<?php $__currentLoopData = $Popay4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div style="width:150px;"><?php echo e($popay->rupiah); ?></div><br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
                    <td>
					<?php $__currentLoopData = $Popay5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div style="width:100px;"><?php echo e($popay->status); ?></div><br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
					
					<!--PPN-->
					<?php
					$PPN=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','SPP'],])->get();
					?>
                    <td>
					<?php $__currentLoopData = $PPN; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PPN): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo e($PPN->harga_pekerjaan * 0.1); ?><br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
					
					<!--PPH-->
                    <td></td>
					
					<!--Jumlah Terbayar-->
					<?php
					$Popay=DB::table('popay')->where('id_laporan_pekerjaan','=',$dashboard->id)->get();
					?>
                    <td>
					<?php $__currentLoopData = $Popay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Popay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
						<?php if($Popay->status == "Paid"): ?>
						<?php echo e($Popay->rupiah); ?>

						<?php endif; ?>
						<br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
					
					<!--Penawaran PGASOL-->
					<?php
					$Penawaran_PGASOL=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','SPH'],])->get();
					?>
                    <td>
					<?php $__currentLoopData = $Penawaran_PGASOL; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Penawaran_PGASOL): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo e($Penawaran_PGASOL->harga_pekerjaan); ?><br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
					
					<!--Selisih Nego-->
					<?php
					$SPK=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','SPK'],])->get()->first();
					$Penawaran_PGASOL=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$dashboard->id],['jenis_dokumen','SPH'],])->get()->first();
					?>
					
                    <td>
					<?php if($SPK and $Penawaran_PGASOL): ?>
					<?php echo e($Penawaran_PGASOL->harga_pekerjaan - $SPK->harga_pekerjaan); ?>

					<?php endif; ?>
					<br>
					</td>
					
					<!--Prosentase-->
                    <td>
					<?php if($SPK and $Penawaran_PGASOL): ?>
					<?php echo e((($Penawaran_PGASOL->harga_pekerjaan - $SPK->harga_pekerjaan)/$Penawaran_PGASOL->harga_pekerjaan)*100); ?>%
					<?php endif; ?>
					<br>
					</td>
					
					<?php $no++; ?>
					</tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
			</div>
			</div>
			</div>
			</div>
			</div>
								
<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'column',
        options3d: {
            enabled: true,
            alpha: 10,
            beta: 25,
            depth: 70
        }
    },
	credits: {
    enabled: false
  },
    title: {
        text: 'Progress Reimbursement'
    },
    subtitle: {
        text: ''
    },
    plotOptions: {
        column: {
            depth: 25
        }
    },
    xAxis: {
        //categories: Highcharts.getOptions().lang.shortMonths,
        categories: [''],
        labels: {
            skew3d: true,
            style: {
                fontSize: '16px'
            }
        }
    },
    yAxis: {
        title: {
            text: null
        }
    },
	<?php
	$usulan=DB::table('laporan_pekerjaan')->where('proses','=','Usulan')->get()->count();
	$Nego=DB::table('laporan_pekerjaan')->where('proses','=','Nego')->get()->count();
	$Pengerjaan=DB::table('laporan_pekerjaan')->where('proses','=','Pengerjaan')->get()->count();
	$Tagihan=DB::table('laporan_pekerjaan')->where('proses','=','Tagihan')->get()->count();
	$Popay=DB::table('laporan_pekerjaan')->where('proses','=','Popay')->get()->count();
	$Paid=DB::table('laporan_pekerjaan')->where('proses','=','Paid')->get()->count();
	?>
    series: [{
        name: 'Usulan',
		color:'green',
        data: [<?php echo e($usulan); ?>]
    },
	
	{
        name: 'Nego',
		color:'Blue',
        data: [<?php echo e($Nego); ?>]
    },
	
	{
        name: 'Pelaksanaan',
		color:'Grey',
        data: [<?php echo e($Pengerjaan); ?>]
    },
	
	{
        name: 'Tagihan',
		color:'Red',
        data: [<?php echo e($Tagihan); ?>]
    },
	
	{
        name: 'Popay',
		color:'chocolate',
        data: [<?php echo e($Popay); ?>]
    },
	
	{
        name: 'Paid',
		color:'yellow',
        data: [<?php echo e($Paid); ?>]
    },
	]
	
	
});
		</script>  
              
<?php $__env->stopSection(); ?>
<script src="<?php echo URL::to('/'); ?>/haightcart/code/highcharts.js"></script>
<script src="<?php echo URL::to('/'); ?>/haightcart/code/highcharts-3d.js"></script>
<script src="<?php echo URL::to('/'); ?>/haightcart/code/modules/exporting.js"></script>
<script src="<?php echo URL::to('/'); ?>/haightcart/code/modules/export-data.js"></script>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>