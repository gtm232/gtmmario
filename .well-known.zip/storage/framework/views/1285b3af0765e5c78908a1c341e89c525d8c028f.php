<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
				

                <div class="row page-titles">
                    <div class="col-md-12 col-12 align-self-center" style="text-align:center; margin-bottom:10px;">
                        <h3 class="text-themecolor m-b-0 m-t-0">Rencana Pembayaran</h3>
                     
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
			
			<br>	
			<?php
				$dolap=DB::table('dokumen_laporan_pekerjaan')->where('id',$id)->get()->first();
				$dolap2=DB::table('spk_dev')->where('id_dokumen',$id)->sum('persentasi');
				$hasil_dolap=($dolap2/100)*$dolap->harga;
				$hasil_dolap2=$dolap->harga-$hasil_dolap;
			if($hasil_dolap2!=0){
			?>
            <form style="margin:10px 0px 0px 20px;" action="<?php echo url('/tambah_spk_dev'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id" value="<?php echo e($id); ?>">
						<button type="submit" class="btn btn-info">Tambah</button>
			</form>
			<?php
			}
			?>
          
            <div class="card-body ">
              <div class="table-responsive" style="margin:20px;">
			
                <table style="font-size:10px;" class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Tahun</th>
                      <th>Persentasi</th>
                      <th>Nilai</th>
                      <th>Keterangan</th>
                     
					  <th>Opsi</th>
				
					  
                    </tr>
                  </thead>
                  
                  <tbody>
				 
				  <?php $no=1; 
				  $spk_dev=DB::table('spk_dev')->where('id_dokumen',$id)->get();
				  ?>
				  <?php $__currentLoopData = $spk_dev; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spk_dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($spk_dev->tahun); ?></td>
						<td><?php echo e($spk_dev->persentasi); ?></td>
						<td><?php echo e(number_format(($spk_dev->persentasi / 100) * $dolap->harga,2,',','.')); ?></td>
						<td><?php echo e($spk_dev->keterangan); ?></td>
						<td>
							<table>
							<tr>
								<td style="border: 0px;">
									<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('edit<?php echo e($no); ?>').submit()"><i class="material-icons">delete</i></a> 
									<form id="edit<?php echo e($no); ?>" style="display:none; float:left; margin-right:5px;" action="<?php echo url('/spk_dev_delete'); ?>" method="post">
										<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
										<input type="hidden" name="id_spk_dev" value="<?php echo e($spk_dev->id); ?>">
										<input type="hidden" name="id" value="<?php echo e($id); ?>">
										<button type="submit" class="btn btn-primary">Edit</button></a>
									</form>
								</td>
								
								<td style="border: 0px;">
									<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('popay<?php echo e($no); ?>').submit()"><i class="material-icons">monetization_on</i></a>  
									<form style="display:none;" id="popay<?php echo e($no); ?>" action="<?php echo url('/popaylist'); ?>" method="post">
										<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
										<input type="hidden" name="id_spk_dev" value="<?php echo e($spk_dev->id); ?>">
										<input type="hidden" name="harga" value="<?php echo e(($spk_dev->persentasi / 100) * $dolap->harga); ?>">
										<button type="submit" class="btn btn-primary">POPAY</button></a>
									</form>
								</td>
								
							</tr>
							</table>
						</td>
					</tr>
					<?php $no++; ?>
				  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
                  </tbody>
                </table>
              </div>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<script type="text/javascript">
   function dokumen(value) {
	  
	$('#text').val(value);
	document.getElementById('bln').submit()
}
</script> 
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>