<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Tambah Data</h2>
			<form class="form-line" action="<?php echo url('/tambah_history_proses'); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="id_laporan_pekerjaan" class="form-control" value="<?php echo e($id_laporan_pekerjaan); ?>">
				<input type="hidden" name="id_pembuatan_surat" class="form-control" value="<?php echo e($id_pembuatan_surat); ?>">
				<input type="hidden" name="akses" class="form-control" value="admin">
				
				<div class="form-line">
					<label for="exampleInputPassword1">Penerima</label>
					<select class="form-control" name="pic" id="file" required>
					<?php
					$users=DB::table('users')->get();
					?>
						<option value="">--Pilih PIC--</option>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($users->id); ?>"><?php echo e($users->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				<div class="form-line">
					<label for="exampleInputPassword1">File</label>
					<input type="file" class="form-control" name="file" onchange="validasiFile()" id="file" required>
				</div>
				
				<br>
				<div class="form-line">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>