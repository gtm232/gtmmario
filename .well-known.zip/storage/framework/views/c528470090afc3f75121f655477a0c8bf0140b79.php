<?php $__env->startSection('content'); ?>

<?php
function penyebut($nilai) {
		$nilai = abs($nilai);
		$huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
		$temp = "";
		if ($nilai < 12) {
			$temp = " ". $huruf[$nilai];
		} else if ($nilai <20) {
			$temp = penyebut($nilai - 10). " belas";
		} else if ($nilai < 100) {
			$temp = penyebut($nilai/10)." puluh". penyebut($nilai % 10);
		} else if ($nilai < 200) {
			$temp = " seratus" . penyebut($nilai - 100);
		} else if ($nilai < 1000) {
			$temp = penyebut($nilai/100) . " ratus" . penyebut($nilai % 100);
		} else if ($nilai < 2000) {
			$temp = " seribu" . penyebut($nilai - 1000);
		} else if ($nilai < 1000000) {
			$temp = penyebut($nilai/1000) . " ribu" . penyebut($nilai % 1000);
		} else if ($nilai < 1000000000) {
			$temp = penyebut($nilai/1000000) . " juta" . penyebut($nilai % 1000000);
		} else if ($nilai < 1000000000000) {
			$temp = penyebut($nilai/1000000000) . " milyar" . penyebut(fmod($nilai,1000000000));
		} else if ($nilai < 1000000000000000) {
			$temp = penyebut($nilai/1000000000000) . " trilyun" . penyebut(fmod($nilai,1000000000000));
		}     
		return $temp;
	}
 
	function terbilang($nilai) {
		if($nilai<0) {
			$hasil = "minus ". trim(penyebut($nilai));
		} else {
			$hasil = trim(penyebut($nilai));
		}     		
		return $hasil;
	}
 
 
	
	?>
	<div class="row">
		<div class="col-md-12">
		<?php
		if($jd == "Undangan"){
		?>
				<!-- content -->
				<h2>Tambah Data</h2>
				<form class="form-group" action="<?php echo url('/tambah_dokumen_proses'); ?>" method="post"> 				
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">				
					<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">				
					<input type="hidden" name="jenis_dokumen" value="<?php echo e($jd); ?>"> 	
					
					<div class="form-group">					
						<label for="judul">Nomor Surat</label>					
						<input type="text" name="nomor_surat" class="form-control" required="required">				
					</div>		
					
					<div class="form-group">					
						<label for="judul">Sifat</label>					
						<input type="text" name="sifat" class="form-control" value="Segera" required="required">				
					</div>			
					
					<div class="form-group">					
						<label for="judul">Lampiran</label>					
						<input type="text" name="lampiran" class="form-control" value="-" required="required">				
					</div>								
					
					<div class="form-group">					
						<label for="judul">Perihal</label>										
						<?php					
						$pekerjaan=DB::table('laporan_pekerjaan')->where('id',$id_laporan_pekerjaan)->get()->first();					
						$perihal="Undangan Rapat Klarifikasi dan Negosiasi Harga ".$pekerjaan->nama_pekerjaan;									
						?>					
						<input type="text" name="perihal" class="form-control" value="<?php echo e($perihal); ?>" required="required">				
					</div>								
					
					<div class="form-group">					
						<label >Tanggal Surat</label>					  
						<input style="background:#ffff;" type="text" class="form-control" id="tgl" autocomplete="off" name="tanggal_surat" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>									
					</div>								
					
					<div class="form-group">					
						<label for="judul">Tujuan</label>					
							<input type="text" name="tujuan" class="form-control" value="Project Manager MARIO PT. PGAS SOLUTION" required="required">				
					</div>
						
						<div class="form-group">
							<label for="judul">Alamat</label>
							<input type="text" name="alamat" class="form-control" value="Komplek PGN, Gedung C.Jl. KH Zainul Arifin No. 20 Jakarta 11140" required="required">				
						</div>								
					
					<div class="form-group">					
					<?php					
					$ju=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','Usulan'],])->get()->count();
					if($ju == 1){
						$nom=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','Usulan'],])->get()->first();
					}else if($ju > 1){
						$nom=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','Usulan'],])->get();					
					}else{
						$ju=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','SPH'],])->get()->count();
						if($ju == 1){
							$nom=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','SPH'],])->get()->first();
						}else if($ju > 1){
							$nom=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','SPH'],])->get();
						}
					}										
					?> 					
					<label for="isi">Isi</label>					
					<textarea name="isi" id="catatan">					
					<?php 		
					if($ju == 1){
					$tgl=date('d',strtotime ($nom->tanggal)); 					
					$bln1=date('M',strtotime ($nom->tanggal));					
					if($bln1 == "Jan"){					
					$bln="Januari";						
					}else if($bln1 == "Feb"){					
					$bln="Februari";						
					}else if($bln1 == "Mar"){					
					$bln="Maret";						
					}else if($bln1 == "Apr"){					
					$bln="April";						
					}else if($bln1 == "May"){					
					$bln="Mei";						
					}else if($bln1 == "Jun"){					
					$bln="Juni";						
					}else if($bln1 == "Jul"){					
					$bln="Juli";						
					}else if($bln1 == "Jan"){					
					$bln="Januari";						
					}else if($bln1 == "Aug"){					
					$bln="Agustus";						
					}else if($bln1 == "Sep"){					
					$bln="September";						
					}else if($bln1 == "Oct"){					
					$bln="Oktober";						
					}else if($bln1 == "Nov"){					
					$bln="November";						
					}else if($bln1 == "Dec"){					
					$bln="Desember";						
					} 					
					$thn=date('Y',strtotime ($nom->tanggal));	
					
					?>					
					Menindaklanjuti Surat Saudara nomor: <?php echo e($nom->no_surat); ?> perihal <?php echo e($nom->prihal); ?> tanggal <?php echo e($tgl); ?> <?php echo e($bln); ?> <?php echo e($thn); ?>, dengan ini kami mengundang Saudara untuk hadir pada :					
					<?php 
					} else if($ju > 1){ 
					$no=1;
					?>
					Menindaklanjuti Surat Usulan Pekerjaan Perbaikan dari PT PGAS Solution yaitu :
					<table style="margin-top:-10px;">
					<?php $__currentLoopData = $nom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
					$tgl=date('d',strtotime ($nom->tanggal)); 					
					$bln1=date('M',strtotime ($nom->tanggal));					
					if($bln1 == "Jan"){					
					$bln="Januari";						
					}else if($bln1 == "Feb"){					
					$bln="Februari";						
					}else if($bln1 == "Mar"){					
					$bln="Maret";						
					}else if($bln1 == "Apr"){					
					$bln="April";						
					}else if($bln1 == "May"){					
					$bln="Mei";						
					}else if($bln1 == "Jun"){					
					$bln="Juni";						
					}else if($bln1 == "Jul"){					
					$bln="Juli";						
					}else if($bln1 == "Jan"){					
					$bln="Januari";						
					}else if($bln1 == "Aug"){					
					$bln="Agustus";						
					}else if($bln1 == "Sep"){					
					$bln="September";						
					}else if($bln1 == "Oct"){					
					$bln="Oktober";						
					}else if($bln1 == "Nov"){					
					$bln="November";						
					}else if($bln1 == "Dec"){					
					$bln="Desember";						
					} 					
					$thn=date('Y',strtotime ($nom->tanggal));	
					?>
						<tr>
							<td valign="top"><?php echo e($no); ?></td>
							<td valign="top">.</td>
							<td valign="top"><?php echo e($nom->prihal); ?> nomor: <?php echo e($nom->no_surat); ?> tanggal <?php echo e($tgl); ?> <?php echo e($bln); ?> <?php echo e($thn); ?></td> <br>
						</tr>
					<?php $no++; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					<?php } ?>
					<?php if($ju > 1){ ?>
					kami mengundang Saudara untuk hadir pada :
					<?php } ?>
					<table style="margin-left:40px; margin-top:-10px;" border="0">						
					
						<tr>							
							<td valign="top">Hari/Tanggal</td>							
							<td valign="top">:</td>							
							<td valign="top"></td>						
						</tr>										
						
						<tr>							
							<td valign="top">Waktu</td>							
							<td valign="top">:</td>							
							<td valign="top"></td> 						
						</tr>												
						
						<tr>							
							<td valign="top">Tempat</td>							
							<td valign="top">:</td>							
							<td valign="top" align="justify">Ruang Rapat GTM, Graha PGAS Lantai 5 Jl. KH Zainul Arifin No. 20 Jakarta Barat.</td>				
						</tr>												
						
						<tr>							
							<td valign="top">Agenda</td>							
							<td valign="top">:</td>							
							<td valign="top" align="justify"><?php echo e($perihal); ?></td>						
						</tr>					
					
					</table>										
					<br>															
					</textarea>					
					<script>					
					CKEDITOR.replace('catatan', {removePlugins: 'about,link,elementspath'});					
					</script>				
					</div>								
					<button type="submit" class="btn btn-info">Tambah</button>		
				</form>
		<?php
		}else if($jd == "BA Nego"){
			$angka = $harga_kesepakatan;
		?>
				<form class="form-group" action="<?php echo url('/tambah_dokumen_proses'); ?>" method="post"> 				
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">				
					<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">				
					<input type="hidden" name="jenis_dokumen" value="<?php echo e($jd); ?>"> 	
					
					<div class="form-group">					
						<label for="judul">Nomor Surat</label>					
						<input type="text" name="nomor_surat" class="form-control" required="required">				
					</div>		
					
					<div class="form-group">					
						<label for="judul">Perihal</label>										
						<?php					
						$pekerjaan=DB::table('laporan_pekerjaan')->where('id',$id_laporan_pekerjaan)->get()->first();					
						$perihal="BERITA ACARA KLARIFIKASI dan NEGOSIASI HARGA ".$pekerjaan->nama_pekerjaan;									
						?>					
						<input type="text" name="perihal" class="form-control" value="<?php echo e($perihal); ?>" required="required">				
					</div>								
					
					<div class="form-group">					
						<label >Tanggal Surat</label>					  
						<input style="background:#ffff;" type="text" class="form-control" id="tgl" autocomplete="off" name="tanggal_surat" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>									
					</div>
					
					<div class="form-group">					
					<?php					
					$nom=DB::table('dokumen_laporan_pekerjaan')->where('id_laporan_pekerjaan',$id_laporan_pekerjaan)->orderBy('no_urut', 'ASC')->get();
					$nom_und=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','Undangan Nego'],])->orderBy('no_urut', 'DESC')->get()->first();
					$no=2;										
					?> 
					<?php
					$pic1=DB::table('pic_area')->where('id',$pic1)->get()->first();
					$pic2=DB::table('pic_area')->where('id',$pic2)->get()->first();
					$pic3=DB::table('pic_area')->where('id',$pic3)->get()->first();
					$pic4=DB::table('pic_area')->where('id',$pic4)->get()->first();
					$pic5=DB::table('pic_area')->where('id',$pic5)->get()->first();
					?>					
					<textarea name="namapic" id="catatan2">
					<b>PT Perusahaan Gas Negara Tbk</b><br>
							<table style="margin-top:5px;">
								<tr>
									<td width="100">Nama</td>
									<td width="5">:</td>
									<td><?php echo e($pic1->nama); ?></td>
								</tr>
								<tr>
									<td>Jabatan</td>
									<td>:</td>
									<td><?php echo e($pic1->jabatan); ?></td>
								</tr>
							</table>
							
							<table style="margin-top:5px;">
								<tr>
									<td width="100">Nama</td>
									<td width="5">:</td>
									<td><?php echo e($pic2->nama); ?></td>
								</tr>
								<tr>
									<td>Jabatan</td>
									<td>:</td>
									<td><?php echo e($pic2->jabatan); ?></td>
								</tr>
							</table>
							
							<table style="margin-top:5px;">
								<tr>
									<td width="100">Nama</td>
									<td width="5">:</td>
									<td><?php echo e($pic3->nama); ?></td>
								</tr>
								<tr>
									<td>Jabatan</td>
									<td>:</td>
									<td><?php echo e($pic3->jabatan); ?></td>
								</tr>
							</table>
							<div style="margin-top:5px;">disebut <b>"PIHAK PERTAMA".</b></div>
							<br>
							
							PT PGAS Solution<br>
							<table style="margin-top:5px;">
								<tr>
									<td width="100">Nama</td>
									<td width="5">:</td>
									<td><?php echo e($pic4->nama); ?></td>
								</tr>
								<tr>
									<td>Jabatan</td>
									<td>:</td>
									<td><?php echo e($pic4->jabatan); ?></td>
								</tr>
							</table>
							
							<table style="margin-top:5px;">
								<tr>
									<td width="100">Nama</td>
									<td width="5">:</td>
									<td><?php echo e($pic5->nama); ?></td>
								</tr>
								<tr>
									<td>Jabatan</td>
									<td>:</td>
									<td><?php echo e($pic5->jabatan); ?></td>
								</tr>
							</table>
							<div style="margin-top:5px;">disebut <b>"PIHAK KEDUA".</b></div><br>
							<b>PIHAK PERTAMA</b> dengan <b>PIHAK KEDUA</b> secara bersama-sama disebut <b>"PARA PIHAK"</b>
					</textarea>
					<label for="isi">Isi</label>					
					<textarea name="isi" id="catatan">
					<b>PARA PIHAK</b> menerangkan terlebih dahulu hal-hal sebagai berikut : <br><br>
					Berdasarkan :
					<table style="margin-left:10px;">
					<tr>
							<td valign="top">1.</td>
							<td valign="top">Perjanjian antara PT Perusahaan Gas Negara Tbk Business Unit Infrastructure dan PT PGAS Solution tentang Amandemen Terhadap Perjanjian nomor: 054000.PK/HK.02/BU.INFRA/2017 antara PT Perusahaan Gas Negara Tbk Business Unit Infrastructure dan PT PGAS Solution Untuk Melaksanakan Manajemen Aset Reliabilitas Infrastruktur Operasi dan Sistem Manajemen Gas (MARIO&SIMAG) nomor: 047600.PK/HK.02/BUI/2018 tanggal 31 Desember 2018;</td>
					</tr>
					<?php $__currentLoopData = $nom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
					$tgl=date('d',strtotime ($nom->tanggal)); 					
					$bln1=date('M',strtotime ($nom->tanggal));					
					if($bln1 == "Jan"){					
					$bln="Januari";						
					}else if($bln1 == "Feb"){					
					$bln="Februari";						
					}else if($bln1 == "Mar"){					
					$bln="Maret";						
					}else if($bln1 == "Apr"){					
					$bln="April";						
					}else if($bln1 == "May"){					
					$bln="Mei";						
					}else if($bln1 == "Jun"){					
					$bln="Juni";						
					}else if($bln1 == "Jul"){					
					$bln="Juli";						
					}else if($bln1 == "Jan"){					
					$bln="Januari";						
					}else if($bln1 == "Aug"){					
					$bln="Agustus";						
					}else if($bln1 == "Sep"){					
					$bln="September";						
					}else if($bln1 == "Oct"){					
					$bln="Oktober";						
					}else if($bln1 == "Nov"){					
					$bln="November";						
					}else if($bln1 == "Dec"){					
					$bln="Desember";						
					}		
					$thn=date('Y',strtotime ($nom->tanggal));	
					if($nom->no_urut <= $nom_und->no_urut){
					?>
					
						<tr>
							<td valign="top"><?php echo e($no); ?>.</td>
							<td valign="top"><?php echo e($nom->prihal); ?> nomor: <?php echo e($nom->no_surat); ?> tanggal <?php echo e($tgl); ?> <?php echo e($bln); ?> <?php echo e($thn); ?></td>
						</tr>
					<?php } $no++; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
					
					Telah dilaksanakan klarifikasi dan negosiasi harga untuk pekerjaan tersebut dengan hasil sebagai berikut  :
							
					<table style="margin-left:10px;">
						<tr>
							<td valign="top">1</td>
							<td valign="top">.</td>
							<td valign="top"><b>PIHAK KEDUA</b> menyetujui akan melakukan <?php echo e($pekerjaan->nama_pekerjaan); ?> sesuai Kerangka Acuan Kerja (KAK);</td>
						</tr>
						
						<tr>
							<td valign="top">2</td>
							<td valign="top">.</td>
							<td valign="top"><b>PARA PIHAK</b> sepakat bahwa <?php echo e($pekerjaan->nama_pekerjaan); ?> dilakukan selama <b><?php echo e($masa_pekerjaan); ?> hari kalender</b> dimulai dari terbitnya Surat Perintah Kerja (SPK);</td>
						</tr>
						
						<tr>
							<td valign="top">3</td>
							<td valign="top">.</td>
							<td valign="top">
							Total harga pekerjaan yang telah disepakati adalah sebesar  <b>Rp <?php echo e(number_format($harga_kesepakatan,2,',','.')); ?>,-</b> <br>(terbilang: <?php echo e(ucfirst(terbilang($angka))); ?> rupiah ), sebagaimana di bawah ini :<br>
							<table border="1" style="margin-top:8px;">
								<tr>
									<td width="50%" align="center">Uraian Kegiatan</td>
									<td align="center">Harga Penawaran</td>
									<td align="center">Harga Negosiasi</td>
									<td align="center">Persentasi Penurunan</td>
								</tr>
								<tr>
									<td width="50%" style="padding:3px;"><?php echo e($pekerjaan->nama_pekerjaan); ?></td>
									<td align="center" style="padding:3px;"><?php echo e(number_format($harga_penawaran,2,',','.')); ?></td>
									<td align="center" style="padding:3px;"><?php echo e(number_format($harga_kesepakatan,2,',','.')); ?></td>
									<td align="center" style="padding:3px;"><?php echo e(round((($harga_penawaran-$harga_kesepakatan)/$harga_penawaran)*100,2)); ?> %</td>
								</tr>
							</table>
							</td>
						</tr>
						
						<tr>
							<td valign="top">4</td>
							<td valign="top">.</td>
							<td valign="top">Seluruh kesepakatan sebagaimana tersebut diatas akan berlaku setelah Surat Perintah Kerja (SPK) mendapat persetujuan <b>PARA PIHAK</b>.</td>
						</tr>
					</table>
					
					Demikian Berita Acara ini dibuat dan ditandatangani pada hari, tanggal, bulan dan tahun sebagaimana tersebut di atas.
					
				
					
					<table style="width:55%; float:left; font-size:10px;" border="1">
						<tr>
							<td align="center" colspan="3" style="font-size:15px;"><b>PT PERUSAHAAN GAS NEGARA TBK</b></td>
						</tr>
						<tr>
							<td height="120px"></td>
							<td></td>
							<td></td>
						</tr>
						<tr>
							<td width="33.3%" align="center" height="30"><?php echo e($pic1->nama); ?></td>
							<td width="33.3%" align="center" height="30"><?php echo e($pic2->nama); ?></td>
							<td width="33.3%" align="center" height="30"><?php echo e($pic3->nama); ?></td>
						</tr>
						<tr>
							<td align="center" height="30"><?php echo e($pic1->jabatan); ?></td>
							<td align="center" height="30"><?php echo e($pic2->jabatan); ?></td>
							<td align="center" height="30"><?php echo e($pic3->jabatan); ?></td>
						</tr>
					</table>
					
					<table style="width:35%; float:right; font-size:10px;" border="1">
						<tr>
							<td align="center" colspan="2" style="font-size:15px;"><b>PT PGAS Solution</b></td>
						</tr>
						<tr>
							<td height="120px"></td>
							<td></td>
						</tr>
						<tr>
							<td align="center" width="50%" height="30"><?php echo e($pic4->nama); ?></td>
							<td align="center" width="50%" height="30"><?php echo e($pic5->nama); ?></td>
						</tr>
						<tr>
							<td align="center" height="30"><?php echo e($pic4->jabatan); ?></td>
							<td align="center" height="30"><?php echo e($pic5->jabatan); ?></td>
						</tr>
					</table>
					</textarea>					
									
					</div>
					<button type="submit" class="btn btn-info">Tambah</button>
					</form>
		<?php
		}else if($jd == "SPK"){
		?>
					<h2>Tambah Data</h2>
				<form class="form-group" action="<?php echo url('/tambah_dokumen_proses'); ?>" method="post"> 				
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">				
					<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">				
					<input type="hidden" name="jenis_dokumen" value="<?php echo e($jd); ?>"> 	
					
					<div class="form-group">					
						<label for="judul">Nomor Surat</label>					
						<input type="text" name="nomor_surat" class="form-control" required="required">				
					</div>		
					
					<div class="form-group">					
						<label for="judul">Sifat</label>					
						<input type="text" name="sifat" class="form-control" value="Segera" required="required">				
					</div>			
					
					<div class="form-group">					
						<label for="judul">Lampiran</label>					
						<input type="text" name="lampiran" class="form-control" value="-" required="required">				
					</div>								
					
					<div class="form-group">					
						<label for="judul">Perihal</label>
						<input style="background:#ffff;" type="hidden" class="form-control" id="tgl" autocomplete="off" name="tanggal_surat" value="<?php echo date('d F Y',strtotime ($tanggal_surat)) ; ?>" readonly>						
						<?php					
						$pekerjaan=DB::table('laporan_pekerjaan')->where('id',$id_laporan_pekerjaan)->get()->first();					
						$perihal="Surat Perintah Kerja (SPK) ".$pekerjaan->nama_pekerjaan;									
						?>					
						<input type="text" name="perihal" class="form-control" value="<?php echo e($perihal); ?>" required="required">				
					</div>													
					
					<div class="form-group">					
						<label for="judul">Tujuan</label>					
							<input type="text" name="tujuan" class="form-control" value="Project Manager MARIO PT. PGAS SOLUTION" required="required">				
					</div>
						
						<div class="form-group">
							<label for="judul">Alamat</label>
							<input type="text" name="alamat" class="form-control" value="Komplek PGN, Gedung C.Jl. KH Zainul Arifin No. 20 Jakarta 11140" required="required">				
						</div>								
					
					<div class="form-group">					
					<?php					
					$nom=DB::table('dokumen_laporan_pekerjaan')->where('id_laporan_pekerjaan',$id_laporan_pekerjaan)->orderBy('no_urut', 'ASC')->get();
					$nom_BANego=DB::table('dokumen_laporan_pekerjaan')->where([['id_laporan_pekerjaan',$id_laporan_pekerjaan],['jenis_dokumen','BA Nego'],])->orderBy('no_urut', 'DESC')->get()->first();
					$no=2;										
					?> 

					<label for="isi">Isi</label>					
					<textarea name="isi" id="catatan">
					Berdasarkan :
					<table style="margin-left:10px;">
					<tr>
							<td valign="top">1</td>
							<td valign="top">.</td>
							<td valign="top">Perjanjian antara PT Perusahaan Gas Negara Tbk Business Unit Infrastructure dan PT PGAS Solution tentang Amandemen Terhadap Perjanjian nomor: 054000.PK/HK.02/BU.INFRA/2017 antara PT Perusahaan Gas Negara Tbk Business Unit Infrastructure dan PT PGAS Solution Untuk Melaksanakan Manajemen Aset Reliabilitas Infrastruktur Operasi dan Sistem Manajemen Gas (MARIO&SIMAG) nomor: 047600.PK/HK.02/BUI/2018 tanggal 31 Desember 2018;</td>
					</tr>
					<?php $__currentLoopData = $nom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
					$tgl=date('d',strtotime ($nom->tanggal)); 					
					$bln1=date('M',strtotime ($nom->tanggal));					
					if($bln1 == "Jan"){					
					$bln="Januari";						
					}else if($bln1 == "Feb"){					
					$bln="Februari";						
					}else if($bln1 == "Mar"){					
					$bln="Maret";						
					}else if($bln1 == "Apr"){					
					$bln="April";						
					}else if($bln1 == "May"){					
					$bln="Mei";						
					}else if($bln1 == "Jun"){					
					$bln="Juni";						
					}else if($bln1 == "Jul"){					
					$bln="Juli";						
					}else if($bln1 == "Jan"){					
					$bln="Januari";						
					}else if($bln1 == "Aug"){					
					$bln="Agustus";						
					}else if($bln1 == "Sep"){					
					$bln="September";						
					}else if($bln1 == "Oct"){					
					$bln="Oktober";						
					}else if($bln1 == "Nov"){					
					$bln="November";						
					}else if($bln1 == "Dec"){					
					$bln="Desember";						
					}		
					$thn=date('Y',strtotime ($nom->tanggal));	
					if($nom->no_urut <= $nom_BANego->no_urut){
					?>
					
						<tr>
							<td valign="top"><?php echo e($no); ?></td>
							<td valign="top">.</td>
							<td valign="top"><?php echo e($nom->prihal); ?> nomor: <?php echo e($nom->no_surat); ?> tanggal <?php echo e($tgl); ?> <?php echo e($bln); ?> <?php echo e($thn); ?></td> <br>
						</tr>
					<?php } $no++; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table><br>
					Dengan ini kami instruksikan kepada PT PGAS Solution untuk melaksanakan <b><?php echo e($pekerjaan->nama_pekerjaan); ?></b> dengan detail sebagai berikut :
					<table>
						<tr>
							<td valign="top" width="170">Lokasi Pekerjaan</td>
							<td valign="top">:</td>
							<td><?php echo e($lokasi_pekerjaan); ?></td>
						</tr>
						<tr>
						<?php
						$tgl1 = date('Y-m-d',strtotime ($tanggal_surat));// pendefinisian tanggal awal
						$tgl2 = date('Y-m-d', strtotime(($masa_pekerjaan-1).'days', strtotime($tgl1))); //operasi penjumlahan tanggal sebanyak 6 hari
						//echo $tgl2; //print tanggal
							$tgl=date('d',strtotime ($tanggal_surat)); 					
							$bln1=date('M',strtotime ($tanggal_surat));
							$tgl_berakhir=date('d',strtotime ($tgl2)); 					
							$bulan_berakhir1=date('M',strtotime ($tgl2));		
							if($bln1 == "Jan"){					
							$bln="Januari";
							}else if($bln1 == "Feb"){					
							$bln="Februari";
							}else if($bln1 == "Mar"){					
							$bln="Maret";
							}else if($bln1 == "Apr"){					
							$bln="April";
							}else if($bln1 == "May"){					
							$bln="Mei";
							}else if($bln1 == "Jun"){					
							$bln="Juni";
							}else if($bln1 == "Jul"){					
							$bln="Juli";
							}else if($bln1 == "Aug"){					
							$bln="Agustus";
							}else if($bln1 == "Sep"){					
							$bln="September";
							}else if($bln1 == "Oct"){					
							$bln="Oktober";
							}else if($bln1 == "Nov"){					
							$bln="November";
							}else if($bln1 == "Dec"){					
							$bln="Desember";
							}		
							
							if($bulan_berakhir1 == "Jan"){
							$bulan_berakhir="Januari";
							}else if($bulan_berakhir1 == "Feb"){
							$bulan_berakhir="Februari";
							}else if($bulan_berakhir1 == "Mar"){
							$bulan_berakhir="Maret";
							}else if($bulan_berakhir1 == "Apr"){	
							$bulan_berakhir="April";
							}else if($bulan_berakhir1 == "May"){
							$bulan_berakhir="Mei";
							}else if($bulan_berakhir1 == "Jun"){
							$bulan_berakhir="Juni";
							}else if($bulan_berakhir1 == "Jul"){
							$bulan_berakhir="Juli";
							}else if($bulan_berakhir1 == "Aug"){		
							$bulan_berakhir="Agustus";
							}else if($bulan_berakhir1 == "Sep"){
							$bulan_berakhir="September";
							}else if($bulan_berakhir1 == "Oct"){
							$bulan_berakhir="Oktober";
							}else if($bulan_berakhir1 == "Nov"){
							$bulan_berakhir="November";
							}else if($bulan_berakhir1 == "Dec"){
							$bulan_berakhir="Desember";
							}		
							$thn=date('Y',strtotime ($tanggal_surat));
							$thn_berakhir=date('Y',strtotime ($tgl2));
					
						?>
							<td valign="top">Jangka Waktu</td>
							<td valign="top">:</td>
							<td>
							Jangka waktu pelaksanaan Pekerjaan adalah paling lambat <b><?php echo e($masa_pekerjaan); ?> (<?php echo e(ucfirst(terbilang($masa_pekerjaan))); ?>)</b> hari kalender terhitung 
							sejak dimulainya Pekerjaan pada tanggal <?php echo e($tgl); ?> <?php echo e($bln); ?> <?php echo e($thn); ?> dan berakhir pada tanggal <?php echo e($tgl_berakhir); ?> <?php echo e($bulan_berakhir); ?> <?php echo e($thn_berakhir); ?>, 
							yang dibuktikan dengan Berita Acara Serah Terima (<b>"BAST"</b>) dan didahului oleh Berita Acara Pemeriksaan (<b>"BAP"</b>)
							</td>
						</tr>
						<tr>
							<td valign="top">Nilai Pekerjaan</td>
							<td valign="top">:</td>
							<td><b><?php echo e($harga_pekerjaan); ?> ,- (harga termasuk pajak-pajak)</b></td>
						</tr>
						<tr>
						<?php
						$hp1=substr($harga_pekerjaan,3);
						$hp=str_replace(".", "", $hp1);
						?>
							<td valign="top">Terbilang</td>
							<td valign="top">:</td>
							<td valign="top"><?php echo e(ucfirst(terbilang($hp))); ?> rupiah</td>
						</tr>
						<tr>
							<td valign="top">Ketentuan Lain</td>
							<td valign="top">:</td>
							<td align="justify">
							Tata Cara Pembayaran :<br><br>
							Pembayaran akan dilakukan setelah ditandatanganinya Berita Acara Serah Terima (<b>"BAST"</b>) yang didahului 
							dengan Berita Acara Pemeriksaan (<b>"BAP"</b>) dengan Prosentase 100% Realisasi fisik pekerjaan dan Pembayaran 
							100% dari biaya pelaksanaan pekerjaan.<br><br>
							
							Mekanisme pengukuran hasil pekerjaan, termasuk didalamnya denda yang berlaku, mengikuti persyaratan yang tertulis
							dalam dokumen kontrak MARIO SIMAG.
							</td>
						</tr>
					</table>
					</textarea>	
									
					</div>								
					<button type="submit" class="btn btn-info">Tambah</button>		
				</form>
		<?php
		}
		?>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>