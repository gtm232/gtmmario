<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-12 col-12 align-self-center" style="text-align:center; margin-bottom:15px;">
                        <h3 class="text-themecolor m-b-0 m-t-0">Laporan Pekerjaan</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
                               
			
           
			<br>
            <div class="card-body ">
              <div class="table-responsive" style="margin:0px 15px 10px 15px;">
			  <?php
			$laporan_pekerjaan=DB::table('laporan_pekerjaan')->where('id','=',$id_laporan_pekerjaan)->get()->first();
			if($laporan_pekerjaan->pic == Auth::user()->id or Auth::user()->hak_akses == "admin"){
			?>
            <form style="float:left; margin:0px 5px 10px;" action="<?php echo url('/tambah_dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
						<button type="submit" class="btn btn-info">Tambah</button></a>
			</form>
			<?php
			}
			?>
			
			<form  action="<?php echo url('/pembuatan_surat'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
						<button type="submit" class="btn btn-info">Buat Dokumen</button></a>
			</form>
			
					<br>
			
			<br>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Nomor Surat</th>
                      <th>Perihal</th>
					  <th>Tanggal</th>
					  <?php
					  if(Auth::user()->hak_akses == "admin" or $laporan_pekerjaan->pic == Auth::user()->id){
					  ?>
					  <th>Opsi</th>
					  <?php } ?>
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php 
				  $no=1;
				  $dokumen_laporan_pekerjaan=DB::table('dokumen_laporan_pekerjaan')->where('id_laporan_pekerjaan','=',$id_laporan_pekerjaan)->orderBy('no_urut', 'DESC')->get();
				  ?>
				  <?php $__currentLoopData = $dokumen_laporan_pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->no_surat); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->nama); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e(date('d-m-Y',strtotime($pkn->tanggal))); ?></div></a></td>
					  
                      
					   <div style="display:none;">
					<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/lihat_dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
						<input type="hidden" name="id" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
					</form>
					  </div>
					 
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td>
						<table>
							<tr>
							
							<?php
								if($pkn->jenis_dokumen == "SPK"){
							?>
							<td style="border:0px;">
							<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('spk_dev<?php echo e($no); ?>').submit()"><i class="material-icons">filter_frames</i></a> 
							<form id="spk_dev<?php echo e($no); ?>" style="display:none; float:left; margin-right:5px;" action="<?php echo url('/spk_dev'); ?>" method="post">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
								<input type="hidden" name="id" value="<?php echo e($pkn->id); ?>">
								<button type="submit" class="btn btn-primary">Edit</button></a>
							</form>
							</td>
							<?php
								}
							?>
							
							<td style="border:0px;">
							<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('edit<?php echo e($no); ?>').submit()"><i class="material-icons">create</i></a> 
							<form id="edit<?php echo e($no); ?>" style="display:none; float:left; margin-right:5px;" action="<?php echo url('/edit_dokumen_pekerjaan'); ?>" method="post">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
								<input type="hidden" name="id" value="<?php echo e($pkn->id); ?>">
								<button type="submit" class="btn btn-primary">Edit</button></a>
							</form>
							</td>
				
							<td style="border:0px;">
							<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('hapus<?php echo e($no); ?>').submit()"><i class="material-icons">delete</i></a>
							<form style="display:none;" id="hapus<?php echo e($no); ?>" method="post" action="<?php echo url('/hapus_dokumen_pekerjaan'); ?>">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id" value="<?php echo e($pkn->id); ?>">
								<input type="hidden" name="file" value="<?php echo e($pkn->file); ?>">
								<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
								<input type="submit" class="btn btn-danger" value="Delete" />
							</form>
							</td>
							</tr>
						</table>
					
					  </td>
					   <?php endif; ?>
					   
					   <?php
					   $pic=DB::table('laporan_pekerjaan')->where('id','=',$pkn->id_laporan_pekerjaan)->get()->first();
					   ?>
					   <?php if(Auth::user()->hak_akses != "admin" and $pic->pic == Auth::user()->id): ?>
					  <td>
						<table>
							<tr>
							<td style="border:0px;">
							<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('edit<?php echo e($no); ?>').submit()"><i class="material-icons">create</i></a> 
							<form id="edit<?php echo e($no); ?>" style="display:none; float:left; margin-right:5px;" action="<?php echo url('/edit_dokumen_pekerjaan'); ?>" method="post">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
								<input type="hidden" name="id" value="<?php echo e($pkn->id); ?>">
								<button type="submit" class="btn btn-primary">Edit</button></a>
							</form>
							</td>
				
							<td style="border:0px;">
							<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('hapus<?php echo e($no); ?>').submit()"><i class="material-icons">delete</i></a>
							<form style="display:none;" id="hapus<?php echo e($no); ?>" method="post" action="<?php echo url('/hapus_dokumen_pekerjaan'); ?>">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id" value="<?php echo e($pkn->id); ?>">
								<input type="hidden" name="nama" value="<?php echo e($pkn->nama); ?>">
								<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($id_laporan_pekerjaan); ?>">
								<input type="submit" class="btn btn-danger" value="Delete" />
							</form>
							</td>
							</tr>
						</table>
					
					  </td>
					   <?php endif; ?>
					   
                    </tr>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>