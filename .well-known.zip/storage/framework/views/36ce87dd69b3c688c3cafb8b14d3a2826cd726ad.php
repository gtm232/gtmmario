<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
				

                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Laporan Pekerjaan</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
			<?php if(!isset($hanya_saya)): ?>
            <form style="float:left; margin:5px;" action="<?php echo url('/hanya_saya'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<button type="submit" class="btn btn-primary">Pekerjaan Saya</button></a>
			</form>
			<?php else: ?>
				<a style="float:left; margin:5px;" href="<?php echo url('/pekerjaan'); ?>" class="waves-effect"><button class="btn btn-info">Semua Pekerjaan</button></a>
			<?php endif; ?>
			
			<?php if(Auth::user()->hak_akses == "admin"): ?>			
             <a style="float:left; margin:5px;" href="<?php echo e(route('pekerjaan.create')); ?>" ><button class="btn btn-info">Tambah</button></a>
					<br>
			<?php endif; ?>
          
			<br>
            <div class="card-body ">
              <div class="table-responsive">
			   <?php if(!isset($hanya_saya)): ?>
                   <select  class="form-control" name="tahun" style="width:110px; margin:0px 0px 10px 5px;" onchange="location = this.value;">
                      <option>Tahun</option>
					  <?php $tgl_aw=2018; $tgl_ak=date("Y"); 
                      for($i=$tgl_ak; $i>=$tgl_aw; $i--){
                      ?>
                      <option value="pekerjaan?thn=<?php echo e($i); ?>"><?php echo e($i); ?></option>
                      <?php } ?>
                      
                  </select>
				<?php else: ?>
					 <select  class="form-control" name="tahun" style="width:110px; margin:0px 0px 10px 5px;" onchange="location = this.value;">
                      <option>Tahun</option>
					  <?php $tgl_aw=2018; $tgl_ak=date("Y"); 
                      for($i=$tgl_ak; $i>=$tgl_aw; $i--){
                      ?>
                      <option value="hanya_saya?thn=<?php echo e($i); ?>"><?php echo e($i); ?></option>
                      <?php } ?>
                      
                  </select>
				<?php endif; ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Nama Pekerjaan</th>
                      <th>Tanggal Mulai</th>
					  <th>Tanggal Berakhir</th>
					  <th>PIC</th>
					  <th>Lokasi Arsip</th>
					  <th>Lokasi Pekerjaan</th>
					  <th>Area Operasi</th>
					  <th>Inisiator Kerja</th>
                      
                      <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>Opsi</th>
					  <?php endif; ?>
					  
                    </tr>
                  </thead>
                  
                  <tbody>
				 
				  <?php $no=1; 
				  if(isset($_GET["thn"])){
				  $pekerjaan=DB::table('laporan_pekerjaan')->whereYear('tanggal_mulai','=',$_GET["thn"])->get();
				  }else{
					$pekerjaan=DB::table('laporan_pekerjaan')->get();
				  }
				  ?>
				
				  <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				   <?php if(!isset($hanya_saya)): ?>
                    <tr>
					
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->nama_pekerjaan); ?></div></a> </td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->tanggal_mulai); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->tanggal_berakhir); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->pic); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->lokasi); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->lokasi_pekerjaan); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->area_operasi); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->inisiator_kerja); ?></div></a></td>
                      
					  <div style="display:none;">
						<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
						</form>
					  </div>
					  
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td>
					 
					<a  style="float:left; margin-right:5px;" href="<?php echo e(route('pekerjaan.edit',$pkn->id)); ?>"><button class="btn btn-primary">Edit</button></a>
					  
					<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/popaylist'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">POPAY</button></a>
					</form>
						
					<form style="float:left;" method="post" action="<?php echo e(route('pekerjaan.destroy',$pkn->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>

					  </td>
					  <?php endif; ?>
                    </tr>
					
					<?php else: ?>
						<?php if(Auth::user()->id == $pkn->pic): ?>
						<tr>
					
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->nama_pekerjaan); ?></div></a> </td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->tanggal_mulai); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->tanggal_berakhir); ?></div></a></td>
                      <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->pic); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->lokasi); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->lokasi_pekerjaan); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->area_operasi); ?></div></a></td>
					  <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($pkn->inisiator_kerja); ?></div></a></td>
                      
					  <div style="display:none;">
						<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/dokumen_pekerjaan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
						</form>
					  </div>
					  
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td>
					 
					<a  style="float:left; margin-right:5px;" href="<?php echo e(route('pekerjaan.edit',$pkn->id)); ?>"><button class="btn btn-primary">Edit</button></a>
					  
					<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/popaylist'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pkn->id); ?>">
						<button type="submit" class="btn btn-primary">POPAY</button></a>
					</form>
						
					<form style="float:left;" method="post" action="<?php echo e(route('pekerjaan.destroy',$pkn->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>

					  </td>
					  <?php endif; ?>
                    </tr>
					<?php endif; ?>
					<?php endif; ?>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>