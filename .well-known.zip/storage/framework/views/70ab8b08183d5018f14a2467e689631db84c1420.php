
<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Tambah Data</h2>
			<form id="tambah_dokumen_form" class="form-group" action="<?php echo url('/tambah_dokumen_bulanan_proses'); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				
				<div class="form-group">
					<label for="isi">Perihal</label>
					<input type="text" name="prihal" class="form-control" required="required">
					<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
					<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
					<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
					<input type="hidden" name="id_users" value="<?php echo e(Auth::user()->id); ?>">
				</div>
				
				<div class="form-group">
					<label for="exampleInputPassword1">File</label>
					<input type="file" class="form-control" name="file" onchange="validasiFile()" id="file" >
				</div>
				
				<div class="form-group" style="<?php if(Auth::user()->hak_akses != 'admin'){ echo 'display:none;'; }?>">
					<label class="col-sm-4 control-label">Tanggal</label>
					  <input style="background:#ffff;" type="text" class="form-control" id="tgl2" autocomplete="off" name="tanggal" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>
				</div>
				
				<div  class="form-group">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
	<!--<button id="button_save" onclick="simpan_dokumen_laporan_bulanan();" type="submit" class="btn btn-primary">Simpan</button></a>
	
	<form id="back_dbln" action="<?php echo url('/dokumen_bulanan'); ?>" method="post">
						<in                put type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
						<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
						<button style="display:none;" type="submit" class="btn btn-primary">save</button></a>
	</form> -->
	
<?php $__env->stopSection(); ?>

<script>


function validasiFile(){
    var inputFile = document.getElementById('file');
    var pathFile = inputFile.value;
    var ekstensiOk = /(\.pdf|\.PDF)$/i;
    if(!ekstensiOk.exec(pathFile)){
        alert('Silakan upload file yang memiliki ekstensi PDF');
        inputFile.value = '';
        return false;
    }else{
        //Pratinjau gambar
        
    }
}


</script>
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>