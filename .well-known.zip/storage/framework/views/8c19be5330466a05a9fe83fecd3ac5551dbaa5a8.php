

<table border="1" >
        <thead>
            <tr>
                <th bgcolor="yellow">Klausul</th>
                <th bgcolor="yellow">Temuan</th>
                <th bgcolor="yellow">Yes</th>
                <th bgcolor="yellow">No</th>
                <th bgcolor="yellow">Rekomendasi Perbaikan</th>
                <th bgcolor="yellow">Due Date</th>
                <th bgcolor="yellow">PIC</th>
                <th bgcolor="yellow">Status</th>
				<th bgcolor="yellow">Dokumentasi</th>
            </tr>
        </thead>
            <?php
				$detail_mea=DB::table("detail_mea")->where('id_mea',$_GET["id_mea"])->get();
			?>
			<?php $__currentLoopData = $detail_mea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_mea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td align="center" valign="top"><?php echo e($detail_mea->klausul); ?></td>
				<td align="center" valign="top"><?php echo e($detail_mea->temuan); ?></td>
				<td align="center" valign="top"><?php echo e($detail_mea->yes); ?></td>
				<td align="center" valign="top"><?php echo e($detail_mea->no); ?></td>
				<td align="center" valign="top"><?php echo e($detail_mea->rekomendasi_perbaikan); ?></td>
				<td align="center" valign="top" valign="top"><?php echo e(date('d-M-Y',strtotime($detail_mea->duedate))); ?></td>
				<td align="center" valign="top"><?php echo e($detail_mea->pic); ?></td>
				<td align="center" valign="top"><?php echo e($detail_mea->status); ?></td>
				<td height="40">
				<?php if($detail_mea->dokumentasi == null): ?>
				<img style="margin-left:10px;" width="40" height="40" src="<?php echo url('/');?>/mea/gambar/<?php echo e($detail_mea->dokumentasi); ?>">
				<?php endif; ?>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>