
<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Tambah Data</h2>
			<form class="form-group" action="<?php echo url('/tambah_jenis_laporan_proses'); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				
				<div class="form-group">
					<label for="isi">Jenis Laporan</label>
					<input type="text" name="jenis_laporan" class="form-control" required="required">
					<input type="hidden" name="id_laporan_bulanan" class="form-control" value="<?php echo e($id_laporan_bulanan); ?>">
					<input type="hidden" name="id_wilayah_operasi" class="form-control" value="<?php echo e($id_wilayah_operasi); ?>">
				</div>
				
				<div class="form-group">
					<label for="isi">Pelapor</label>
						<select name="pelapor" class="form-control" required="required">
							<option value="">--Pilih Pelapor--</option>
							<option value="0">Tidak Ada Pelapor</option>
							<?php
							$pelapor=DB::table('users')->get();
							?>
							<?php $__currentLoopData = $pelapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($pelapor->id); ?>"><?php echo e($pelapor->name); ?></option>
								
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
				</div>
				
				
				
				<div class="form-group">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>