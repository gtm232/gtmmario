<html>

	<head>
	<link rel="stylesheet" href="<?php echo URL::to('/'); ?>/catatan/jquery-ui.css">
	<link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="<?php echo URL::to('/'); ?>/aset/plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="<?php echo URL::to('/'); ?>/aset/plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="<?php echo URL::to('/'); ?>/aset/plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Morris Chart Css-->
    <link href="<?php echo URL::to('/'); ?>/aset/plugins/morrisjs/morris.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="<?php echo URL::to('/'); ?>/aset/css/style.css" rel="stylesheet">
	<link href="<?php echo URL::to('/'); ?>/aset/plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="<?php echo URL::to('/'); ?>/aset/css/themes/all-themes.css" rel="stylesheet" />
	<style>
		#holder{
		  margin: 0 auto;
		  background: #eee;
		  padding: 0px 0 0px 0;
		  max-width:100%;
		}
		.canvas-wrapper{
		}
		canvas{
		  margin: 0 auto;
		  margin-bottom:5px;
		  display: block;
		  height : 160%;
		  width: 100%;
		  
		}
	</style>
	
	</head>
	
	<body>
	<a href="javascript:" onclick="document.getElementById('backdbln').submit()">
	<i class="material-icons">reply</i>
	</a>
					 
			<div style="display:none;">
					<form id="backdbln" action="<?php echo url('/dokumen_bulanan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
						<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
					</form>
			</div>		
		<?php
			$folder=DB::table('laporan_bulanan')->where('id',$id_laporan_bulanan)->get()->first();
			$wilayah=DB::table('wilayah_operasi')->where('id',$id_wilayah_operasi)->get()->first();
			$jenis_laporan=DB::table('jenis_laporan')->where('id',$id_jenis_laporan)->get()->first();
			if($folder->bulan == 1){
				$nama_bulan="Januari";
			}else if($folder->bulan == 2){
				$nama_bulan="Februari";
			}else if($folder->bulan == 3){
				$nama_bulan="Maret";
			}else if($folder->bulan == 4){
				$nama_bulan="April";
			}else if($folder->bulan == 5){
				$nama_bulan="Mei";
			}else if($folder->bulan == 6){
				$nama_bulan="Juni";
			}else if($folder->bulan == 7){
				$nama_bulan="Juli";
			}else if($folder->bulan == 8){
				$nama_bulan="Agustus";
			}else if($folder->bulan == 9){
				$nama_bulan="September";
			}else if($folder->bulan == 10){
				$nama_bulan="Oktober";
			}else if($folder->bulan == 11){
				$nama_bulan="November";
			}else if($folder->bulan == 12){
				$nama_bulan="Desember";
			}
		?>
		<?php 
			$dokumen_laporan_bulanan=DB::table('dokumen_laporan_bulanan')->where('id','=',$id)->get()->first();
		?>
		<div id="loading" style="display:none; position: absolute; width: 100%;">
			<img style="display: block; margin-left: auto; margin-right: auto; width:40%;" src="<?php echo URL::to('/'); ?>/gambar/Loading_2.gif">
		</div>
		
		<div id="holder2" class="col-md-12 col-12 align-self-center">
			<h3 align="center" style="margin:20px 0px 20px 0px;" class="text-themecolor m-b-0 m-t-0"><?php echo e($dokumen_laporan_bulanan->prihal); ?></h3>              
		</div>
		
		<div style="width:100%;">
			<div style="margin: 0 auto;">			   
							<?php $dokumen_laporan_bulanan2=DB::table('dokumen_laporan_bulanan')->where([['id_laporan_bulanan',$id_laporan_bulanan],['jenis_laporan',$id_jenis_laporan],['wilayah_operasi',$id_wilayah_operasi],])->get(); ?>
							<div class="card-body ">
								<?php
								$dl=DB::table('notif_catatan_revisi')->where('id_dokumen_laporan',$dokumen_laporan_bulanan->id)->get()->first();
								$dl1=DB::table('notif_catatan_revisi')->where('id_dokumen_laporan',$dokumen_laporan_bulanan->id)->count();
								?>
								
								<table border="0" align="center" style="width:95%;">
									<tr>
									
										<td>
											<select style="" class="form-control" id="dokumen" onchange="dokumen(this.value)">
												<option value="0">-- Silahkan Pilih --</option>
												<?php $__currentLoopData = $dokumen_laporan_bulanan2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dlb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($dlb->id); ?>"><?php echo e($dlb->prihal); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											
											<div style="display:none;">
											<form id="bln" action="<?php echo url('/lihat_dokumen_bulanan'); ?>" method="post">
													<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
													<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
													<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
													<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
													<input type="hidden" name="id" id="text" value="<?php echo e($id); ?>">
													<button type="submit" class="btn btn-primary">save</button></a>
											</form>
											</div>
										</td>
								<?php		
								if($dl1 != 0){
								$udl=DB::table('user_review_catatan_revisisi')->where([['user_review',Auth::user()->id],['id_notif_catatan_review',$dl->id],])->count();
								
								?>
								<?php if(($dl->status == "Melaporkan" and $udl > 0 ) or (Auth::user()->hak_akses == "admin")): ?>
										
										<td width="10">
								
											<a style="" href="javascript:" class="waves-effect" data-toggle="modal" data-target="#exampleModalLong"> <i class="material-icons">attach_file</i></a>
													
											<!-- Modal -->
											<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
												<div class="modal-dialog" role="document">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title" id="exampleModalLongTitle">Attach</h5>
															<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																<span aria-hidden="true">&times;</span>
															</button>
														</div>
														
														<div class="modal-body">
															<div class="table-responsive">
																							
																	<?php if(Auth::user()->hak_akses == "admin"): ?>
																		<form style=" margin-right:0px 5px 10px;" action="<?php echo url('/attach'); ?>" method="post">
																			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
																			<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
																			<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
																			<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
																			<input type="hidden" name="id" value="<?php echo e($id); ?>">
																			<button type="submit" class="btn btn-info">Tambah</button></a>
																		</form>
																	<?php endif; ?>		
																
																<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
																	<thead>
																		<tr>
																			<th>Dokumen</th>
																			<?php if(Auth::user()->hak_akses == "admin"): ?>
																			<th>Opsi</th>
																			<?php endif; ?>	
																		</tr>
																	</thead>
																	<?php $lampiran=DB::table('attach')->where([['id_laporan_bulanan',$id_laporan_bulanan],['id_jenis_laporan',$id_jenis_laporan],['id_wilayah_operasi',$id_wilayah_operasi],])->get(); ?>
																	<tbody>
																	<?php $__currentLoopData = $lampiran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<tr>
																		<td><?php echo e($lam->nama_dokumen); ?></td>
																		<td>
																			<?php if(Auth::user()->hak_akses == "admin"): ?>
																			<form style="float:left; margin-right:5px;" method="post" action="<?php echo url('/hapus_attach'); ?>">
																			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
																			<input type="hidden" name="id_attach" value="<?php echo e($lam->id); ?>">
																			<input type="hidden" name="id" value="<?php echo e($id); ?>">
																			<input type="hidden" name="nama_dokumen" value="<?php echo e($lam->nama_dokumen); ?>">
																			<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
																			<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
																			<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
																			<input type="submit" class="btn btn-danger" value="Delete" />
																			</form>
																			<?php endif; ?>
																			<a style="float:left;" href="<?php echo URL::to('/'); ?>/laporan_bulanan/<?php echo e($folder->tahun); ?>/<?php echo e($nama_bulan); ?>/<?php echo e($wilayah->wilayah_operasi); ?>/<?php echo e($jenis_laporan->jenis); ?>/editable/<?php echo e($lam->nama_dokumen); ?>" download><button class="btn btn-info">Download</button></a>
																		</td>
																	</tr>
																	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																	</tbody>
																</table>
															</div>
														</div>
														
														<div class="modal-footer">
															<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
														</div>
													</div>
												</div>
											</div>
										</td>
										
										<td width="10">
											<form method="post" name="frm_ajax" style="">
												<input id="no_garis" type="hidden" value="1" class="form-control">
												<input type="hidden" name="_token" id="token_garis" value="<?php echo e(csrf_token()); ?>">
											</form>
											<a style="" href="javascript:" onclick="kirim_garis();"> <i class="material-icons">remove</i></a>
											
										</td>
										
										<td width="10">
											<a href="javascript:" type="button" data-toggle="modal" data-target="#review">
												<i class="material-icons">format_shapes</i>
											</a>
										
											<div class="modal fade" id="review" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
											  <div class="modal-dialog" role="document">
												<div class="modal-content">
												  <div class="modal-header">
													<h5 class="modal-title" id="exampleModalLabel">Silahkan isi Form</h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													  <span aria-hidden="true">&times;</span>
													</button>
												  </div>
												  <div class="modal-body">
													<form method="post" name="frm_ajax" style="">
														<input id="no_catatan" type="hidden" value="1" class="form-control">
														<input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
														<textarea style="width:100%; height:100px;" name="isi" id="isi"></textarea>
														<input style="margin-top:10px; width:50px; background:blue; color:white;" class="form-control" type="button" onclick="kirim_form();" value="OK"/>
													</form>
												  </div>
												 
												</div>
											  </div>
											</div>
											
										</td>
										
										<td width="10">
											<form style="display:none;" id="form_simpan_gambar" target="_blank" action="<?php echo url('/save_revisi'); ?>" method="post">
													<input type="hidden" id="token_revisi" name="_token" value="<?php echo e(csrf_token()); ?>">
													<textarea name="file" id="simpan_gambar"></textarea>
													<textarea name="nama_gambar" id="nama_gambar"></textarea>
													<input type="text" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
													<input type="text" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
													<input type="text" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
													<input type="text" name="id" value="<?php echo e($id); ?>">
													<input type="text" name="id_user" value="<?php echo e(Auth::user()->id); ?>">
													<input type="text" id="param" name="param" value="">
													<button type="submit" style="" class="btn btn-primary">save</button></a>
											</form>
											<a style="" id="save_revisi" href="javascript:" onclick="save_revisi();"> <i class="material-icons">save</i></a>
											
										</td>
										
										<td width="10">
										
											<a style="" id="selesai_review" href="javascript:" onclick="selesai_review();"> <i class="material-icons">done</i></a>
											
										</td>
										<?php endif; ?>
										<?php } ?>
										
										<td width="10">
											<form style="display:none;" id="form_selesai_review" target="_blank" action="<?php echo url('/selesai_review'); ?>" method="post">
													<input type="hidden" id="token_revisi" name="_token" value="<?php echo e(csrf_token()); ?>">
													<textarea name="file" id="simpan_gambar"></textarea>
													<textarea name="nama_gambar" id="nama_gambar"></textarea>
													<input type="text" name="id_notif_catatan_review" value="<?php echo e($dl->id); ?>">
													<input type="text" name="user_review" value="<?php echo e(Auth::user()->id); ?>">
													<input type="text" name="id_dokumen_laporan_bulanan" value="<?php echo e($id); ?>">
													
													<button type="submit" style="" class="btn btn-primary">save</button></a>
										</form>
										
											<a href="javascript:" data-toggle="modal" data-target="#largeModal"><i class="material-icons">error</i></a>
											<div class="modal fade" id="largeModal" tabindex="-1" role="dialog">
												<div class="modal-dialog modal-lg" role="document">
													<div class="modal-content">
														<div class="modal-header">
															<h4 class="modal-title" id="largeModalLabel">Daftar Revisi</h4>
														</div>
														<div class="modal-body">
															
															<div class="card-body ">
															
															  <div class="table-responsive" style="margin:10px;">
																
																
																<button type="submit" class="btn btn-info" data-toggle="modal" data-target="#smallModal">Tambah</button></a>
											
																
																<br>
																
																<table class="table table-bordered table-striped table-hover js-basic-example dataTable" width="100%" cellspacing="0">
																  <thead>
																	<tr>
																	<th>Pe-Review</th>
																	<th>Hasil Review</th>
																	<th>Option</th>
																	  
																	</tr>
																  </thead>
																  
																  <tbody id="tampil_revisi_tabel">
																  
																  </tbody>
																  
																	<script>
																		function newtab(revisi_id, revisi_user){
																		var x = window.open('<?php echo e(url('/lihat_revisi')); ?>?id_laporan_bulanan=<?php echo e($id_laporan_bulanan); ?>&id_jenis_laporan=<?php echo e($id_jenis_laporan); ?>&id_wilayah_operasi=<?php echo e($id_wilayah_operasi); ?>&id_revisi=' + revisi_id + '&id_dokumen_laporan_bulanan=<?php echo e($id); ?>&user=' + revisi_user,'_blank');
																			x.focus();
																		}
																	</script>
																</table>
															  </div>
															  
															  
															</div>
															
														</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-link waves-effect">SAVE CHANGES</button>
															<button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
														</div>
													</div>
												</div>
											</div>
											
										</td>
										
										
									</tr>
								</table>
								
							</div>	
				
			</div>
		</div>
		
		<div class="modal fade" id="smallModal" tabindex="-1" role="dialog">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="smallModalLabel">Modal title</h4>
					</div>
					<div class="modal-body">
						<form style="" id="tambah_revisi_hard" target="_blank" action="<?php echo url('/tambah_revisi_hard'); ?>" method="post" enctype="multipart/form-data">
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
							<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
							<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
							<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
							<input type="hidden" name="id" value="<?php echo e($id); ?>">
							<input type="hidden" name="input" value="2">
							<input type="hidden" name="id_user" value="<?php echo e(Auth::user()->id); ?>">
							<div class="form-group">
								<label for="exampleInputPassword1">File</label>
								<input type="file" class="form-control" name="file" onchange="validasiFile()" id="file" >
							</div>
							<button style="display:none;" type="submit"  class="btn btn-info">Save</button>
							
						</form>
						<a href="javascript:" onclick="revisi_hard();" class="waves-effect">
								<button class="btn btn-info">Save</button>
						</a>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
					</div>
				</div>
			</div>
		</div>
		
		<?php
		$t=URL::to('/')."/laporan_bulanan/".$folder->tahun."/".$nama_bulan."/".$wilayah->wilayah_operasi."/".$jenis_laporan->jenis."/". addslashes($dokumen_laporan_bulanan->nama_dokumen_laporan);
		
		?>
		<br>			
		
		<div style="width:100%;">
			<div class="body" style="text-align:center;">
				<nav>
					<ul class="pagination">
						<li>
							<a href="javascript:" onclick="prev();">
								<i class="material-icons">chevron_left</i>
							</a>
						</li>
						<input type="hidden" id="nilai_max" value="">
						<li><a>
						<input type="text" id="halaman" value="1" style="text-align:center; width:50px; height:20px; border:0;">
						</a></li>
						<li>
							<a href="javascript:" onclick="next();" class="waves-effect">
								<i class="material-icons" >chevron_right</i>
							</a>
							
							<!--
							<a href="javascript:" onclick="zoombesar(1)" class="waves-effect">
								<i class="material-icons" >add</i>
							</a>
							
							<a href="javascript:" onclick="zoomkecil(1)" class="waves-effect">
								<i class="material-icons" >remove</i>
							</a>
							-->
							
							<a href="javascript:" class="waves-effect" onclick="perbesar_gambar();">
								<i class="material-icons" >wb_iridescent</i>
							</a>
							
							<div class="modal fade" id="besarkan_gambar" tabindex="-1" role="dialog">
								<div style="display: block; margin-left: auto; margin-right: auto; width:90%;" role="document">
									<div class="modal-content">
										<div class="modal-header">
											<h4 class="modal-title" id="largeModalLabel">Modal title</h4>
										</div>
										<div class="modal-body">
										
											<div style="width:100%; overflow: scroll;">
												<div id="holder_2" style="width:1500px; height:2528px;  "></div>
											</div>
											
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
										</div>
									</div>
								</div>
							</div>
						</li>
						
					</ul>
				</nav>
				
			</div>					
       </div>
	   
	   
		
		<form id="lb" style="display:none;" action="<?php echo url('/lihat_dokumen_bulanan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<input type="hidden" name="id_jenis_laporan" value="<?php echo e($id_jenis_laporan); ?>">
						<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($id_wilayah_operasi); ?>">
						<input type="hidden" name="id" value="<?php echo e($id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
		</form>
		
		
		<div id="holder">
				<div id="pesan_kirim" style="max-height:0px; width:100%;"></div>
		</div>
		
		<input type="hidden" id="scale" value="1">
	</body>
<script src="<?php echo URL::to('/'); ?>/aset/plugins/jquery/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/pdfjs-dist@2.0.385/build/pdf.min.js"></script>
<script src="<?php echo URL::to('/'); ?>/catatan/html2canvas.js"></script>
<script src="<?php echo URL::to('/'); ?>/catatan/canvas2image.js"></script>
<script src="<?php echo URL::to('/'); ?>/catatan/jquery-ui.js"></script>
<script src="<?php echo URL::to('/'); ?>/catatan/jquery-touch.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Base64/0.3.0/base64.min.js"></script>
<script src="<?php echo URL::to('/'); ?>/aset/plugins/jquery-datatable/jquery.dataTables.js"></script>
<script src="<?php echo URL::to('/'); ?>/aset/plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
<script src="<?php echo URL::to('/'); ?>/aset/plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
<script src="<?php echo URL::to('/'); ?>/aset/plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
<script src="<?php echo URL::to('/'); ?>/aset/plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
<script src="<?php echo URL::to('/'); ?>/aset/plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
<script src="<?php echo URL::to('/'); ?>/aset/plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
<script src="<?php echo URL::to('/'); ?>/aset/plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
<script src="<?php echo URL::to('/'); ?>/aset/plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>
<script src="<?php echo URL::to('/'); ?>/aset/js/pages/tables/jquery-datatable.js"></script>
<!-- Bootstrap Core Js -->
<script src="<?php echo URL::to('/'); ?>/aset/plugins/bootstrap/js/bootstrap.js"></script>
<script>
function selesai_review(){
	document.getElementById('form_selesai_review').submit();
	window.setTimeout(refresh_selesai_review, 1000);
}

function refresh_selesai_review(){
	document.getElementById('backdbln').submit();
}

function perbesar_gambar(){
renderPDF('<?php echo e($t); ?>', document.getElementById('holder_2'), 3, 5);
renderPDF('<?php echo e($t); ?>', document.getElementById('holder'), 3, 5);
$("#besarkan_gambar").modal("show");
}

function prev(){
	document.getElementById('scale').value = parseInt(1);
	renderPDF('<?php echo e($t); ?>', document.getElementById('holder'), 1, 5);
}

function next(){
	document.getElementById('scale').value = parseInt(1);
	renderPDF('<?php echo e($t); ?>', document.getElementById('holder'), 2, 5);
}

$(document).on("keypress", "#halaman", function(e){
        if(e.which == 13){
			document.getElementById('scale').value = parseInt(1);
            var inputVal = $(this).val();
            //alert("You've entered: " + inputVal);
			renderPDF('<?php echo e($t); ?>', document.getElementById('holder'), 3, 5);
        }
		
    });

function dokumen(value) {
	$('#text').val(value);
	document.getElementById('bln').submit();
}

function revisi_hard() {
	document.getElementById('tambah_revisi_hard').submit();
	document.getElementById('lb').submit();
}

function hapus_revisi_pdf() {
	
	var token   = $('#token').val();
	var id_jenis_laporan   = <?php echo e($id_jenis_laporan); ?>;
	var id_wilayah_operasi   = <?php echo e($id_wilayah_operasi); ?>;
	var id_dokumen_laporan_bulanan   = <?php echo e($id); ?>;
	var id_laporan_bulanan   = <?php echo e($id_laporan_bulanan); ?>;
	var user   = <?php echo e(Auth::user()->id); ?>;
	
	 
	$.ajax({
		//Alamat url harap disesuaikan dengan lokasi script pada komputer anda
		url	     : '<?php echo url("/hapus_revisi"); ?>',
		type     : 'POST',
		dataType : 'html',
		data     : "_token=" + token + "&id_jenis_laporan=" + id_jenis_laporan + "&id_wilayah_operasi=" + id_wilayah_operasi + "&id_laporan_bulanan=" + id_laporan_bulanan + "&id=" + id_dokumen_laporan_bulanan + "&user=" + user,
		success  : function(respons){
			document.getElementById('lb').submit();
			
		},
	});
	
}

function kirim_form(){
	var no   = $('#no_catatan').val();
	var isi   = $('#isi').val();
	var token   = $('#token').val();
	
	 
	$.ajax({
		//Alamat url harap disesuaikan dengan lokasi script pada komputer anda
		url	     : '<?php echo url("/catatan"); ?>',
		type     : 'POST',
		dataType : 'html',
		data     : 'no='+no+ "&_token=" + token+ "&isi=" + isi,
		success  : function(respons){
			$('#pesan_kirim').append(respons);
			$('#pesan_kirim').slideDown('fast');
			document.getElementById('no_catatan').value = parseInt(no)+1;
			
			
		},
	});
};



function save_revisi(){
	$("#loading").show();
	html2canvas($("#holder"), {
            onrendered: function(canvas) {
				
                theCanvas = canvas;
                //document.body.appendChild(canvas);
			
                // Convert and download as image 
                //Canvas2Image.saveAsPNG(canvas); 
                var image = Canvas2Image.convertToPNG(canvas);
               var image_data = $(image).attr('src');
               //$('#img').append(image_data);
			   //document.getElementById('gambar_c').value =image_data;
			   //document.getElementById('revisi').submit();
              //make an ajax call here sending image_data to the server
              /*
              $.ajax({
              url: 'localhost:3000/save_image',
              data:{ image: image_data},
              success: function(){
              
              }
              });
              */
                //$("#img-out").append(canvas);
                // Clean up 
                //document.body.removeChild(canvas);
				
				var token_revisi   = $('#token_revisi').val();
				var halaman   = $('#halaman').val();
				var id_laporan_bulanan   = <?php echo e($id_laporan_bulanan); ?>;
				var id_jenis_laporan   = <?php echo e($id_jenis_laporan); ?>;
				var id_wilayah_operasi   = <?php echo e($id_wilayah_operasi); ?>;
				var id_dokumen_laporan_bulanan   = <?php echo e($id); ?>;
				var user  = <?php echo e(Auth::user()->id); ?>;
				var gambar  = image_data;
				var d = new Date();
				var n = d.getTime();
				var nama_gambar  = n +".png";
				var input = 1;
				
				$.ajax({
					//Alamat url harap disesuaikan dengan lokasi script pada komputer anda
					url	     : '<?php echo url("/save_revisi_data"); ?>',
					type     : 'POST',
					data     : "_token=" + token_revisi + "&id_laporan_bulanan=" + id_laporan_bulanan + "&id_jenis_laporan=" + id_jenis_laporan + "&id_wilayah_operasi=" + id_wilayah_operasi + "&id_dokumen_laporan_bulanan=" + id_dokumen_laporan_bulanan + "&user=" + user + "&nama_gambar=" + nama_gambar + "&halaman=" + halaman + "&input=" + input,
					success  : function(respons){
						document.getElementById('simpan_gambar').value =gambar;
						document.getElementById('nama_gambar').value =nama_gambar;
						document.getElementById('param').value =respons;
						document.getElementById("form_simpan_gambar").submit();
						$("#loading").hide();
						var div = document.getElementById('pesan_kirim');
						while(div.firstChild){
							div.removeChild(div.firstChild);
						}
						alert(respons);
						ambil_data_revisi();
					},
				});
				
				
				
				
            }
        });
		
	
};

function ambil_data_revisi(){
	var token_tabel_revisi   = $('#token_revisi').val();
				var id_laporan_bulanan   = <?php echo e($id_laporan_bulanan); ?>;
				var id_jenis_laporan   = <?php echo e($id_jenis_laporan); ?>;
				var id_wilayah_operasi   = <?php echo e($id_wilayah_operasi); ?>;
				var id_dokumen_laporan_bulanan   = <?php echo e($id); ?>;
				var user = <?php echo e(Auth::user()->id); ?>;
				$.ajax({
					//Alamat url harap disesuaikan dengan lokasi script pada komputer anda
					url	     : '<?php echo url("/tampil_revisi_tabel"); ?>',
					type     : 'POST',
					data     : "_token=" + token_tabel_revisi + "&id_laporan_bulanan=" + id_laporan_bulanan + "&id_jenis_laporan=" + id_jenis_laporan + "&id_wilayah_operasi=" + id_wilayah_operasi + "&id=" + id_dokumen_laporan_bulanan + "&user=" + user,
					success  : function(respons2){
						document.getElementById("tampil_revisi_tabel").innerHTML = respons2;
						}
						
				});
}

function kirim_garis(){
	
	var no_garis  = $('#no_garis').val();
	var token_garis   = $('#token_garis').val();
	
	
	$.ajax({
		//Alamat url harap disesuaikan dengan lokasi script pada komputer anda
		url	     : '<?php echo url("/garis"); ?>',
		type     : 'POST',
		dataType : 'html',
		data     : 'no_garis='+no_garis+ "&_token=" + token_garis,
		success  : function(respons){
			$('#pesan_kirim').append(respons);
			$('#pesan_kirim').slideDown('fast');
			document.getElementById('no_garis').value = parseInt(no_garis)+1;
			
			
		},
	});
};


function renderPDF(url, canvasContainer, param, scale, options) {
$(".canvas-wrapper").hide();
var bc=parseInt($('#halaman').val());
var nm=parseInt($('#nilai_max').val());
var scale=scale;

if(param == 1){
	var bc = bc - 1;
	if(bc < 1){
		var bc=1;
	}
	document.getElementById('halaman').value = parseInt(bc);
}else if(param == 2){
	var bc = bc + 1;
	if(bc > nm){
		var bc=nm;
	}
	document.getElementById('halaman').value = parseInt(bc);
}else if(param == 3){
	
	var bc = parseInt($('#halaman').val());
}

    options = options || { scale: scale };
        
    function renderPage(page) {
        var viewport = page.getViewport(options.scale);
        var wrapper = document.createElement("div");
        wrapper.className = "canvas-wrapper";
        var canvas = document.createElement('canvas');
        var ctx = canvas.getContext('2d');
        var renderContext = {
          canvasContext: ctx,
          viewport: viewport
        };
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        wrapper.appendChild(canvas);
        canvasContainer.appendChild(wrapper);
        
        page.render(renderContext);
    }
    
    function renderPages(pdfDoc) {
        for(var num = 1; num <= pdfDoc.numPages; num++){
			
		}
        pdfDoc.getPage(bc).then(renderPage);
		document.getElementById('nilai_max').value = parseInt(num)-1;
		//alert(num);
    }
	
	
	
    PDFJS.disableWorker = true;
    PDFJS.getDocument(url).then(renderPages);
	

};

function zoombesar(besar){
	var zoomawal=$('#scale').val();;
	var zomsekarang= parseInt(zoomawal)+parseInt(besar);
	document.getElementById('scale').value = parseInt(zomsekarang);
	renderPDF('<?php echo e($t); ?>', document.getElementById('holder'), 0, zomsekarang);
}

function zoomkecil(kecil){
	
	var zoomawal=$('#scale').val();
	
	if(zoomawal == 1){
		var zoomawal=2;
	}
	var zomsekarang= parseInt(zoomawal)-parseInt(kecil);
	document.getElementById('scale').value = parseInt(zomsekarang);
	renderPDF('<?php echo e($t); ?>', document.getElementById('holder'), 0, zomsekarang);
}

renderPDF('<?php echo e($t); ?>', document.getElementById('holder'), 0, 5);
ambil_data_revisi();

</script>