<?php $__env->startSection('content'); ?>
<script>
  tinymce.init({
  selector: 'textarea',
  height: 500,
  plugins: [
        "advlist autolink lists link image charmap print preview anchor",
        "searchreplace visualblocks code fullscreen",
        "insertdatetime media table contextmenu paste imagetools wordcount"
    ],
    toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
  // imagetools_cors_hosts: ['www.tinymce.com', 'codepen.io'],
  content_css: [
    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
    '//www.tinymce.com/css/codepen.min.css',
	
  ],
   file_browser_callback: function(field, url, type, win) {
        tinyMCE.activeEditor.windowManager.open({
            file: 'kcfinder/browse.php?opener=tinymce4&field=' + field + '&type=' + type,
            title: 'KCFinder',
            width: 700,
            height: 500,
            inline: true,
            close_previous: false
        }, {
            window: win,
            input: field
        });
        return false;
    }
//  ...
});
  </script>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->

				<!-- Modal -->
				
				
				
				<div class="modal fade" id="bast" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
						<form id="jd" action="<?php echo url('/tambah_dokumen'); ?>" method="post"> 
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
							<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo $id_laporan_pekerjaan; ?>">
							<input type="hidden" name="jenis_dokumen" id="text" value="BAST">
							
								<div class="form-group">					
									<label for="judul">PGN</label>					
									<select style="margin: 5px;" name="pic1" class="form-control" required="required">
										<option>--Pilih--</option>
										<?php
										$picpgn=DB::table('pic_area')->where('perusahaan','PT Perusahaan Gas Negara Tbk')->get();
										?>
										<?php $__currentLoopData = $picpgn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picpgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($picpgn->id); ?>"><?php echo e($picpgn->nama); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
									
								</div>		

								<div class="form-group">					
									<label for="judul">Pihak Ke 2</label>					
									<select style="margin: 5px;" name="pic2" class="form-control" required="required">
										<option>--Pilih--</option>
										<?php
										$picpgn=DB::table('pic_area')->where('perusahaan','!=','PT Perusahaan Gas Negara Tbk')->get();
										?>
										<?php $__currentLoopData = $picpgn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picpgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($picpgn->id); ?>"><?php echo e($picpgn->nama); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
									
								</div>
								
								<div class="form-group">					
									<label >Tanggal Surat</label>					  
									<input style="background:#ffff;" type="text" class="form-control" id="tgl" autocomplete="off" name="tanggal_surat" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>									
								</div>
								
								<div class="form-group">
									<label for="judul">Harga yang dibayarkan</label>
									<input type="text" id="harga_db" name="harga_yangdibayarkan" class="form-control" >
								</div>
						
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save changes</button>
					  </div>
					  </form>
					</div>
				  </div>
				</div>
				
				<div class="modal fade" id="bap" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
						<form id="jd" action="<?php echo url('/tambah_dokumen'); ?>" method="post"> 
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
							<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo $id_laporan_pekerjaan; ?>">
							<input type="hidden" name="jenis_dokumen" id="text" value="BAP">
							
								<div class="form-group">					
									<label for="judul">PGN</label>					
									<select style="margin: 5px;" name="pic1" class="form-control" required="required">
										<option>--Pilih--</option>
										<?php
										$picpgn=DB::table('pic_area')->where('perusahaan','PT Perusahaan Gas Negara Tbk')->get();
										?>
										<?php $__currentLoopData = $picpgn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picpgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($picpgn->id); ?>"><?php echo e($picpgn->nama); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
									
								</div>		

								<div class="form-group">					
									<label for="judul">Pihak Ke 2</label>					
									<select style="margin: 5px;" name="pic2" class="form-control" required="required">
										<option>--Pilih--</option>
										<?php
										$picpgn=DB::table('pic_area')->where('perusahaan','!=','PT Perusahaan Gas Negara Tbk')->get();
										?>
										<?php $__currentLoopData = $picpgn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picpgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($picpgn->id); ?>"><?php echo e($picpgn->nama); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
									
								</div>
								
								<div class="form-group">					
									<label >Tanggal Surat</label>					  
									<input style="background:#ffff;" type="text" class="form-control" id="tgl11" autocomplete="off" name="tanggal_surat" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>									
								</div>
						
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save changes</button>
					  </div>
					  </form>
					</div>
				  </div>
				</div>
				
				<div class="modal fade" id="ba_nego" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
						<form id="jd" action="<?php echo url('/tambah_dokumen'); ?>" method="post"> 
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
							<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo $id_laporan_pekerjaan; ?>">
							<input type="hidden" name="jenis_dokumen" id="text" value="BA Nego">
							
								<div class="form-group">					
									<label for="judul">PGN</label>					
									<select style="margin: 5px;" name="pic1" class="form-control" required="required">
										<option>--Pilih--</option>
										<?php
										$picpgn=DB::table('pic_area')->where('perusahaan','PT Perusahaan Gas Negara Tbk')->get();
										?>
										<?php $__currentLoopData = $picpgn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picpgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($picpgn->id); ?>"><?php echo e($picpgn->nama); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
									
									<select style="margin: 5px;" name="pic2" class="form-control" required="required">
										<option>--Pilih--</option>
										<?php
										$picpgn=DB::table('pic_area')->where('perusahaan','PT Perusahaan Gas Negara Tbk')->get();
										?>
										<?php $__currentLoopData = $picpgn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picpgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($picpgn->id); ?>"><?php echo e($picpgn->nama); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
									
									<select style="margin: 5px;" name="pic3" class="form-control" required="required">
										<option>--Pilih--</option>
										<?php
										$picpgn=DB::table('pic_area')->where('perusahaan','PT Perusahaan Gas Negara Tbk')->get();
										?>
										<?php $__currentLoopData = $picpgn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picpgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($picpgn->id); ?>"><?php echo e($picpgn->nama); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
								</div>		

								<div class="form-group">					
									<label for="judul">Pihak Ke 2</label>					
									<select style="margin: 5px;" name="pic4" class="form-control" required="required">
										<option>--Pilih--</option>
										<?php
										$picpgn=DB::table('pic_area')->where('perusahaan','!=','PT Perusahaan Gas Negara Tbk')->get();
										?>
										<?php $__currentLoopData = $picpgn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picpgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($picpgn->id); ?>"><?php echo e($picpgn->nama); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
									
									<select style="margin: 5px;" name="pic5" class="form-control" required="required">
										<option>--Pilih--</option>
										<?php
										$picpgn=DB::table('pic_area')->where('perusahaan','!=','PT Perusahaan Gas Negara Tbk')->get();
										?>
										<?php $__currentLoopData = $picpgn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picpgn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($picpgn->id); ?>"><?php echo e($picpgn->nama); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</select>
									
								</div>	
								
								<div class="form-group">					
									<label for="judul">Masa Pekerjaan (Hari)</label>					
									<input type="number" id="masa_pekerjaan" name="masa_pekerjaan" class="form-control" required="required">				
								</div>	

								<div class="form-group">
									<label for="judul">Harga Penawaran</label>
									<input type="text" id="harga_penawaran" name="harga_penawaran" class="form-control" >
								</div>
								
								<div class="form-group">
									<label for="judul">Harga Kesepakatan</label>
									<input type="text" id="harga_kesepakatan" name="harga_kesepakatan" class="form-control" >
								</div>
						
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save changes</button>
					  </div>
					  </form>
					</div>
				  </div>
				</div>
				
				<div class="modal fade" id="spk" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
						<form id="jd" action="<?php echo url('/tambah_dokumen'); ?>" method="post"> 
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
							<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo $id_laporan_pekerjaan; ?>">
							<input type="hidden" name="jenis_dokumen" id="text" value="SPK">
							
								<div class="form-group">					
									<label >Tanggal Surat</label>					  
									<input style="background:#ffff;" type="text" class="form-control" id="tgl10" autocomplete="off" name="tanggal_surat" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>									
								</div>
							
								<div class="form-group">					
									<label for="judul">Lokasi Pekerjaan</label>					
									<input type="text" id="lokasi_pekerjaan" name="lokasi_pekerjaan" class="form-control" required="required">				
								</div>
								
								<div class="form-group">					
									<label for="judul">Masa Pekerjaan (Hari)</label>					
									<input type="number" id="masa_pekerjaan" name="masa_pekerjaan" class="form-control" required="required">				
								</div>	

								<div class="form-group">
									<label for="judul">Harga Pekerjaan</label>
									<input type="text" id="harga_pekerjaan" name="harga_pekerjaan" class="form-control" >
								</div>
								
						
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save changes</button>
					  </div>
					  </form>
					</div>
				  </div>
				</div>
				<!-- Akhir Modal -->
				
				<div class="row page-titles" style="margin-bottom:20px; text-align:center;">
                    <div class="col-md-12 col-12 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Pembuatan Surat</h3>
                        
                    </div>
                   
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block" >
            
            <div class="card-body ">
			<br>
              <div class="table-responsive" style="margin:15px;">
			  	
            <select class="form-line" id="dokumen" onchange="dokumen(this.value)">
					<option>Pilih</option>
					<option value="Undangan">Undangan</option>
					<option value="BA Nego">BA Nego</option>
					<option value="SPK">SPK</option>
					<option value="BAP">BAP</option>
					<option value="BAST">BAST</option>
					
			</select>
				
				<div style="display:none;">
				<form id="jd" action="<?php echo url('/tambah_dokumen'); ?>" method="post"> 
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo $id_laporan_pekerjaan; ?>">
						<input type="hidden" name="jenis_dokumen" id="text" value="">
						<button type="submit" class="btn btn-primary">save</button></a>
				</form>
				</div> 
					<br>
					<br>
			

                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Perihal</th>
                      <th>Jenis Surat</th>
					  <th>Status</th>
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>Catatan</th>
                      <?php endif; ?> 
					  <th>Opsi</th>
					
					  
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php $no=1; ?>
				  <?php $__currentLoopData = $pembuatan_surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pbs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
				  <?php $catatan=$pbs->catatan;?>
                    <tr>
					
					  <td><?php echo e($pbs->perihal); ?></td>
                      <td><?php echo e($pbs->jenis_dokumen); ?></td>
					  <td><?php echo e($pbs->status); ?></td>
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td><?php echo $pbs->catatan; ?></td>
					  <?php endif; ?>
					 
					<td>
					 
					
					<?php if(Auth::user()->hak_akses == "user" and $pbs->status == "Belum Konfirmasi"): ?> 
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('hapus<?php echo e($no); ?>').submit()"><i class="material-icons">delete</i></a>
					<form id="hapus<?php echo e($no); ?>" method="post" style="display:none; margin-right:5px; float:left" action="<?php echo e(route('pembuatan_surat.destroy',$pbs->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					<?php endif; ?>
					
					<?php if(Auth::user()->hak_akses == "admin"): ?> 
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('hapus<?php echo e($no); ?>').submit()"><i class="material-icons">delete</i></a>
					<form id="hapus<?php echo e($no); ?>" method="post" style="display:none; margin-right:5px; float:left" action="<?php echo e(route('pembuatan_surat.destroy',$pbs->id)); ?>">
						<input type="hidden" name="_method" value="DELETE">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="submit" class="btn btn-danger" value="Delete" />
					</form>
					<?php endif; ?>
					
					<?php if(Auth::user()->hak_akses == "admin" and $pbs->status != "Ok"): ?>
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('revisi<?php echo e($no); ?>').submit()"><i class="material-icons">colorize</i></a>
					<form id="revisi<?php echo e($no); ?>" class="form-group"  style="display:none; float:left; margin-right:5px;" action="<?php echo url('/selesai_revisi');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id_pembuatan_surat" value="<?php echo e($pbs->id); ?>">
					<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pbs->id_laporan_pekerjaan); ?>">
					<input type="submit" class="btn btn-success" value="Revisi" />
					</form>
					<?php endif; ?>
					
					<?php
					$pic3=DB::table('laporan_pekerjaan')->where('id',$pbs->id_laporan_pekerjaan)->get()->first();
					?>
					<?php if(Auth::user()->id == $pic3->pic and $pbs->status == "Open"): ?>
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('ok<?php echo e($no); ?>').submit()"><i class="material-icons">done</i></a>
					<form id="ok<?php echo e($no); ?>" class="form-group"  style="display:none; float:left; margin-right:5px;" action="<?php echo url('/ok');?>" method="post">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pbs->id_laporan_pekerjaan); ?>">
								<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
								<input type="submit" class="btn btn-success" value="Verifikasi" />
					</form>
					
				<div class="modal fade" id="catatan_revisi" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel" style="text-align:center;">Catatan Revisi</h5>
						
					  </div>
					  <div class="modal-body">
							<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/revisi');?>" method="post">
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
								<textarea name="catatan" id="catatan2">
								</textarea>
								<br>
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								<button type="submit" class="btn btn-primary">Revisi</button>
							</form>
					  <div class="modal-footer">
						
					  </div>
					</div>
				  </div>
				</div>
				</div>
					<a style="float:left; margin-right:5px;" href="javascript:" data-toggle="modal" data-target="#catatan_revisi"><i class="material-icons">clear</i></a>
					<?php endif; ?>
					
					<?php if(Auth::user()->hak_akses == "admin" and $pbs->status == "Ok"): ?>
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('arsipkan<?php echo e($no); ?>').submit()"><i class="material-icons">description</i></a>
					<form id="arsipkan<?php echo e($no); ?>" class="form-group"  style="display:none; float:left; margin-right:5px;" action="<?php echo url('/arsip');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
					<input type="hidden" name="ps" value="ps">
					<input type="hidden" name="id_laporan_pekerjaan" value="<?php echo e($pbs->id_laporan_pekerjaan); ?>">
					<input type="submit" class="btn btn-success" value="Arsipkan" />
					</form>
					<?php endif; ?>
					
						
					<!--<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/lihat_pembuatan_surat');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
					<input type="submit" class="btn btn-primary" value="Lihat <?php echo e($pbs->id); ?>" />
					</form>
					
					<form class="form-group"  style="float:left; margin-right:5px;" action="<?php echo url('/print_dokumen');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
					<input type="submit" class="btn btn-primary" value="PDF" />
					</form>-->
						
					<a style="float:left; margin-right:5px;" href="javascript:" onclick="document.getElementById('lihat<?php echo e($no); ?>').submit()"><i class="material-icons">remove_red_eye</i></a>
					<form id="lihat<?php echo e($no); ?>" class="form-group"  style="display:none; float:left; margin-right:5px;" action="<?php echo url('/print_doc');?>" method="post">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id" value="<?php echo e($pbs->id); ?>">
					<input type="submit" class="btn btn-primary" value="Lihat" />
					</form>
					</td>
				
					  
                    </tr>
					<?php $no++; $catatan=$pbs->catatan;?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
				
				<div>
				<?php //echo $catatan ?> 
				</div>
				
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<script type="text/javascript">


   function dokumen(value) {
	var dokumen = value;
	if(dokumen == "Undangan"){
		$('#text').val(value);
		document.getElementById('jd').submit()
	}else if(dokumen == "BA Nego"){
		$("#ba_nego").modal();
		$('#text').val(value);
	}else if(dokumen == "SPK"){
		$("#spk").modal();
		$('#text').val(value);
	}else if(dokumen == "BAP"){
		$("#bap").modal();
		$('#text').val(value);
	}else if(dokumen == "BAST"){
		$("#bast").modal();
		$('#text').val(value);
	}
}
</script> 
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>