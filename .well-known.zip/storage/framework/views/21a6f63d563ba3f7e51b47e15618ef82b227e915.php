<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Tambah Data</h2>
			<form class="form-group" action="<?php echo url('/tambah_dokumen_pekerjaan_proses'); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				
				<div class="form-group">
					<label for="isi">No Surat</label>
					<input type="text" name="no_surat" class="form-control" required="required">
					<input type="hidden" name="id_laporan_pekerjaan" class="form-control" value="<?php echo e($id_laporan_pekerjaan); ?>">
				</div>
				
				<div class="form-group">
					<label for="isi">Jenis Dokumen</label>
					<select name="jenis_dokumen" class="form-control" id="zoneSelect" onclick="updateChar();" required="required">
						<option value="">--Pilih Jenis Dokumen--</option>
						<option value="Usulan">Usulan</option>
						<option value="SPPH">Surat Permintaan Penawaran Harga</option>
						<option value="SPH">Surat Penawaran Harga</option>
						<option value="Undangan Nego">Undangan Klarifikasi & Negosiasi</option>
						<option value="BA Nego">Berita Acara Hasil Klarifikasi & Negosiasi</option>
						<option value="SPK">Surat Perintah Kerja</option>
						<option value="LPS">Laporan Penyelesaian Pekerjaan</option>
						<option value="BAP">Berita Acara Pemeriksaan</option>
						<option value="BAST">Berita Acara Serah Terima</option>
						<option value="SPP">Surat Permohonan Pembayaran</option>
						<option value="Kwitansi">Kwitansi</option>
						<option value="Invoice">Invoice</option>
						<option value="Faktur Pajak">Faktur Pajak</option>
						<option value="Lampiran Faktur Pajak">Lampiran Faktur Pajak</option>
						<option value="Surat Masuk">Surat Masuk</option>
						<option value="Surat Keluar">Surat Keluar</option>
					</select>
				</div>
				
				<?php
					$perihal=DB::table('laporan_pekerjaan')->where('id','=',$id_laporan_pekerjaan)->get()->first();
				?>
				<div class="form-group">
					<label for="isi">Perihal</label>
					<input type="text" id="prihal" name="prihal" class="form-control" required="required">
				</div>
				
				<div style="display:none;" id="tanggal12" class="form-group">
				<div class="form-group">
					<label >Tanggal Mulai</label>
					  <input style="background:#ffff;" type="text" class="form-control" id="tgl" autocomplete="off" name="tanggal_mulai" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>
					
				</div>
				
				<div class="form-group">
					<label >Tanggal Berakhir</label>
					  <input style="background:#ffff;" type="text" class="form-control" id="tgl2" autocomplete="off" name="tanggal_berakhir" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>
					  <input type="hidden" id="rt" name="rubahtanggal" value="tidak">
				</div>
				</div>
				
				<div style="display:none;" id="harga1" class="form-group">
					<label for="judul">Harga</label>
					<input type="text" id="harga" name="harga" class="form-control" >
				</div>
				
				<?php
				
				/**$catatan_pajak="
					<b>Kode dan Nomer Seri Faktur Pajak :</b><br><hr>
					<b>Dasar Pengenaan Pajak :</b><br><hr>
					<b>PPN = 10% x Dasar Pengenaan Pajak :</b><br><hr>
					<b>PT.PGAS Solution</b><br>
					NPWP :<hr>
		
					<b>PT.PGAS Solution</b><br>
					NPWP :<hr>";*/
					
				?>
				<!--
				<div class="form-group" id="catatan1" style="display:none;">
					<label for="isi">Catatan Pajak</label>
					<textarea name="catatan" id="catatan" >
					$catatan_pajak
						
					</textarea>
					<script>
					CKEDITOR.replace('catatan', {removePlugins: 'about,sourcearea,link,elementspath,image'});
					</script>
				</div>-->
				
				<div class="form-group">
					<label >Tanggal</label>
					  <input style="background:#ffff;" type="text" class="form-control" id="tgl3" autocomplete="off" name="tanggal" value="<?php echo date('d F Y',strtotime (date("Y-m-d"))) ; ?>" readonly>
					
				</div>
				
				<div class="form-group">
					<label for="exampleInputPassword1">File</label>
					<input type="file" class="form-control" name="file" onchange="validasiFile()" id="file" >
				</div>
				
				
				
				<div class="form-group">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>

<script>
function validasiFile(){
    var inputFile = document.getElementById('file');
    var pathFile = inputFile.value;
    var ekstensiOk = /(\.pdf|\.PDF)$/i;
    if(!ekstensiOk.exec(pathFile)){
        alert('Silakan upload file yang memiliki ekstensi mp4');
        inputFile.value = '';
        return false;
    }else{
        //Pratinjau gambar
        
    }
}

function updateChar() {

    var zone = document.getElementById("zoneSelect");

    if (zone.value == "SPK"){
		$("#harga1").fadeIn(1000);
		$("#tanggal12").fadeIn(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("prihal").value = "Surat Perintah Kerja <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "ya";
    }else if (zone.value == "SPP"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeIn(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("prihal").value = "Surat Permohonan Pembayaran <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
    }else if (zone.value == "SPH"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeIn(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("prihal").value = "Surat Penawaran Harga <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
    }else if (zone.value == "Kwitansi"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeIn(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("prihal").value = "Kwitansi <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
    }else if (zone.value == "Invoice"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeIn(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("prihal").value = "Invoice <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
    }else if (zone.value == "Faktur Pajak"){
		$("#tanggal12").fadeOut(1000);
		document.getElementById("harga").value = "";
		$("#harga1").fadeOut(1000);
		$("#catatan1").fadeIn(1000);
		document.getElementById("prihal").value = "Faktur Pajak <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
    }else if (zone.value == "Usulan"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeOut(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("harga").value = "";
		document.getElementById("prihal").value = "Usulan <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
	}else if (zone.value == "SPPH"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeOut(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("harga").value = "";
		document.getElementById("prihal").value = "Surat Permintaan Penawaran Harga <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
		
	}else if (zone.value == "Undangan Nego"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeOut(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("harga").value = "";
		document.getElementById("prihal").value = "Undangan Klarifikasi dan Negosiasi <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
		
	}else if (zone.value == "BA Nego"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeOut(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("harga").value = "";
		document.getElementById("prihal").value = "Berita Acara Klarifikasi dan Negosiasi Harga <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
		
	}else if (zone.value == "LPS"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeOut(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("harga").value = "";
		document.getElementById("prihal").value = "Laporan Penyelesaian <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
		
	}else if (zone.value == "BAP"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeOut(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("harga").value = "";
		document.getElementById("prihal").value = "Berita Acara Pemeriksaan <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
		
	}else if (zone.value == "BAST"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeIn(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("harga").value = "";
		document.getElementById("prihal").value = "Berita Acara Serah Terima <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
		
	}else if (zone.value == "Lampiran Faktur Pajak"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeOut(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("harga").value = "";
		document.getElementById("prihal").value = "Laporan Faktur Pajak <?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
		
	}else if (zone.value == "Surat Masuk" || zone.value == "Surat Keluar"){
		$("#tanggal12").fadeOut(1000);
		$("#harga1").fadeOut(1000);
		$("#catatan1").fadeOut(1000);
		document.getElementById("harga").value = "";
		document.getElementById("prihal").value = "<?php echo e($perihal->nama_pekerjaan); ?>";
		document.getElementById("rt").value = "tidak";
		
	}
}



</script>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>