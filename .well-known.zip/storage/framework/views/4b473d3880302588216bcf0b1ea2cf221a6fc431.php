<?php $__env->startSection('content'); ?>
	<!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-12 col-lg-12 align-self-center" style="margin-bottom:10px; text-align:center;">
						<h3 class="text-themecolor m-b-0 m-t-0">Wilayah Operasi</h3>
                    </div>
                   
                </div>
				<a href="<?php echo url('/bulanan'); ?>">
                            <i class="material-icons">reply</i>
            </a>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-block">
            <br>                
			<?php if(Auth::user()->hak_akses == "admin"): ?>			
            <form style="margin:-5px 0px 10px 10px;" action="<?php echo url('/tambah_wilayah_operasi'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<button type="submit" class="btn btn-info">Tambah</button></a>
			</form>
			<?php endif; ?>
			
			
			
			<?php
			$pelapor=DB::table('jenis_laporan')->where('id_tujuan',Auth::user()->id)->count();
			?>
			<?php if($pelapor != 0 and Auth::user()->hak_akses != "admin"): ?>			
            <form style="margin:-5px 0px 10px 10px;" action="<?php echo url('/selesai_melapor'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<input type="hidden" name="id_tujuan" value="<?php echo e(Auth::user()->id); ?>">
						<button type="submit" class="btn btn-info">Selesai Melapor</button></a>
			</form>
			<?php endif; ?>
			
			<?php if(Auth::user()->hak_akses == "admin"): ?>			
            <button style="margin-left:10px;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#kirim_notif_ke_pelapor">
			  Kirim Notif Ke Pelapor
			</button>
			<div class="modal fade" id="kirim_notif_ke_pelapor" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
						<form style="margin:-5px 0px 10px 10px;" action="<?php echo url('/kirim_notif_ke_pelapor'); ?>" method="post">
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
							<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
							<select name="id_users" class="form-control" required="required">
								<option value="">--Pilih Pelapor--</option>
								<option value="0">Tidak Ada Pelapor</option>
								<?php
								$pelapor=DB::table('users')->get();
								?>
								<?php $__currentLoopData = $pelapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelapor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($pelapor->id); ?>"><?php echo e($pelapor->name); ?></option>
									
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<button type="submit" style="margin-top:10px;" class="btn btn-info">Kirim</button></a>
						</form>
					  </div>
					  <div class="modal-footer">
					  </div>
					</div>
				  </div>
			</div>
			
			<?php endif; ?>
          
            <div class="card-body ">
              <div class="table-responsive" style="margin:10px;">
                <table class="table table-bordered table-striped table-hover js-basic-example dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					  <th>Wilayah Operasi </th>
                      
                      <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <th>Opsi</th>
					  <?php endif; ?>
					  
                    </tr>
                  </thead>
                  
                  <tbody>
				  <?php 
				  $no=1; 
				  $wilayah_operasi=DB::table('wilayah_operasi')->where('id_laporan_bulanan',$id_laporan_bulanan)->get();
				  ?>
				  
				  <?php $__currentLoopData = $wilayah_operasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
					 <td><a href="javascript:" onclick="document.getElementById('dbln<?php echo e($no); ?>').submit()"><div style="width:100%;"><?php echo e($wo->wilayah_operasi); ?></a></div></td>
					  
					  <div style="display:none;">
					<form id="dbln<?php echo e($no); ?>" action="<?php echo url('/jenis_laporan'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<input type="hidden" name="id_wilayah_operasi" value="<?php echo e($wo->id); ?>">
						<button type="submit" class="btn btn-primary">save</button></a>
					</form>
					  </div>
					  
					  <?php if(Auth::user()->hak_akses == "admin"): ?>
					  <td>
					  
					<form style="float:left; margin-right:5px;" action="<?php echo url('/edit_wilayah_operasi'); ?>" method="post">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
						<input type="hidden" name="id" value="<?php echo e($wo->id); ?>">
						<button type="submit" class="btn btn-primary">Edit</button></a>
					</form>
					  
					  <form method="post" action="<?php echo url('/hapus_wilayah_operasi'); ?>">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="id_laporan_bulanan" value="<?php echo e($id_laporan_bulanan); ?>">
					<input type="hidden" name="id" value="<?php echo e($wo->id); ?>">
					<input type="submit" class="btn btn-danger" value="Delete" />
				</form>
					  </td>
					  <?php endif; ?>
					  
                    </tr>
					<?php $no++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
         
							   
							   
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>