<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-12">
			<!-- content -->
			<h2>Edit Data</h2>
			<form class="form-group" action="<?php echo url('/edit_dokumen_bulanan_proses'); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				
				<?php $bln = DB::table('dokumen_laporan_bulanan')->where('id', '=', $id)->get()->first(); ?>
				
					<input type="hidden" name="id_laporan_bulanan" class="form-control" value="<?php echo e($id_laporan_bulanan); ?>">
					<input type="hidden" name="id_jenis_laporan" class="form-control" value="<?php echo e($id_jenis_laporan); ?>">
					<input type="hidden" name="id_wilayah_operasi" class="form-control" value="<?php echo e($id_wilayah_operasi); ?>">
					<input type="hidden" name="id" class="form-control" value="<?php echo e($id); ?>">
				
				
				<div class="form-group">
					<label for="isi">Perihal</label>
					<input type="text" name="prihal" class="form-control" value="<?php echo e($bln->prihal); ?>" required="required">
				</div>
				
				<div class="form-group">
					<label for="exampleInputPassword1">File ( Kosongkan Jika Tidak dirubah )</label>
					<input type="file" class="form-control" name="file" onchange="validasiFile()" id="file" >
					<input type="text" class="form-control" name="file_old"  value="<?php echo e($bln->nama_dokumen_laporan); ?>" >
				</div>
				
				<div class="form-group">
					<label class="col-sm-4 control-label">Tanggal</label>
					  <input style="background:#ffff;" type="text" class="form-control" id="tgl" autocomplete="off" name="tanggal" value="<?php echo date('d F Y',strtotime ($bln->tanggal)) ; ?>" readonly>
					
				</div>
				
				<div class="form-group">
					<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
				</div>
			</form>
		</div>
	</div>
	
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>